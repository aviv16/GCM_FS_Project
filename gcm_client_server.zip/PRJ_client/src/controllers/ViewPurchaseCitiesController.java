package controllers;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import client.UserClient;
import entity.City;
import entity.ClientPurchase;
import entity.Map;
import entity.report;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class ViewPurchaseCitiesController extends OpenWindowClass implements Initializable {

	/**
	 * The class ViewPurchaseCitiesController
	 */
	//*****SEMAPHORE
		/**
		 * Semaphore variables
		 */
		public static int flag;
		final Lock lock = new ReentrantLock();
		final Condition dbAvalibale = lock.newCondition();   
		//*****
		
	public static Map selectedMap;
	public static boolean isGotAllMaps;
	ArrayList<ClientPurchase> purchases;
	UserClient userClient;
	ObservableList<Map> availableMaps;
	
	/**
	 * Initialize the tables and the static variables.
	 * for every purchased city, requests for the city maps from the server.
	 * initialize the table of maps
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) 
	{
		userClient=ConnectToServerClass.userClient;
		userClient.setViewPurchaseCities(this);
		
		availableMaps=FXCollections.observableArrayList();
		mapIDColumn.setCellValueFactory(new PropertyValueFactory<Map, Integer>("IDMap"));
		mapIDColumn.setStyle( "-fx-alignment: CENTER;");
		cityNameColumn.setCellValueFactory(new PropertyValueFactory<Map, String>("cityName"));
		cityNameColumn.setStyle( "-fx-alignment: CENTER;");
		descriptionColumn.setCellValueFactory(new PropertyValueFactory<Map, String>("textualDescription"));
		descriptionColumn.setStyle( "-fx-alignment: CENTER;");
		flag=-1;
		purchases=HomeController.allValidPurchases;
		isGotAllMaps=false;
		if(purchases.size()==0)
		{
			noMaps.setVisible(true);
			return;
		}
		for(ClientPurchase purchase: purchases) //check if no purchases
		{
			lock.lock();
			QueryCommunicator Qcom=QueryCreator.getMapByCityName6(purchase.getCityName());
			userClient.handleMessageFromClientUI(Qcom);
			while (flag==-1)
				try {
					dbAvalibale.await();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
			lock.unlock();
			flag=-1;
		}
		
		mapsTable.getItems().setAll(availableMaps);
	}

	@FXML
	private TableView<Map> mapsTable;

	@FXML
	private TableColumn<Map, Integer> mapIDColumn;

	@FXML
	private TableColumn<Map, String> cityNameColumn;

	@FXML
	private TableColumn<Map, String> descriptionColumn;

	@FXML
	private Label noMaps;

	/**
	 * going back to previous page
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void back(ActionEvent event) throws IOException 
	{
		openWindow(event, "Home", "application");
	}

	/**
	 * opens new window to show selected map
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void viewMap(ActionEvent event) throws IOException 
	{
		selectedMap=mapsTable.getSelectionModel().getSelectedItem();
		if(selectedMap==null)
		{
			return;
		}
		isGotAllMaps=true;
		LocalDate today=LocalDate.now();
		String date= today.format(DateTimeFormatter.ofPattern("dd/MM/yy"));
		openWindowWithoutClosingCurrent("MapImage", "application");
		QueryCommunicator Qcom=QueryCreator.getReportByCityName1(selectedMap.getCityName(), date);
		userClient.handleMessageFromClientUI(Qcom);
	}
	
	/**
	 * gets maps of city and saves them to present in table
	 * @param maps
	 */
	public void setMapsOfCity(ArrayList<Map> maps)
	{
		for(Map map:maps)
		{
			availableMaps.add(map);
		}
		flag=1;
		lock.lock();
		dbAvalibale.signalAll();
		lock.unlock();
	}
	
	/**
	 * get report of the day and add 1 to the views count
	 * @param reports
	 */
	public void setReport(ArrayList<report> reports)
	{
		QueryCommunicator Qcom;
		LocalDate today=LocalDate.now();
		String date= today.format(DateTimeFormatter.ofPattern("dd/MM/yy"));
		if(reports.size()==0)
		{
			Qcom=QueryCreator.insertReport1(selectedMap.getCityName(), date, 1,0);
			userClient.handleMessageFromClientUI(Qcom);
			return;
		}
		else {
			Qcom=QueryCreator.UpdatetReport2(selectedMap.getCityName(), date, reports.get(0).getViewsNumber()+1);
			userClient.handleMessageFromClientUI(Qcom);
			return;
		}
	}
}
