package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import client.UserClient;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import com.jfoenix.controls.JFXTextField;


public class RegistrationController extends OpenWindowClass implements Initializable{

	/**
	 * class RegistrationController
	 *
	 */
	public static boolean userNameExists;
	
	/**
	 * Semaphore variables
	 */
	public static int flag=-1;
	final Lock lock = new ReentrantLock();
	final Condition dbAvalibale = lock.newCondition();   

		UserClient userClient;
		/**
		 * Sets the userClient from ConnectToServerClass to communicate with the server through it, and sends "this" to get feedback from the server
		 */
		@Override
		public void initialize(URL arg0, ResourceBundle arg1) {
			
			userClient=ConnectToServerClass.userClient;
			userClient.setRegistration(this);
		}
	@FXML
	JFXTextField firstNameTxt;
	
	@FXML
	JFXTextField lastNameTxt;
	
	@FXML
	JFXTextField userNameTxt;
	
	@FXML
	JFXTextField passwordTxt;
	
	@FXML
	JFXTextField passwordConfirmTxt;
	
	@FXML
	JFXTextField phoneTxt;
	
	@FXML
	JFXTextField emailNameTxt;
	
	@FXML
	JFXTextField cardNumberTxt;
	
	@FXML
	JFXTextField cvvTxt;
	
	@FXML
	JFXTextField expireMonthTxt;
	
	@FXML
	JFXTextField expireYearTxt;
	
	@FXML
	Button backBtn;
	
	@FXML
	Button registerBtn;
	
	@FXML
	Label errorLabel;
	
	@FXML
	Label usernameExistLabel;
	
	/**
	 * When "Back" button is clicked, switches to login page
	 * @param event
	 * @throws IOException
	 */
	public void back(ActionEvent event) throws IOException
	{
		openWindow(event,"LogIn","application");
	}
	
	/**
	 * When "register" button is clicked, checks for empty fields,
	 * check password confirmation and then sends query to check if username availible
	 * @param event
	 * @throws IOException
	 * @throws InterruptedException 
	 */
	public void register(ActionEvent event) throws IOException, InterruptedException
	{
		usernameExistLabel.setVisible(false);
		errorLabel.setVisible(false);
		clearRed();
		
		if( firstNameTxt.getText().isEmpty()||
				lastNameTxt.getText().isEmpty()||
				userNameTxt.getText().isEmpty()||
				passwordTxt.getText().isEmpty()
			||passwordConfirmTxt.getText().isEmpty()||phoneTxt.getText().isEmpty()||emailNameTxt.getText().isEmpty()
			||cardNumberTxt.getText().isEmpty()||cvvTxt.getText().isEmpty()||expireMonthTxt.getText().isEmpty()||expireYearTxt.getText().isEmpty())
		{
			errorLabel.setText("Missing field!");
			errorLabel.setVisible(true);
			return;
		}
		
		if(passwordConfirmTxt.getText().equals(passwordTxt.getText())==false)
		{
			errorLabel.setText("The password confirmation does not match the password!");
			errorLabel.setVisible(true);
			passwordConfirmTxt.setStyle("-fx-text-inner-color: red");
			passwordTxt.setStyle("-fx-text-inner-color: red");
			return;
		}
		
		for(int i=0; i<phoneTxt.getText().length(); i++)
		{
			if(phoneTxt.getText().charAt(i)<'0'||phoneTxt.getText().charAt(i)>'9')
			{
				errorLabel.setText("Phone field has to contain numbers only!");
				errorLabel.setVisible(true);
				phoneTxt.setStyle("-fx-text-inner-color: red");
				return;
			}
		}
		
		for(int i=0; i<cardNumberTxt.getText().length(); i++)
		{
			if(cardNumberTxt.getText().charAt(i)<'0'||cardNumberTxt.getText().charAt(i)>'9')
			{
				errorLabel.setText("Card number field has to contain numbers only!");
				errorLabel.setVisible(true);
				cardNumberTxt.setStyle("-fx-text-inner-color: red");
				return;
			}
		}
		
		
		for(int i=0; i<cvvTxt.getText().length(); i++)
		{
			if(cvvTxt.getText().charAt(i)<'0'||cvvTxt.getText().charAt(i)>'9')
			{
				errorLabel.setText("CVV field has to contain numbers only!");
				errorLabel.setVisible(true);
				cvvTxt.setStyle("-fx-text-inner-color: red");
				return;
			}
		}
		
		if(cvvTxt.getText().length()!=3)
		{
			errorLabel.setText("The CVV field has to be 3 numbers");
			errorLabel.setVisible(true);
			cvvTxt.setStyle("-fx-text-inner-color: red");
			return;
		}
		
		for(int i=0; i<firstNameTxt.getText().length(); i++)
		{
			if(!((firstNameTxt.getText().charAt(i)<='Z'&&firstNameTxt.getText().charAt(i)>='A')
					||(firstNameTxt.getText().charAt(i)<='z'&&firstNameTxt.getText().charAt(i)>='a')))
			{
				errorLabel.setText("First name has to contain letters only!");
				errorLabel.setVisible(true);
				firstNameTxt.setStyle("-fx-text-inner-color: red");
				return;
			}
		}	
		
		for(int i=0; i<lastNameTxt.getText().length(); i++)
		{
			if(!((lastNameTxt.getText().charAt(i)<='Z'&&lastNameTxt.getText().charAt(i)>='A')
					||(lastNameTxt.getText().charAt(i)<='z'&&lastNameTxt.getText().charAt(i)>='a')))
			{
				errorLabel.setText("Last name has to contain letters only!");
				errorLabel.setVisible(true);
				lastNameTxt.setStyle("-fx-text-inner-color: red");
				return;
			}
		}
		
			if((!(emailNameTxt.getText().contains("@")))||!(emailNameTxt.getText().contains(".")))
			{
				errorLabel.setText("Email format is illegal!");
				errorLabel.setVisible(true);
				emailNameTxt.setStyle("-fx-text-inner-color: red");
				return;
			}
			
			for(int i=0; i<expireMonthTxt.getText().length(); i++)
			{
				if(expireMonthTxt.getText().charAt(i)<'0'||expireMonthTxt.getText().charAt(i)>'9')
				{
					errorLabel.setText("Expiry month field has to contain numbers only!");
					errorLabel.setVisible(true);
					expireMonthTxt.setStyle("-fx-text-inner-color: red");
					return;
				}
			}
			
			if(expireMonthTxt.getText().length()!=2)
			{
				errorLabel.setText("Expiry month field has to be 2 numbers");
				errorLabel.setVisible(true);
				expireMonthTxt.setStyle("-fx-text-inner-color: red");
				return;
			}
			
			for(int i=0; i<expireYearTxt.getText().length(); i++)
			{
				if(expireYearTxt.getText().charAt(i)<'0'||expireYearTxt.getText().charAt(i)>'9')
				{
					errorLabel.setText("Expiry year field has to contain numbers only!");
					errorLabel.setVisible(true);
					expireYearTxt.setStyle("-fx-text-inner-color: red");
					return;
				}
			}
			
			if(expireYearTxt.getText().length()!=2)
			{
				errorLabel.setText("Expiry year field has to be 2 numbers");
				errorLabel.setVisible(true);
				expireYearTxt.setStyle("-fx-text-inner-color: red");
				return;
			}
			
		
		lock.lock();
		QueryCommunicator Qcom = QueryCreator.checkExistUserQuery(userNameTxt.getText());
		userClient.handleMessageFromClientUI(Qcom);
		
		while (flag==-1)
			dbAvalibale.await(); 
		lock.unlock();
		
		if(flag==1)
		{
			flag=-1;
			lock.lock(); //??
		String expireDate=expireMonthTxt.getText()+"/"+expireYearTxt.getText();
		ArrayList <QueryCommunicator> queryArr=QueryCreator.registerNewUserQuery(firstNameTxt.getText(),lastNameTxt.getText(),userNameTxt.getText(),
																			passwordTxt.getText(),phoneTxt.getText(),emailNameTxt.getText(),
																			cardNumberTxt.getText(),cvvTxt.getText(),expireDate, 1,0);
		ConnectToServerClass.userClient.handleMessageFromClientUI(queryArr.get(0));
		Thread.currentThread().sleep(1);
		ConnectToServerClass.userClient.handleMessageFromClientUI(queryArr.get(1));
		//openSuccessWindow("SuccessRegistration","application");
		popUpWindow("Registration Complete!");
		openWindow(event,"LogIn","application");
		}
	}
	
	/**
	 * gets boolean from server that indicates whether the username exist in
	 * database or not. If not, sends query with the inserted info to create new
	 * user in database and goes back to "login" page to log in.
	 * 
	 * @param exist
	 */
	public void userExist(boolean exist)
	{
		
		if(exist)
		{
			userNameExists=true;// probably not necessary
			usernameExistLabel.setVisible(true);
			flag=2;
		}
		else {
			flag=1;			
		}
		lock.lock();
		dbAvalibale.signalAll();
		lock.unlock();
	}
	
	/**
	 * clear the error 
	 */
	public void clearRed()
	{
		firstNameTxt.setStyle("-fx-text-inner-color: black");
		lastNameTxt.setStyle("-fx-text-inner-color: black");
		userNameTxt.setStyle("-fx-text-inner-color: black");
		passwordTxt.setStyle("-fx-text-inner-color: black");
		passwordConfirmTxt.setStyle("-fx-text-inner-color: black");
		phoneTxt.setStyle("-fx-text-inner-color: black");
		emailNameTxt.setStyle("-fx-text-inner-color: black");
		cardNumberTxt.setStyle("-fx-text-inner-color: black");
		cvvTxt.setStyle("-fx-text-inner-color: black");
		expireMonthTxt.setStyle("-fx-text-inner-color: black");
		expireYearTxt.setStyle("-fx-text-inner-color: black");
	}
}


