package controllers;

import java.io.Serializable;


public class SendDataClass implements Serializable {

	/**
	 * The class SendDataClass this class classifies a data which is transfered to
	 * the server by the screen name it has been transfered from.
	 *
	 */
	private static final long serialVersionUID = 1L;

	private String screenName;
	private Object data;

	/**
	 * constructor of the class data type that initializes the data object and the
	 * screen name.
	 * 
	 * @param screenName
	 * @param data
	 */
	public SendDataClass(String screenName, Object data) {
		this.data = data;
		this.screenName = screenName;
	}

	/**
	 * get the screen name
	 * 
	 * @return
	 */
	public String getScreenName() {
		return screenName;
	}

	public Object getData() {
		return data;
	}
}
