package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.ResourceBundle;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import client.UserClient;
import entity.City;
import entity.Site;
import entity.SiteInTour;
import entity.Tour;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;


public class EditTourController extends OpenWindowClass implements Initializable {

	/**
	 * 
	 * The class EditTourController
	 *
	 */
	public static EditTourController editTourCon;

	Site selectedSite;
	Tour currentTour = null;
	ArrayList<Site> sitesInCity = null;
	ArrayList<SiteInTour> startSitesInTour = null;
	ArrayList<SiteInTour> sitesToAddToTour = null;
	ArrayList<SiteInTour> sitesToRemoveFromTour = null;
	public ObservableList<Site> sitesInCityList;
	public ObservableList<SiteInTour> sitesInTourList;
	City currentCity = null;

	UserClient userClient;

	/**
	 * Sets the userClient from ConnectToServerClass to communicate with the server
	 * through it, and sends "this" to get feedback from the server
	 */

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		userClient = ConnectToServerClass.userClient;
		userClient.setEditTour(this);
		editTourCon = this;
		currentTour = EditCityController.currentTour;
		sitesInCityList = FXCollections.observableArrayList();
		sitesInTourList = FXCollections.observableArrayList();
		// sitesInCityList=EditCityController.sitesList; //initialized in fillTables
		// method
		startSitesInTour = new ArrayList<SiteInTour>();
		sitesToAddToTour = new ArrayList<SiteInTour>();
		sitesToRemoveFromTour = new ArrayList<SiteInTour>();

		siteInTourNumColumn.setCellValueFactory(new PropertyValueFactory<SiteInTour, Integer>("serialNumber"));
		siteInTourNumColumn.setStyle("-fx-alignment: CENTER;");
		siteInTourNameColumn.setCellValueFactory(new PropertyValueFactory<SiteInTour, String>("siteName"));
		siteInTourNameColumn.setStyle("-fx-alignment: CENTER;");
		siteInTourDurationColumn.setCellValueFactory(new PropertyValueFactory<SiteInTour, Integer>("durationOfVisit"));
		siteInTourDurationColumn.setStyle("-fx-alignment: CENTER;");
		siteInCityNameColumn.setCellValueFactory(new PropertyValueFactory<Site, String>("siteName"));
		siteInCityNameColumn.setStyle("-fx-alignment: CENTER;");

		currentCity = EditCityController.currentCity;
		cityNameLabel.setText(currentCity.getName());
		tourDescriptionTxt.setText(currentTour.getDescription());

		QueryCommunicator Qcom = QueryCreator.getSitesInSpecificTour(currentTour.getIDTour(), currentCity.getName());
		userClient.handleMessageFromClientUI(Qcom);

		/*
		 * //TEST startSitesInTour.add(new SiteInTour(1, 1, 20, "Name", "city"));
		 * fillTables(startSitesInTour);
		 */
	}

	@FXML
	Label cityNameLabel;

	@FXML
	Label nothingSelcted;

	@FXML
	TextArea tourDescriptionTxt;

	@FXML
	TableView<SiteInTour> siteInTourTable;

	@FXML
	TableColumn<SiteInTour, Integer> siteInTourNumColumn;

	@FXML
	TableColumn<SiteInTour, String> siteInTourNameColumn;

	@FXML
	TableColumn<SiteInTour, Integer> siteInTourDurationColumn;

	@FXML
	TableView<Site> siteInCityTable;

	@FXML
	TableColumn<Site, String> siteInCityNameColumn;

	/**
	 * goes back to EditCity window without saving the changes
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void cancel(ActionEvent event) throws IOException {
		editTourCon = null;
		openWindow(event, "EditCity", "application");
	}

	/**
	 * remove site from tour
	 * 
	 * @param event
	 */
	public void removeSiteFromTour(ActionEvent event) {
		boolean flag = false;
		nothingSelcted.setVisible(false);
		if (siteInTourTable.getSelectionModel().getSelectedItem() == null) // checks if there is selection from the
																			// table
		{
			nothingSelcted.setVisible(true);
			return;
		}
		SiteInTour removedSiteInTour = siteInTourTable.getSelectionModel().getSelectedItem();
		Site removedFromTour = null;
		for (Site site : EditCityController.sitesArr) {
			if (removedSiteInTour.getSiteName().equals(site.getSiteName())) {
				removedFromTour = site; // gets the site that's being removed from the tour
				break;
			}
		}
		for (SiteInTour sit : sitesToAddToTour)// checks if the site was part of the tour before edit
		{
			if (sit.getSiteName().equals(removedSiteInTour.getSiteName()))// the site was added and than removed
			{
				flag = true;
				sitesToAddToTour.remove(sit);
				break;
			}
		}
		if (!flag) // the site was in the tour in first and now needs to be removed
		{
			sitesToRemoveFromTour.add(removedSiteInTour);
		}
		SiteInTour toDel = null;
		for (SiteInTour sit : sitesInTourList) // updating the ObservableList to show updated tables
		{
			if (removedSiteInTour.getSiteName().equals(sit.getSiteName()))
				toDel = sit;
			else if (removedSiteInTour.getSerialNumber() < sit.getSerialNumber())
				sit.setSerialNumber(sit.getSerialNumber() - 1);
		}
		sitesInTourList.remove(toDel);
		siteInTourTable.getItems().setAll(sitesInTourList);

		siteInCityTable.getItems().add(removedFromTour);
		// siteInTourTable.getItems().remove(removedSiteInTour); //MAYBE IRRELEVANT-
		// CHECK

	}

	/**
	 * Add site to tour
	 * 
	 * @param event
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void addSiteToTour(ActionEvent event) throws IOException, InterruptedException {
		nothingSelcted.setVisible(false);
		if (siteInCityTable.getSelectionModel().getSelectedItem() == null) {
			nothingSelcted.setVisible(true);
			return;
		}
		Site newSite = siteInCityTable.getSelectionModel().getSelectedItem(); // gets selected site
		selectedSite = newSite;
		openWindowWithoutClosingCurrent("AddDurationAndSerial", "application"); // goes to window to get input from user
	}

	/**
	 * The employee click save. update the database: add sites to city tour or edit
	 * site in tour or remove site.
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void save(ActionEvent event) throws IOException {
		QueryCommunicator Qcom;
		System.out.println("Sites to add:");
		for (SiteInTour sit : sitesToAddToTour) {
			// Add SiteInTour query
			Qcom = QueryCreator.AddSitesToCityTourQueryInEditTour(sit.getTourID(), sit.getCityName(), sit.getSiteName(),
					sit.getSerialNumber(), sit.getDurationOfVisit());
			userClient.handleMessageFromClientUI(Qcom);
			// TEST
			System.out.println(sit.getSiteName());
		}
		System.out.println("\nSites to remove:");
		for (SiteInTour sit : sitesToRemoveFromTour) {
			// delete SiteInTour query
			Qcom = QueryCreator.deleteSiteInTour(sit.getTourID(), sit.getCityName(), sit.getSiteName());
			userClient.handleMessageFromClientUI(Qcom);
			// TEST
			System.out.println(sit.getSiteName());
		}
		System.out.println("\nSites to change:");
		for (SiteInTour sit : startSitesInTour) {
			if (!(sitesToRemoveFromTour.contains(sit))) {
				// update SiteInTour query
				Qcom = QueryCreator.EditSiteInTourQuery(sit.getTourID(), sit.getCityName(), sit.getSiteName(),
						sit.getSerialNumber(), sit.getDurationOfVisit());
				userClient.handleMessageFromClientUI(Qcom);
				// TEST
				System.out.println(sit.getSiteName());
			}
		}
		editTourCon = null;
		Qcom=QueryCreator.EditTour(currentTour.getIDTour(), tourDescriptionTxt.getText());
		userClient.handleMessageFromClientUI(Qcom);
		popUpWindow("The tour has been edited successfully!");
		openWindow(event, "EditCity", "application");
	}

	/**
	 * gets ArrayList of all the sites in the tour sets them in the table of the
	 * sites in tour sets the other table with all the sites of the city that are
	 * not in the tour
	 * 
	 * @param sitesInTour
	 */
	public void fillTables(ArrayList<SiteInTour> sitesInTour) {
		System.out.println("fill tables");
		System.out.println(sitesInTour);
		boolean flag = false;
		startSitesInTour = sitesInTour;
		for (SiteInTour siteInTour : sitesInTour) {
			sitesInTourList.add(siteInTour);
		}
		Collections.sort(sitesInTourList, new SiteInTourComparator()); // sorts the sites by position
		siteInTourTable.getItems().setAll(sitesInTourList);

		sitesInCity = EditCityController.sitesArr;
		for (Site site : sitesInCity) {
			for (SiteInTour siteInTour : sitesInTour) {
				if (site.getSiteName().equals(siteInTour.getSiteName())) {
					flag = true;
				}
			}
			if (!flag) {
				sitesInCityList.add(site);
			}
			flag = false;
		}
		siteInCityTable.getItems().setAll(sitesInCityList);
	}

	/**
	 * add to site information duration and location
	 * 
	 * @param enteredDuration
	 * @param position
	 */
	public void addDurAndPos(int enteredDuration, int position) {
		int duration = enteredDuration, serial = position;

		SiteInTour newSiteInTour = new SiteInTour(currentTour.getIDTour(), serial, duration, selectedSite.getSiteName(),
				currentCity.getName());
		// TEST SiteInTour newSiteInTour=new SiteInTour(currentTour.getIDTour(), serial,
		// duration, selectedSite.getSiteName(), "city");

		boolean flag = false;
		for (SiteInTour sit : sitesToRemoveFromTour) {
			if (sit.getSiteName().equals(newSiteInTour.getSiteName())) // the site was removed and than added back
			{
				flag = true;
				sitesToRemoveFromTour.remove(sit);
				break;
			}
		}
		if (!flag) // if the site wasn't in the tour before edit
		{
			sitesToAddToTour.add(newSiteInTour);
		}
		int maxPos = 0;
		for (SiteInTour sit : sitesInTourList) // loop that arranges the position according to the entered position of
												// the site
		{
			if (sit.getSerialNumber() >= serial) {
				sit.setSerialNumber(sit.getSerialNumber() + 1);
			}
			if (maxPos < sit.getSerialNumber())
				maxPos = sit.getSerialNumber();
		}
		if (maxPos + 1 < serial)
			newSiteInTour.setSerialNumber(maxPos + 1);

		sitesInTourList.add(newSiteInTour);
		Collections.sort(sitesInTourList, new SiteInTourComparator()); // sorts the sites by position
		siteInCityTable.getItems().remove(selectedSite);
		siteInTourTable.getItems().setAll(sitesInTourList);
	}
}
