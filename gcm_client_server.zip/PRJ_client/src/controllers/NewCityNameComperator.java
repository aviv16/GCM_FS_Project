package controllers;


import java.util.Comparator;

import entity.newCity;


public class NewCityNameComperator implements Comparator<newCity> {

	/**
	 * The class  NewCityNameComperator  compare to cities by their name
	 *
	 */
	@Override
	public int compare(newCity city1, newCity city2) {
		return city1.getName().compareTo(city2.getName());
	}

}