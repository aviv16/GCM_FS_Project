package controllers;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.UserClient;
import entity.City;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXComboBox;

public class CreateReportController extends OpenWindowClass implements Initializable {
	/**
	 * The class CreateReportController - the manager selects the report he wants
	 *
	 */
	UserClient userClient;
	public static ObservableList<String> cityNames;
	public static LocalDate selectedDate;
	public static String cityName;
	
	@FXML
	JFXComboBox<String> cityNameCB;

    @FXML
    DatePicker date;

    @FXML
    JFXButton createReport;

    @FXML
    JFXCheckBox allCityCheckBox;

    @FXML
    JFXCheckBox chooseCityCheckBox;
    
    @FXML
    Label noCitySelectedLabel;
    
    @FXML
    Label illegalDate;
    
    /**
     * initialize the screen "CreateReport".
     * sets instance of this controller in userClient to get data from server.
     * send query to get all cities and when receiving the list, fill the comboBox.
     */
    @Override
	public void initialize(URL arg0, ResourceBundle arg1) {
    	userClient=ConnectToServerClass.userClient;
    	userClient.setCreateReport(this);
    	
    	allCityCheckBox.setSelected(true);
    	chooseCityCheckBox.setSelected(false);
    	cityNames=FXCollections.observableArrayList();
    	QueryCommunicator Qcom=QueryCreator.getCityQuery3();
    	userClient.handleMessageFromClientUI(Qcom);
    	
    	cityNameCB.setDisable(true);
    	
    	date.setValue(LocalDate.now());
	}
    
    /**
     * manager click "back"- back to manager home page.
     * @param event
     * @throws IOException
     */
    public void backToLoginClick(ActionEvent event) throws IOException {
    	openWindow(event, "ManagerHome", "application");
    }
    
    /**
     * The manager select all city report.
     * @param event
     */
    public void allCitiesClick(ActionEvent event)
    {
    	chooseCityCheckBox.setSelected(false);
    	cityNameCB.setDisable(true);
    }
    
    /**
     * The manager select one city report.
     * @param event
     */
    public void chooseCityClick(ActionEvent event)
    {
    	allCityCheckBox.setSelected(false);
    	cityNameCB.setDisable(false);
    }
    
    /**
     * click "create report" button go to "ShowReport" screen.
     * @param event
     * @throws IOException
     */
    public void createReport(ActionEvent event) throws IOException
    {
    	if(date.getValue().isAfter(LocalDate.now()))
    	{
    		illegalDate.setVisible(true);
    		return;
    	}
    	selectedDate=date.getValue();
    	if(allCityCheckBox.isSelected())
    		cityName=null;
    	else { //specific city is chosen
    		if(cityNameCB.getValue()==null)
    		{
    			noCitySelectedLabel.setVisible(true);
    			return;
    		}
    		cityName=cityNameCB.getValue();
    	}
    	openWindow(event, "ShowReport","application");
    }
    
    /**
     * Get all cities from database and fill the comboBox.
     * @param cities
     */
    public void setCities(ArrayList<City> cities)
    {
    	for(City city: cities)
    	{
    		cityNames.add(city.getName());
    	}
    	cityNameCB.setItems(cityNames);
    }
}
