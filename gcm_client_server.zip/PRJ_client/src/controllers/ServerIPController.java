package controllers;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import com.jfoenix.controls.JFXTextField;


public class ServerIPController extends OpenWindowClass {

	/**
	 * The class ServerIPController
	 *
	 */
	@FXML
	JFXTextField serverIP;

	@FXML
	Label connectionFail;

	public static String host;
	public static int DEFAULT_PORT = 5555;

	/**
	 * submits a new connection to server according to the given IP address given by
	 * the user in a textbox.
	 * 
	 * @param event
	 */
	public void connectToServer(ActionEvent event) {
		host = serverIP.getText();
		ConnectToServerClass conToServer = new ConnectToServerClass();
		try {
			conToServer.connectToServer(serverIP.getText());
			openWindow(event, "LogIn", "application");
			// openWindow(event, "SubscriptionRenewal","application");
		} catch (IOException e) {
			connectionFail.setVisible(true);
		}
	}
}
