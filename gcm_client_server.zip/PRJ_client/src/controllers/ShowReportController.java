package controllers;

import java.io.IOException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.ResourceBundle;

import client.UserClient;
import entity.ClientPurchase;
import entity.Map;
import entity.StatisticInformation;
import entity.report;
import javafx.fxml.Initializable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class ShowReportController extends OpenWindowClass implements Initializable {

	/**
	 * Class that showing all the information of the report
	 *
	 */
	UserClient userClient;
	ObservableList<StatisticInformation> statisticsArr;
	String date;

	@FXML
	private TableView<StatisticInformation> statisticsInfo;

	@FXML
	private TableColumn<StatisticInformation, String> cityColumn;

	@FXML
	private TableColumn<StatisticInformation, Integer> numOfMapsColumn;

	@FXML
	private TableColumn<StatisticInformation, Integer> oneTimePurchaseColumn;

	@FXML
	private TableColumn<StatisticInformation, Integer> subscriptionsColumn;

	@FXML
	private TableColumn<StatisticInformation, Integer> renewalColumn;

	@FXML
	private TableColumn<StatisticInformation, Integer> viewsColumn;

	@FXML
	private TableColumn<StatisticInformation, Integer> downloadsColumn;

	@FXML
	private Label reportDate;

	/**
	 * Initialize the table and the arrays and sending query to get the maps of the
	 * cities the user want
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		userClient = ConnectToServerClass.userClient;
		userClient.setShowReport(this);

		statisticsArr = FXCollections.observableArrayList();
		date = CreateReportController.selectedDate.format(DateTimeFormatter.ofPattern("dd/MM/yy"));
		reportDate.setText(date);

		cityColumn.setCellValueFactory(new PropertyValueFactory<StatisticInformation, String>("cityName"));
		cityColumn.setStyle("-fx-alignment: CENTER;");
		numOfMapsColumn.setCellValueFactory(new PropertyValueFactory<StatisticInformation, Integer>("numberOfMaps"));
		numOfMapsColumn.setStyle("-fx-alignment: CENTER;");
		oneTimePurchaseColumn
				.setCellValueFactory(new PropertyValueFactory<StatisticInformation, Integer>("oneTimeNumber"));
		oneTimePurchaseColumn.setStyle("-fx-alignment: CENTER;");
		subscriptionsColumn
				.setCellValueFactory(new PropertyValueFactory<StatisticInformation, Integer>("subscriptionNumber"));
		subscriptionsColumn.setStyle("-fx-alignment: CENTER;");
		renewalColumn.setCellValueFactory(new PropertyValueFactory<StatisticInformation, Integer>("renewalsNumber"));
		renewalColumn.setStyle("-fx-alignment: CENTER;");
		viewsColumn.setCellValueFactory(new PropertyValueFactory<StatisticInformation, Integer>("viewsNumber"));
		viewsColumn.setStyle("-fx-alignment: CENTER;");
		downloadsColumn.setCellValueFactory(new PropertyValueFactory<StatisticInformation, Integer>("downloadsNumber"));
		downloadsColumn.setStyle("-fx-alignment: CENTER;");

		QueryCommunicator Qcom;
		if (CreateReportController.cityName == null) // report on all cities
		{
			Qcom = QueryCreator.getMap();
			userClient.handleMessageFromClientUI(Qcom);
		} else { // report on specific city
			Qcom = QueryCreator.getMapByCityName2(CreateReportController.cityName);
			userClient.handleMessageFromClientUI(Qcom);
		}
	}

	/**
	 * get all the relevant maps for the report send query to get all the relevant
	 * purchases of those cities
	 * 
	 * @param maps
	 */
	public void getCityMap(ArrayList<Map> maps) {
		System.out.println("setMaps");
		QueryCommunicator Qcom;
		int mapsCount = 0;
		if (CreateReportController.cityName == null) // report on all cities
		{
			for (String cityName : CreateReportController.cityNames) {
				mapsCount = 0;
				for (Map map : maps) {
					if ((map.getCityName().equals(cityName)) && (dateInRange(map, date)))
						mapsCount++;
				}
				statisticsArr.add(new StatisticInformation(cityName, mapsCount));
			}
		} else { // report on specific city
			for (Map map : maps) {
				if (dateInRange(map, date))
					mapsCount++;
			}
			StatisticInformation si = new StatisticInformation(CreateReportController.cityName, mapsCount);
			statisticsArr.add(si);
		}
		Collections.sort(statisticsArr, new StatisticComparator());
		statisticsInfo.getItems().setAll(statisticsArr);
		Qcom = QueryCreator.getClientPurchase2();
		userClient.handleMessageFromClientUI(Qcom);
	}

	/**
	 * gets all the relevant purchases send query to get all reports of the desired
	 * date
	 * 
	 * @param purchases
	 */
	public void setAllPurchases(ArrayList<ClientPurchase> purchases) {
		System.out.println("setPurch");
		int oneTimeCount;
		int subscriptionsCount;
		int renewalsCount;
		for (StatisticInformation info : statisticsArr) {
			oneTimeCount = 0;
			subscriptionsCount = 0;
			renewalsCount = 0;
			for (ClientPurchase pur : purchases) {
				if ((info.getCityName().equals(pur.getCityName())) && ((pur.getDate().equals(date))
						|| ((pur.getPurchaseType() == 2) && (subscriptionInRange(pur, date))))) // relevant city,
																								// requested date or
																								// valid subscription
				{
					if (pur.isSubRenewal() == 1)
						renewalsCount++;
					else {
						if (pur.getPurchaseType() == 1) {
							oneTimeCount++;
						}
						if (pur.getPurchaseType() == 2) {
							subscriptionsCount++;
						}
					}
				}
			}
			info.setOneTimeNumber(oneTimeCount);
			info.setSubscriptionNumber(subscriptionsCount);
			info.setRenewalsNumber(renewalsCount);
		}
		Collections.sort(statisticsArr, new StatisticComparator());
		statisticsInfo.getItems().setAll(statisticsArr);
		QueryCommunicator Qcom = QueryCreator.getReportDate(date);
		userClient.handleMessageFromClientUI(Qcom);
	}

	/**
	 * gets the reports of the desired date. fill the table with all the data
	 * 
	 * @param reports
	 */
	public void setReports(ArrayList<report> reports) {
		System.out.println("setReports");
		for (StatisticInformation info : statisticsArr) {
			for (report rep : reports) {
				if (rep.getCityName().equals(info.getCityName())) {
					info.setDownloadsNumber(rep.getDownloadsNumber());
					info.setViewsNumber(rep.getViewsNumber());
				}
			}
		}
		Collections.sort(statisticsArr, new StatisticComparator());
		statisticsInfo.getItems().setAll(statisticsArr);
	}

	/**
	 * going back to the previous page
	 * 
	 * @param event
	 */
	public void back(ActionEvent event) {
		try {
			openWindow(event, "CreateReport", "application");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * gets map and date and returns whether the map was available that date or not
	 * 
	 * @param map
	 * @param requestedDate
	 * @return
	 */
	public boolean dateInRange(Map map, String requestedDate) {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		try {
			Date requested = formatter.parse(requestedDate);
			Date startDate = formatter.parse(map.getUploadDate());
			if (requested.after(startDate) || requested.equals(startDate)) // the map uploaded before the requested date
			{
				if (map.getDeleteDate().equals("0")) // the map wasn't deleted
				{
					return true;
				}
				Date deleteDate = formatter.parse(map.getDeleteDate());
				if (requested.before(deleteDate)) {
					return true;
				}

			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * gets purchase and date and returns whether the purchase was relevant on that
	 * date or not
	 * 
	 * @param purch
	 * @param requestedDate
	 * @return
	 */
	public boolean subscriptionInRange(ClientPurchase purch, String requestedDate) {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		try {
			Date requested = formatter.parse(requestedDate);
			Date purchased = formatter.parse(purch.getDate());
			if (purchased.before(requested))// the purchase was made before the requested date. may be valid
			{
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(purchased);
				calendar.add(calendar.MONTH, purch.getSubPeriod());
				if (calendar.getTime().after(requested)) // the requested date is before the end of subscription
				{
					return true;
				}
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * comparator of statisticInformation by the city name
	 *
	 */
	public class StatisticComparator implements Comparator<StatisticInformation> {
		@Override
		public int compare(StatisticInformation info1, StatisticInformation info2) {
			return info1.getCityName().compareTo(info2.getCityName());
		}
	}

}
