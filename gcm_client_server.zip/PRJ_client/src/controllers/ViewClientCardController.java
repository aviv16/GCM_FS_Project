package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.ResourceBundle;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.jfoenix.controls.JFXButton;

import client.UserClient;
import entity.City;
import entity.Client;
import entity.ClientPurchase;
import entity.Purchase;
import entity.RegisteredUser;
import entity.Site;
import entity.SiteInTour;
import entity.SiteType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

public class ViewClientCardController extends OpenWindowClass implements Initializable {

	/**
	 * The class ViewClientCardController
	 *
	 */
	public static RegisteredUser user;
	Client client = new Client();
	public static RegisteredUser user1;// = LoginController.user;
	public static ArrayList<ClientPurchase> clientPurchasetArr;
	ConnectToServerClass conToServer;
	UserClient userClient;
	// QueryCommunicator Qcom;
	public ObservableList<fillClientPurcaseTable> ClientPurchaseList;

	public static int flag;
	public static int fillFlag;
	final Lock lock = new ReentrantLock();
	final Condition dbAvalibale = lock.newCondition();

	@FXML
	TextField userName;

	@FXML
	TextField firstName;

	@FXML
	TextField lastName;

	@FXML
	TextField phone;

	@FXML
	TextField email;

	@FXML
	TextField credit;

	@FXML
	TextField cvv;

	@FXML
	TextField month;

	@FXML
	TextField year;

	@FXML
	TableView<fillClientPurcaseTable> cityPurchaseTypeTable;

	@FXML
	TableColumn<fillClientPurcaseTable, String> cityNameColumn;

	@FXML
	TableColumn<fillClientPurcaseTable, String> purchaseTypeColumn;

	@FXML
	TableColumn<fillClientPurcaseTable, String> dateColumn;

	@FXML
	private JFXButton editBtn;

	/**
	 * initializes flags, an instance of userClient to keep trace and checks of
	 * which permission level the current account is to show relevant actions.
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		fillFlag = 0;
		flag = 0;
		QueryCommunicator Qcom;
		userClient = ConnectToServerClass.userClient;
		userClient.setViewClientCard(this);

		user1 = LoginController.user;
		if (user1.getPermission() == 3 || user1.getPermission() == 4) {
			editBtn.setVisible(false);
			Qcom = QueryCreator.getAllregistered_users(ManagerHomeController.client.getUserName());
			userClient.handleMessageFromClientUI(Qcom);
		} else {
			user = LoginController.user;
			setUserDetails();
			firstName.setEditable(true);
			lastName.setEditable(true);
			phone.setEditable(true);
			email.setEditable(true);
			credit.setEditable(true);
			cvv.setEditable(true);
			month.setEditable(true);
			year.setEditable(true);
		}
	}

	/**
	 * sets the current user to class static variable
	 * 
	 * @param types
	 */
	public void setUser(RegisteredUser c) {
		user = c;
		setUserDetails();
	}

	/**
	 * set all user details in relevant fields for client card view. the method also
	 * sends data queries in order to receive the client's payment info and his
	 * purchases history.
	 */
	public void setUserDetails() {
		userName.setText(user.getUserName());
		firstName.setText(user.getFirstName());
		lastName.setText(user.getLastName());
		phone.setText(user.getPhoneNumber());
		email.setText(user.getEmail());

		ClientPurchaseList = FXCollections.observableArrayList();
		cityNameColumn.setCellValueFactory(new PropertyValueFactory<fillClientPurcaseTable, String>("cityName"));
		cityNameColumn.setStyle("-fx-alignment: CENTER;");
		purchaseTypeColumn
				.setCellValueFactory(new PropertyValueFactory<fillClientPurcaseTable, String>("purchaseType_1_2"));
		purchaseTypeColumn.setStyle("-fx-alignment: CENTER;");
		dateColumn.setCellValueFactory(new PropertyValueFactory<fillClientPurcaseTable, String>("date"));
		dateColumn.setStyle("-fx-alignment: CENTER;");

		// ������ ������ �� ���� ������ �� ����
		QueryCommunicator Qcom = QueryCreator.getClient(user.getUserName());
		userClient.handleMessageFromClientUI(Qcom);
		// ������ ������� ���� �� �� ������� �� ����
		Qcom = QueryCreator.getClientbyName(user.getUserName());
		userClient.handleMessageFromClientUI(Qcom);
	}

	/**
	 * sets the client's payment info in the relevant on-screen fields. the method
	 * also sends a query in order to receive all client's purchases.
	 * 
	 * @param types
	 */
	public void setClient(ArrayList<Client> clientArr) {
		if (clientArr.size() != 0) {
			client.setCreditCardNumber(clientArr.get(0).getCreditCardNumber());
			client.setCvv(clientArr.get(0).getCvv());
			client.setExpirationDate(clientArr.get(0).getExpirationDate());

			if (user1.getPermission() == 1) {
				credit.setText(client.getCreditCardNumber());
				cvv.setText(client.getCvv());
				String string = client.getExpirationDate();
				String[] parts = string.split("(?=/)");
				String part1 = parts[0];
				String part2 = parts[1];
				month.setText(parts[0]);
				year.setText(parts[1].substring(1));
			} else {
				credit.setText("*********");
				cvv.setText("***");
				month.setText("**");
				year.setText("**");
			}

			QueryCommunicator Qcom = QueryCreator.getClientbyName(user.getUserName());
			userClient.handleMessageFromClientUI(Qcom);
		}
	}

	/**
	 * gets the desired user from the server. If don't exist, it's null. notify the
	 * login method to continue running
	 * 
	 * @param regUser
	 */
	public void setclientPurchaset(ArrayList<ClientPurchase> clientPurchasetArry) {
		clientPurchasetArr = clientPurchasetArry;
		if (clientPurchasetArr.size() > 0 && fillFlag == 0) {
			Collections.sort(clientPurchasetArr, new ClientPurchaseComperator());
			for (int i = 0; i < clientPurchasetArr.size(); i++) {
				fillClientPurcaseTable p = new fillClientPurcaseTable(clientPurchasetArr.get(i));
				ClientPurchaseList.add(p);
			}
			fillFlag = 1;
			cityPurchaseTypeTable.getItems().setAll(ClientPurchaseList);
		}
	}

	public void editDetails(ActionEvent event) throws IOException, InterruptedException {
		if (user1.getPermission() == 1) {
			QueryCommunicator Qcom = QueryCreator.UpdateReg(user.getUserName(), firstName.getText(), lastName.getText(),
					phone.getText(), email.getText());
			userClient.handleMessageFromClientUI(Qcom);
			Thread.sleep(4);
			Qcom = QueryCreator.UpdateClient(user.getUserName(), Integer.parseInt(credit.getText()),
					month.getText() + "/" + year.getText(), Integer.parseInt(cvv.getText()));
			userClient.handleMessageFromClientUI(Qcom);
			updateUser();
			popUpWindow("The changes are saved!");
		}
	}

	public void updateUser() {
		LoginController.user.setFirstName(firstName.getText());
		LoginController.user.setLastName(lastName.getText());
		LoginController.user.setEmail(email.getText());
		LoginController.user.setPhoneNumber(phone.getText());
	}

	public void back(ActionEvent event) throws IOException {
		if (user1.getPermission() == 1)
			openWindow(event, "Home", "application");
		else {
			openWindow(event, "ManagerHome", "application");

		}
	}

	public class fillClientPurcaseTable {
		String cityName;
		String purchaseType_1_2;
		String date;

		fillClientPurcaseTable(ClientPurchase client) {
			cityName = client.getCityName();
			if (client.getPurchaseType() == 1)
				purchaseType_1_2 = "one time";
			else
				purchaseType_1_2 = "subscribe";
			date = client.getDate();
		}

		public String getCityName() {
			return cityName;
		}

		public String getPurchaseType_1_2() {
			return purchaseType_1_2;
		}

		public String getDate() {
			return date;
		}
	}

}
