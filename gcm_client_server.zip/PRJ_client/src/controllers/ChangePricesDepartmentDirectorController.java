package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.ResourceBundle;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import client.UserClient;
import controllers.ViewClientCardController.fillClientPurcaseTable;
import entity.City;
import entity.ClientPurchase;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;

public class ChangePricesDepartmentDirectorController extends OpenWindowClass implements Initializable {

	/**
	 * The class ChangePricesDepartmentDirectorController
	 */
	@FXML
	TableView<fillCityTable> table;

	@FXML
	private TableColumn<fillCityTable, String> cityName;

	@FXML
	private TableColumn<fillCityTable, Double> price;

	@FXML
	private TableColumn<fillCityTable, String> newPrice;

	public ObservableList<fillCityTable> ClientPurchaseList;

	public static ArrayList<City> cityArr;
	ConnectToServerClass conToServer;
	UserClient userClient;
	QueryCommunicator Qcom;
	
	// *****SEMAPHORE
	/**
	 * Semaphore variables
	 */
	public static int flag = 0;
	final Lock lock = new ReentrantLock();
	final Condition dbAvalibale = lock.newCondition();

	/**
	 * sets instance of this controller in userClient to get data from server
	 * send query to get all cities and when receiving the list, fill the table.
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		table.refresh();
		userClient = ConnectToServerClass.userClient;
		userClient.setChangePricesDepartmentDirector(this);

		Qcom = QueryCreator.getCityQuery4();
		userClient.handleMessageFromClientUI(Qcom);
		flag=0;
		lock.lock();
		while (flag == 0)
			try {
				dbAvalibale.await();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		lock.unlock();
		// System.out.println("before");
		cityName.setCellValueFactory(new PropertyValueFactory<fillCityTable, String>("cityName"));
		cityName.setStyle("-fx-alignment: CENTER;");
		// System.out.println("after");
		price.setCellValueFactory(new PropertyValueFactory<fillCityTable, Double>("price"));
		price.setStyle("-fx-alignment: CENTER;");
		newPrice.setCellValueFactory(new PropertyValueFactory<fillCityTable, String>("newPrice"));
		newPrice.setStyle("-fx-alignment: CENTER;");

		if (cityArr != null) {
			Collections.sort(cityArr, new CityNameComperator());
			ArrayList<fillCityTable> temp = new ArrayList<>();
			for (int i = 0; i < cityArr.size(); i++) {
				fillCityTable p = new fillCityTable(cityArr.get(i));
				temp.add(p);
			}
			table.getItems().setAll(temp);
		}

		// ����� ����� �� ����� ���� �����
		table.setEditable(true);
		newPrice.setCellFactory(TextFieldTableCell.forTableColumn());

	}

	/**
	 * saves the changes in the database so that the company manager could see and approve
	 * @param event
	 * @throws IOException
	 */
	public void sendToConfirm(ActionEvent event) throws IOException {
		Qcom = QueryCreator.DeleteFromNewprice2();
		userClient.handleMessageFromClientUI(Qcom);

		// ���� �� ������ ������ �DB
		for (fillCityTable row : table.getItems()) {
			if (!(row.getNewPrice().equals(""))) {
				System.out.println(row.getCityName() + " " + row.getNewPrice());
				Qcom = QueryCreator.insertIntoNewprice(row.getCityName(), Double.parseDouble(row.getNewPrice()));
				userClient.handleMessageFromClientUI(Qcom);
			}
		}
		popUpWindow("New Prices Send To Confirm!");
		openWindow(event, "ManagerHome", "application");
	}

	/**
	 * cancels the changes
	 * @param event
	 * @throws IOException
	 */
	public void cancel(ActionEvent event) throws IOException {
		popUpWindow("Cancel!");
		openWindow(event, "ManagerHome", "application");
	}

	/**
	 *  save the new value that the worker change
	 * @param event
	 */
	public void onEditChange(CellEditEvent<fillCityTable, String> event) {
		fillCityTable f = table.getSelectionModel().getSelectedItem();
		f.setNewPrice(event.getNewValue());
	}

	/**
	 * get all cities from database
	 * @param cityArry
	 */
	public void setCity(ArrayList<City> cityArry) {
		lock.lock();
		cityArr = cityArry;
		flag = 1;
		dbAvalibale.signalAll();
		lock.unlock();
	}
	/**
	 * class to present all the relevant data in table
	 *
	 *
	 */
	public class fillCityTable {
		private String cityName;
		private Double price;
		private String newPrice;

		fillCityTable(City city) {
			cityName = city.getName();
			price = city.getRate();
			newPrice = "";
		}

		public String getCityName() {
			return cityName;
		}

		public void setCityName(String cityName) {
			this.cityName = cityName;
		}

		public Double getPrice() {
			return price;
		}

		public void setPrice(Double price) {
			this.price = price;
		}

		public String getNewPrice() {
			return newPrice;
		}

		public void setNewPrice(String newPrice) {
			this.newPrice = newPrice;
		}

	}
}