package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.UserClient;
import entity.City;
import entity.ClientPurchase;
import entity.Map;
import entity.Site;
import entity.SiteInTour;
import entity.Tour;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;


public class ViewCityInMapCatalogController extends OpenWindowClass implements Initializable {

	/**
	 * The class ViewCityInMapCatalogController
	 *
	 */
	public static City currentCity;
	UserClient userClient;
	public static Map selectedMap;

	ObservableList<Map> mapsObservable;

	@FXML
	Label cityName;

	@FXML
	Label numberOfSites;

	@FXML
	Label numberOfTours;

	@FXML
	Label numberOfMaps;

	@FXML
	TableView<Map> mapsTable;

	@FXML
	TableColumn<Map, Integer> IDColumn;

	@FXML
	TableColumn<Map, String> descriptionColumn;

	@FXML
	Button purchaseCollectionBtn;

	/**
	 * Overrides initialize method. initializes an instance of userClient to trace
	 * back responses from server. initializes class variables and types of values
	 * that will appear in the columns of the screen's table. the method also
	 * requests from server all maps of a certain city and all tours of a city as
	 * well.
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		userClient = ConnectToServerClass.userClient;
		userClient.setViewCityInMapCatalog(this);
		currentCity = SearchInCatalogController.chosenCity;
		cityName.setText(currentCity.getName());
		if (LoginController.user.getPermission() > 1) {
			purchaseCollectionBtn.setVisible(false);
		}
		if (SearchInCatalogController.allSites != null) {
			int sitesInCityCounter = 0;
			for (Site site : SearchInCatalogController.allSites) {
				if (site.getCityName().equals(currentCity.getName()))
					sitesInCityCounter++;
			}
			numberOfSites.setText("" + sitesInCityCounter);
		} else
			numberOfSites.setText("0");
		numberOfMaps.setText("0");// initialize
		numberOfTours.setText("0"); // initialize
		mapsObservable = FXCollections.observableArrayList();
		IDColumn.setCellValueFactory(new PropertyValueFactory<Map, Integer>("IDMap"));
		IDColumn.setStyle("-fx-alignment: CENTER;");
		descriptionColumn.setCellValueFactory(new PropertyValueFactory<Map, String>("textualDescription"));
		descriptionColumn.setStyle("-fx-alignment: CENTER;");
		QueryCommunicator Qcom = QueryCreator.getAllToursOfCityQuery2(currentCity.getName());
		userClient.handleMessageFromClientUI(Qcom);
		Qcom = QueryCreator.getMapByCityName(currentCity.getName());
		userClient.handleMessageFromClientUI(Qcom);

	}

	/**
	 * submits purchase when the "purchase" button is pressed. the method checks if
	 * the city is not already purchased by this user and whether this is a
	 * registered user or not.
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void purchase(ActionEvent event) throws IOException {
		if (LoginController.user != LoginController.undefinedUser) {
			if (LoginController.user.getPermission() != 1) {

			}
			for (ClientPurchase purchase : HomeController.allValidPurchases) {
				if (purchase.getCityName().equals(currentCity.getName())) {
					popUpWindow("You already purchased the maps of " + currentCity.getName());
					return;
				}
			}
			openWindow(event, "PurchaseSubscription", "application");
		} else {
			popUpWindow("Hey there, in order to purchase you must register :)");
		}
	}

	/**
	 * when the "back" button is pressed, returns to the previous "SearchInCatalog"
	 * screen.
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void back(ActionEvent event) throws IOException {

		openWindow(event, "SearchInCatalog", "application");
	}

	/**
	 * sets all maps of a city on a table.
	 * 
	 * @param mapArray
	 */
	public void fillMapTable(ArrayList<Map> mapArray) {
		for (Map map : mapArray) {
			mapsObservable.add(map);
		}
		mapsTable.getItems().setAll(mapsObservable);

		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				numberOfMaps.setText(Integer.toString(mapArray.size()));
			}
		});
	}

	/**
	 * sets the on-screen number of tours to show the number of tours exist in a
	 * certain city.
	 * 
	 * @param toursArray
	 */
	public void setNumberOfTours(ArrayList<Tour> toursArray) {

		Platform.runLater(new Runnable() {
			@Override
			public void run() {
				numberOfTours.setText(Integer.toString(toursArray.size()));
			}
		});
	}
}
