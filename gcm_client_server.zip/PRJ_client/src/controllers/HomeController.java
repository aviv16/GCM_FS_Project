package controllers;

import java.io.IOException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;

import client.UserClient;
import entity.City;
import entity.ClientPurchase;
import entity.Map;
import entity.RegisteredUser;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;

public class HomeController extends OpenWindowClass implements Initializable {

	/**
	 * The class HomeController
	 *
	 */
	RegisteredUser user = LoginController.user;
	ConnectToServerClass conToServer;
	UserClient userClient;
	QueryCommunicator Qcom;
	ArrayList<City> cities;
	public static City renewalCity;
	public static ArrayList<City> allRenewalCities;
	public static ArrayList<ClientPurchase> clientPurchasesForRenewal;
	public static ArrayList<ClientPurchase> allValidPurchases;
	String allUpdates;

	/**
	 * Sets the userClient from ConnectToServerClass to communicate with the server
	 * through it, and sends "this" to get feedback from the server
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		userClient = ConnectToServerClass.userClient;
		userClient.setHome(this);
		allRenewalCities = new ArrayList<City>();
		clientPurchasesForRenewal = new ArrayList<ClientPurchase>();
		allValidPurchases = new ArrayList<ClientPurchase>();
		QueryCommunicator Qcom = QueryCreator.getCityQuery6();
		userClient.handleMessageFromClientUI(Qcom);
	}

	@FXML
	Label renewLabel1;

	@FXML
	Label renewLabel2;

	@FXML
	Button renewBtn;

	@FXML
	Label updatesLabel;

	@FXML
	Label youHaveMessage;

	/**
	 * When "view Client Card" button is clicked, switches to client card page
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void viewClientCard(ActionEvent event) throws IOException {
		System.out.println("AAAAA");
		allRenewalCities.clear();
		clientPurchasesForRenewal.clear();
		openWindow(event, "ViewClientCard", "application");
	}

	/**
	 * When "log out" button is clicked, switches to login page
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void logOut(ActionEvent event) throws IOException {
		allRenewalCities.clear();
		clientPurchasesForRenewal.clear();
		Qcom = QueryCreator.logOutQuery(user.getUserName(), user.getPassword());
		userClient.handleMessageFromClientUI(Qcom);
		openWindow(event, "LogIn", "application");
	}

	/**
	 * When "view Cities Catalog" button is clicked, switches to login page
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void viewCitiesCatalog(ActionEvent event) throws IOException {
		allRenewalCities.clear();
		clientPurchasesForRenewal.clear();
		openWindow(event, "SearchInCatalog", "application");
	}

	/**
	 * "renewal" button press go to "RenewalPage" screen
	 * @param event
	 * @throws IOException
	 */
	public void renewal(ActionEvent event) throws IOException {
		openWindow(event, "RenewalPage", "application");
	}


	/**
	 *  Gets all cities that the client purchase from the DB
	 * @param allCities
	 */
	public void setCities(ArrayList<City> allCities) {
		System.out.println("city");
		cities = allCities;
		QueryCommunicator Qcom = QueryCreator.getClientPurchaseByName(LoginController.user.getUserName());
		userClient.handleMessageFromClientUI(Qcom);
	}

	/**
	 * handle renewals if client has subscription: sent message to  he to renewal, send massage about new virsion map.
	 * 
	 * @param purchases
	 */
	public void handleRenewals(ArrayList<ClientPurchase> purchases) {
		Date today = new Date();
		for (ClientPurchase purchase : purchases) {
			if ((purchase.getPurchaseType() == 2)) // subscription
			{
				if (dateInThreeDays(purchase, today) && (purchase.isUserSubscribed() == 0)) // 3 days until sub end and
																							// didn't get the message
																							// before
				{
					for (City city : cities) {
						if (city.getName().equals(purchase.getCityName())) {
							allRenewalCities.add(city);
							clientPurchasesForRenewal.add(purchase);
						}
					}
					renewLabel1.setVisible(true);
					renewLabel2.setVisible(true);
					renewBtn.setVisible(true);
					youHaveMessage.setVisible(false);
				}
				if (dateValid(purchase, today))// valid subscription
				{
					allValidPurchases.add(purchase);
				}
			}
		}
		if (allValidPurchases.size() != 0) {
			allUpdates = "There was an update to the following cities: ";
			for (ClientPurchase purch : allValidPurchases) {
				if ((purch.getUpToDate() == 1))// didn't see notification yet
				{
					allUpdates = allUpdates + purch.getCityName() + ",";
					QueryCommunicator Qcom = QueryCreator.SetUpdateZero(purch.getPurchaseNum()); // updates back to
																									// notify that the
																									// user seen the
																									// notification
					userClient.handleMessageFromClientUI(Qcom);
				}
			}
			if (!(allUpdates.equals("There was an update to the following cities: "))) {
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						updatesLabel.setText(allUpdates);
					}
				});

				updatesLabel.setVisible(true);
				youHaveMessage.setVisible(false);
			}
		}
	}

	/**
	 * upload purchase date and uploadDate of purchase
	 * @param purchaseDate
	 * @param uploadDate
	 * @return
	 */
	public boolean uploadAfterPurchase(String purchaseDate, String uploadDate) {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");
		try {
			Date purchased = formatter.parse(purchaseDate);
			Date upload = formatter.parse(uploadDate);
			if (purchased.before(upload)) {
				return true;
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * "renewal" button press go to "SubscriptionRenewal" screen.
	 * @throws IOException
	 */
	public void openRenewal() throws IOException {
		openWindowWithoutClosingCurrent("SubscriptionRenewal", "application");
	}

	/**
	 * Check if subscription of client expires within 3 days. 
	 * @param purchase
	 * @param today
	 * @return
	 */
	public boolean dateInThreeDays(ClientPurchase purchase, Date today) {
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yy");
		// String strDate = dateFormat.format(today);
		// System.out.println(strDate);

		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");
		try {
			Date purchased = formatter.parse(purchase.getDate());
			Calendar endDate = Calendar.getInstance();
			endDate.setTime(purchased);
			endDate.add(endDate.MONTH, purchase.getSubPeriod());
			String end = dateFormat.format(endDate.getTime());
			// System.out.println("end: "+end);
			Calendar checkInThreeDays = Calendar.getInstance();
			checkInThreeDays.setTime(today);
			checkInThreeDays.add(checkInThreeDays.HOUR, 72);
			String threeDays = dateFormat.format(checkInThreeDays.getTime());
			// System.out.println("three: "+threeDays);
			if (end.equals(threeDays)) // the requested date is before the end of subscription
			{
				return true;
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * check if requested date is before the end of subscription
	 * @param purchase
	 * @param today
	 * @return
	 */
	public boolean dateValid(ClientPurchase purchase, Date today) {
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yy");
		try {
			Date purchased = formatter.parse(purchase.getDate());
			Calendar endDate = Calendar.getInstance();
			endDate.setTime(purchased);
			endDate.add(endDate.MONTH, purchase.getSubPeriod());
			Calendar now = Calendar.getInstance();
			now.setTime(today);
			if (endDate.after(now)) // the requested date is before the end of subscription
			{
				return true;
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * When "view purchased maps" button is clicked, switches to login page
	 * 
	 * @param event
	 * @throws IOException
	 */

	@FXML
	void viewPurchasedMaps(ActionEvent event) throws IOException {
		openWindow(event, "ViewPurchasedCities", "application");
	}

	/**
	 * When "subscribe" button is clicked, switches to PurchaseSubscription page
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void subscribe(ActionEvent event) throws IOException {
		openWindow(event, "PurchaseSubscription", "application");
	}
	/**
	 * When "one time purchase" button is clicked, switches to login page
	 * 
	 * @param event
	 * @throws IOException
	 */
//		    public void oneTimePurchase(ActionEvent event) throws IOException {
//		    	openWindow(event,"ViewCityInMapCatalog","application");
//		    }

}
