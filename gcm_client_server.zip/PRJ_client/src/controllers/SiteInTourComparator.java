package controllers;

import java.util.Comparator;

import entity.SiteInTour;


public class SiteInTourComparator implements Comparator<SiteInTour>{

	/**
	 * The class SiteInTourComparator comparing between two serial number of site
	 *
	 */
	@Override
	public int compare(SiteInTour site1, SiteInTour site2) {
		return site1.getSerialNumber()-site2.getSerialNumber();
	}

}
