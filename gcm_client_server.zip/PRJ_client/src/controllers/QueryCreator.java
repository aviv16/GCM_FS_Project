package controllers;

import java.util.ArrayList;

import entity.SiteInMap;


public class QueryCreator {
	/**
	 * The class QueryCreator
	 *
	 */
//*************************************LOGIN AND REGISTRATION***************************************************************
	
	
	/**
	 * checks if a desired username of a new registered already exists
	 * @param userName
	 * @return QueryCommunicator
	 */
	
	public static QueryCommunicator checkExistUserQuery(String userName) {
	

		String query = "SELECT * FROM gcm.registered_users Where userName='" + userName + "'" + ";";
		QueryCommunicator QCom = new QueryCommunicator(query, "Registration");
		return QCom;
	}

	
	
	/**
	 * checks if a specific user is already connected to the system
	 * @param userName
	 * @return QueryCommunicator
	 */

	public static QueryCommunicator checkIfConnected(String userName) {

		String query = "SELECT userName FROM registered_users WHERE userName='" + userName + "' AND activeStatus='1';";
		QueryCommunicator QCom = new QueryCommunicator(query, "Login");
		return QCom;
	}

	
	
	/**
	 * when login succeed changes active status of user
	 * @param userName
	 * @param pass
	 * @return QueryCommunicator
	 */
	public static QueryCommunicator loginQuery(String userName, String pass) {

		String query = "UPDATE registered_users SET activeStatus = '1' WHERE userName='" + userName + "' AND password='"
				+ pass + "';";
		QueryCommunicator QCom = new QueryCommunicator(query, "Login");
		return QCom;
	}

	
	/** 
	 * checks if a user exists in order to login
	 * @param userName
	 * @param pass
	 * @return QueryCommunicator
	 */
	public static QueryCommunicator IsLoginInfoExist(String userName, String pass) {
		String query = "SELECT * FROM gcm.registered_users Where userName='" + userName + "'" + " AND password='" + pass
				+ "'" + ";";
		QueryCommunicator QCom = new QueryCommunicator(query, "Login");
		return QCom;
	}
	

	
	
	/**
	 * insert a new registered user to the DB into tables: registered_users & client
	 * @param firstName
	 * @param lastName
	 * @param userName
	 * @param password
	 * @param phoneNumber
	 * @param email
	 * @param creditCardNumber
	 * @param CVV
	 * @param expireDate
	 * @param permission
	 * @param activeStatus
	 * @return QueryCommunicator
	 */
	public static ArrayList<QueryCommunicator> registerNewUserQuery(String firstName, String lastName, String userName,
			String password, String phoneNumber, String email, String creditCardNumber, String CVV, String expireDate,
			int permission, int activeStatus) {
		ArrayList<QueryCommunicator> QComArr = new ArrayList<QueryCommunicator>();
		String query = "INSERT INTO registered_users VALUES (\'" + userName + "\', \'" + password + "\', \'" + firstName
				+ "\', \'" + lastName + "\', \'" + phoneNumber + "\', \'" + email + "\', " + permission + ", "
				+ activeStatus + ");";
		String query2 = "INSERT INTO client VALUES (\'" + userName + "\'," + creditCardNumber + ", \'" + expireDate
				+ "\', " + CVV + ");";
		QComArr.add(new QueryCommunicator(query, "Registration"));
		QComArr.add(new QueryCommunicator(query2, "Registration"));
		return QComArr;
	}
//*************************************************SEARCH IN CATALOG*************************************

	
	
	/**
	 * Returns all cities objects
	 * @return QueryCommunicator
	 */
	public static QueryCommunicator getCityQuery() {

		String query = "SELECT * FROM city;";
		QueryCommunicator QCom = new QueryCommunicator(query, "SearchInCatalog");
		return QCom;
	}
	
	
/**
 * Return all maps which their description contains the description searched or part of it
 * @param description
 * @return QueryCommunicator
 */
	
	public static QueryCommunicator searchCityByDescriptionQuery(String description) {

		String query = "SELECT * FROM map WHERE description LIKE \'%"+description+"%\';";
		QueryCommunicator QCom = new QueryCommunicator(query, "SearchInCatalog");
		return QCom;
	}
	
	/** 
	 * Return all sites which their description contains the description searched or part of it
	 * @param description
	 * @return QueryCommunicator
	 */
		public static QueryCommunicator searchSiteByDescriptionQuery(String description) {

			String query = "SELECT * FROM site WHERE description LIKE \'%"+description+"%\';";
			QueryCommunicator QCom = new QueryCommunicator(query, "SearchInCatalog");
			return QCom;
		}

	
		
		/** 
		 *  Returns all sites
		 * @return QueryCommunicator
		 */
		public static QueryCommunicator getAllSitesQuery() {

			String query = "SELECT * FROM site;";
			QueryCommunicator QCom = new QueryCommunicator(query, "SearchInCatalog");
			return QCom;
		}


	// ************************************************* EDIT CITY***************************************

		
		/** 
		 * Returns all sites of a certain city
		 * @param cityName
		 * @return QueryCommunicator
		 */
		public static QueryCommunicator getAllSitesOfCityQuery(String cityName) {

			String query = "SELECT * FROM site WHERE cityNamefk='" + cityName + "';";
			QueryCommunicator QCom = new QueryCommunicator(query, "EditCity");
			return QCom;
		}
		
		
		
		/** 
		 *  Returns all tours of a certain city
		 * @param cityName
		 * @return QueryCommunicator
		 */
	public static QueryCommunicator getAllToursOfCityQuery(String cityName) {

		String query = "SELECT * FROM tour WHERE cityName='" + cityName + "';";
		QueryCommunicator QCom = new QueryCommunicator(query, "EditCity");
		return QCom;
	}
	
	
	
	/** 
	 *  delete site
	 * @param siteName
	 * @param cityName
	 * @return QueryCommunicator
	 */
	public static QueryCommunicator deleteSite(String siteName, String cityName)//��� �������� ����� ���  
	{
		String query="DELETE FROM site WHERE siteName=\'"+siteName+"\' AND cityNamefk=\'"+cityName+"\';";
		QueryCommunicator QCom = new QueryCommunicator(query,"EditCity");
		return QCom;
		
	}
	
	
	/** 
	 *  delete tour
	 * @param tourID
	 * @return QueryCommunicator
	 */
	public static QueryCommunicator deleteTour(int tourID)//����� ����  
	{
		String query="DELETE FROM tour WHERE tourID="+tourID+";";
		QueryCommunicator QCom = new QueryCommunicator(query,"EditCity");
		return QCom;
		
	}
	
	
	
	
	/** 
	 *  delete site_in_tour
	 * @param tourID
	 * @return QueryCommunicator
	 */
	public static QueryCommunicator deleteSiteFromTour(int tourID)// ���� ��� �����  
	{
		String query="DELETE FROM site_in_tour WHERE tourID="+tourID+";";
		QueryCommunicator QCom = new QueryCommunicator(query,"EditCity");
		return QCom;
		
	}
	
	//**********************************************AddCity***********************************

	
	
	/** 
	 * Returns all tours of a certain city
	 * @param cityName
	 * @param price
	 * @return QueryCommunicator
	 */
	public static QueryCommunicator AddCityQuery(String cityName, int price) {

		String query = "INSERT INTO city VALUES (\'" + cityName + "\'," + price + ");";
		//QueryCommunicator QCom = new QueryCommunicator(query, "EditCity");
		QueryCommunicator QCom = new QueryCommunicator(query, "AddCity");
		return QCom;
	}
	
	
	
	/** 
	 * Returns a specific city
	 * @param cityName
	 * @return QueryCommunicator
	 */
		public static QueryCommunicator getCityList(String cityName) {

			String query = "SELECT * FROM city WHERE cityName=\'"+cityName+"\';";
			QueryCommunicator QCom = new QueryCommunicator(query, "AddCity");
			return QCom;
		}
	
		
		
		/** 
		 * adds a new report when we add a new city
		 * @param cityName
		 * @param date
		 * @return QueryCommunicator
		 */
		public static QueryCommunicator insertReport(String cityName,String date) {

			String query = "INSERT INTO report VALUES (\'"+cityName+"\',\'"+date+"\',0,0);";
			QueryCommunicator QCom = new QueryCommunicator(query, "AddCity");
			return QCom;
		}

	// ******************************************************ADD TOUR TO CITY*****************************************************
	
		
		/** 
		 * adds a new tour to a city(only on tour table-not sites)
		 * @param description
		 * @param cityName
		 * @return QueryCommunicator
		 */
		public static QueryCommunicator AddTourToCityQueryInAddTour(String description, String cityName) {
			String query = "INSERT INTO tour(cityName,description) VALUES (\'" + cityName + "\',\'" + description + "\');";
			QueryCommunicator QCom = new QueryCommunicator(query,"AddTourToCity");
			return QCom;
		}
		
		
		/**
		 * Selects a tour with the maximum number of a particular city
		 * @param cityName QueryCommunicator
		 * @return QueryCommunicator
		 */
		public static QueryCommunicator getIDofCreatedTour(String cityName)
	{
		String query="SELECT * FROM tour WHERE tourID=(SELECT MAX(tourID) FROM tour WHERE cityName=\'"+cityName+"\');";
		QueryCommunicator QCom = new QueryCommunicator(query,"AddTourToCity");
		return QCom;
	}
		
		
		/**
		 * adds sites to a tour(on site_in_tour table)
		 * @param tourID
		 * @param cityName
		 * @param siteName
		 * @param serialNum
		 * @param duration
		 * @return QueryCommunicator
		 */
	
		public static QueryCommunicator AddSitesToCityTourQueryInAddTour(int tourID, String cityName,
					String siteName,int serialNum,int duration)
		{
			String query="INSERT INTO site_in_tour VALUES ("+tourID+",\'"+cityName+"\',\'"+siteName+"\',"+serialNum+","+duration+");";
			QueryCommunicator QCom = new QueryCommunicator(query,"AddTourToCity");
			return QCom;
		}
		
	

	
	// ******************************************************EDIT SITE CONTENT****************************************************
		
		
	/**
	 * Returns specific site's info
	 * @param siteName
	 * @return QueryCommunicator
	 */
	
	public static QueryCommunicator getSiteInfoQuery(String siteName) {

		String query = "SELECT * FROM site WHERE siteName=\'"+siteName+"\';";
		QueryCommunicator QCom = new QueryCommunicator(query, "EditSite");
		return QCom;
	}
	
	
	/**
	 * Updates site's info
	 * @param siteName
	 * @param cityName
	 * @param classification
	 * @param description
	 * @param accessability
	 * @return QueryCommunicator
	 */
	
	public static QueryCommunicator updateSiteInfoQuery(String siteName,String cityName,String classification,String description,String accessability) {

		String query = "UPDATE site SET classification=\'"+classification+"\', description=\'"+description+"\', accessability=\'"+accessability+"\' WHERE  siteName=\'"+siteName+"\' AND cityNamefk=\'"+cityName+"\';";
		QueryCommunicator QCom = new QueryCommunicator(query, "EditSite");
		return QCom;
	}
	
	
	/**
	 * Returns a list of site type names
	 * @return QueryCommunicator
	 */
	
	public static QueryCommunicator getSiteType() {

		String query = "SELECT * FROM site_type";
		QueryCommunicator QCom = new QueryCommunicator(query,"EditSite");
		return QCom;
	}
	// ******************************************************ADD SITE****************************************************
	/**
	 * Returns a list of site type names
	 * @return QueryCommunicator
	 */
		public static QueryCommunicator getSiteType2() {

			String query = "SELECT * FROM site_type";
			QueryCommunicator QCom = new QueryCommunicator(query,"AddSite");
			return QCom;
		}
		
		/**
		 * add a new site to city
		 * @param siteName
		 * @param cityNamefk
		 * @param classification
		 * @param description
		 * @param accessability
		 * @return QueryCommunicator
		 */
				public static QueryCommunicator addSite(String siteName,String cityNamefk,String classification,String description,String accessability) {

					String query = "INSERT INTO site VALUES (\'"+siteName+"\',\'"+cityNamefk+"\',\'"+classification+"\',\'"+description+"\',\'"+accessability+"\');";
					QueryCommunicator QCom = new QueryCommunicator(query,"AddSite");
					return QCom;
				}
	// *****************************************����� �� ���������*************ADD MAP TO CITY***************************************************
		//attaches a map to a specific city
		/*public static QueryCommunicator addMapToCityQuery(int mapID,int version,String cityName,String description) {

			String query="INSERT INTO map VALUES (\'"+cityName+"\',"+mapID+","+version+",\'"+description+"\');";
			QueryCommunicator QCom = new QueryCommunicator(query,"EditMap");
			return QCom;
		}
		*/
	//****************EditTourInCity***************
				
	    /**
	     * delete site_in_tour
	     * @param tourID
	     * @param cityName
	     * @param siteName
	     * @return QueryCommunicator
	     */
		public static QueryCommunicator deleteSiteInTour(int tourID,String cityName,String siteName)//����� ��� �����
		{
			String query="DELETE FROM site_in_tour WHERE tourID="+tourID+" and cityName=\'"+cityName+"\' and siteName=\'"+siteName+"\';";
			QueryCommunicator QCom = new QueryCommunicator(query,"EditTourInCity");
			return QCom;
			
		}
		
		
		/**
		 * get all site_in_tour of a specific city
		 * @param tourID
		 * @param cityName
		 * @return QueryCommunicator
		 */
		public static QueryCommunicator getSitesInSpecificTour(int tourID,String cityName)//������ ����� �� ���� ������
		{
			String query="SELECT * FROM site_in_tour WHERE cityName=\'"+cityName+"\' and tourID="+tourID+";";
			QueryCommunicator QCom = new QueryCommunicator(query,"EditTourInCity");
			return QCom;
			
		}
		
		
		/**
		 * add site_in_tour
		 * @param tourID
		 * @param cityName
		 * @param siteName
		 * @param serialNum
		 * @param duration
		 * @return QueryCommunicator
		 */
		public static QueryCommunicator AddSitesToCityTourQueryInEditTour(int tourID, String cityName,
				String siteName,int serialNum,int duration)
		{
		String query="INSERT INTO site_in_tour VALUES ("+tourID+",\'"+cityName+"\',\'"+siteName+"\',"+serialNum+","+duration+");";
		QueryCommunicator QCom = new QueryCommunicator(query,"EditTourInCity");
		return QCom;
		}
		
		
		
		/**
		 * update site_in_tour of a specific city
		 * @param tourID
		 * @param cityName
		 * @param siteName
		 * @param serialNum
		 * @param duration
		 * @return QueryCommunicator
		 */
		//����� ��� ������
		public static QueryCommunicator EditSiteInTourQuery(int tourID, String cityName,String siteName,int serialNum,int duration)
	{
		String query="UPDATE site_in_tour SET tourID= "+tourID+",cityName=\'"+cityName+"\',siteName=\'"+siteName+"\', serialNumber="+serialNum+", visitDuration="+duration+" WHERE cityName=\'"+cityName+"\'and siteName=\'"+siteName+"\' and tourID="+tourID+";";
		QueryCommunicator QCom = new QueryCommunicator(query,"EditTourInCity");
		return QCom;
	}
		
		
		/**
		 * update tour
		 * @param tourID
		 * @param description
		 * @return QueryCommunicator
		 */
		//����� �����
		public static QueryCommunicator EditTour(int tourID, String description)
	{
		String query="UPDATE tour SET description=\'"+description+"\' WHERE tourID="+tourID+";";
		QueryCommunicator QCom = new QueryCommunicator(query,"EditTourInCity");
		return QCom;
	}
		
		
		
		//****************EditMapWithPic***************
		
		/**
		 * update DeleteDate of map 
		 * @param DeleteDate
		 * @param mapID
		 * @return QueryCommunicator
		 */
		public static QueryCommunicator deleteMap(String DeleteDate ,int mapID)
		{
			String query="UPDATE map SET DeleteDate=\'"+DeleteDate+"\' WHERE mapID="+mapID+";";//����� ���
			QueryCommunicator QCom = new QueryCommunicator(query,"EditMapWithPic");
			return QCom;
		}
		
		
		/**
		 * link map to city
		 * @param mapID
		 * @param cityName
		 * @return QueryCommunicator
		 */
		public static QueryCommunicator LinkmapToCity(int mapID,String cityName)//���� ��� ���� �� ���� ��� ��� ���� ������ ���
		{
			String query="UPDATE map SET cityName=\'"+cityName+"\' WHERE mapID="+mapID+";";
			QueryCommunicator QCom = new QueryCommunicator(query,"EditMapWithPic");
			return QCom;
		}
		
		
		/**
		 * return specific map
		 * @param mapID
		 * @return QueryCommunicator
		 */
		public static QueryCommunicator getMap(int mapID)
		{
			String query="SELECT * FROM map WHERE mapID="+mapID+";";//����� ��� ��� ���� ���
			QueryCommunicator QCom = new QueryCommunicator(query,"EditMapWithPic");
			return QCom;
		}
		
		
		
		/** 
		 * Returns all cities objects
		 * @param userName
		 * @return QueryCommunicator
		 */
		public static QueryCommunicator getCityQuery2() {

			String query = "SELECT * FROM city;";
			QueryCommunicator QCom = new QueryCommunicator(query,"EditMapWithPic");
			return QCom;
		}
		
	    /**
	     * /Returns specific site's info
	     * @param cityName
	     * @return QueryCommunicator
	     */
		public static QueryCommunicator getSitelistQuery2(String cityName) {//����� ����� ����� �� ��� �������

			String query = "SELECT * FROM site WHERE cityNamefk=\'"+cityName+"\';";
			QueryCommunicator QCom = new QueryCommunicator(query, "EditMapWithPic");
			return QCom;
		}
		
		
		/**
		 * adds a new row to site_in_map table
		 * @param siteInMap
		 * @return QueryCommunicator
		 */
		public static QueryCommunicator addSiteInMapQuery(SiteInMap siteInMap) {
			String query = "INSERT INTO site_in_map VALUES ("+ siteInMap.getmapID() +","+ siteInMap.getMapVersion()+",\'"+siteInMap.getSiteName()+"\',"+siteInMap.getxOnMap()+","+siteInMap.getyOnMap()+");";
			QueryCommunicator QCom = new QueryCommunicator(query, "EditMapWithPic");
			return QCom;
		}
		
		
		/**
		 * returns all sites_in_map of a certain map
		 * @param mapID
		 * @param version
		 * @return QueryCommunicator
		 */
				public static QueryCommunicator getAllSitesOfMapQuery(int mapID,int version) {

					String query = "SELECT * FROM site_in_map WHERE mapID=" + mapID + " and mapVersion=" +version+ ";";
					QueryCommunicator QCom = new QueryCommunicator(query, "EditMapWithPic");
					return QCom;
				}
				
				/**
				 * Returns a specific map with a zero deletion date
				 * @param mapID
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getmapWhereDeleteDateZero(int mapID) {//����� ��� ����� �� ����� ����� 0

					String query = "SELECT * from map where mapID="+mapID+" and DeleteDate='0';";
					QueryCommunicator QCom = new QueryCommunicator(query, "EditMapWithPic");
					return QCom;
				}
		
		
				//*************************ORI****************************
				
				/**
				 * Returns a specific map that has no upload date
				 * @param mapID
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getMepWithoutUploadDate(int mapID) {//������ ��� ���� ���� �� ����� �����

					String query = "SELECT * from map where mapID="+mapID+" and UploadDate is null;";
					QueryCommunicator QCom = new QueryCommunicator(query, "EditMapWithPic");
					return QCom;
				}
				
				/**
				 * Change map edit status
				 * @param mapID
				 * @param version
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator UpdateEditTo1(int mapID,int version) {//���� ����� ����� �0 � 1

					String query = "UPDATE map SET isEditing = '1' WHERE mapID=" + mapID+ " AND version="+version+";";
					QueryCommunicator QCom = new QueryCommunicator(query, "EditMapWithPic");
					return QCom;
				}
				
				/**
				 * Change map edit status
				 * @param mapID
				 * @param version
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator UpdateEditTo0(int mapID,int version) {//���� ����� ����� �1 � 0

					String query = "UPDATE map SET isEditing = '0' WHERE mapID=" + mapID+ " AND version="+version+";";
					QueryCommunicator QCom = new QueryCommunicator(query, "EditMapWithPic");
					return QCom;
				}
				
				
				/**
				 * change SentApproval status
				 * @param mapID
				 * @param version
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator UpdateSendTo1(int mapID,int version) {//���� ����� ����� �0 � 1

					String query = "UPDATE map SET isSentApproval = '1' WHERE mapID=" + mapID+ " AND version="+version+";";
					QueryCommunicator QCom = new QueryCommunicator(query, "EditMapWithPic");
					return QCom;
				}
				
				
				/**
				 * delete specific site_in_map
				 * @param mapID
				 * @param mapVersion
				 * @param siteName
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator DeleteSiteInMap(int mapID,int mapVersion,String siteName) {//����� ��� ����

					String query = "DELETE FROM site_in_map WHERE mapID="+mapID+" and mapVersion="+mapVersion+" and siteName=\'"+siteName+"\';";
					QueryCommunicator QCom = new QueryCommunicator(query, "EditMapWithPic");
					return QCom;
				}
				
				
				/**
				 * adds a new row to site_in_map table
				 * @param siteInMap
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator InsertSiteInMap(int mapID,int mapVersion,String siteName,double xOnMap,double yOnMap) {//����� ��� ����

					String query = "INSERT INTO site_in_map VALUES (" + mapID + "," + mapVersion + ", \'" +siteName+ "\', " + xOnMap+ ","+yOnMap  +");";
					QueryCommunicator QCom = new QueryCommunicator(query, "EditMapWithPic");
					return QCom;
				}
				
				
				/**
				 * update specific site_in_map
				 * @param mapID
				 * @param mapVersion
				 * @param siteName
				 * @param xOnMap
				 * @param yOnMap
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator UpdatetSiteInMap(int mapID,int mapVersion,String siteName,double xOnMap,double yOnMap) {//����� ��� ����

					String query = "UPDATE site_in_map SET xOnMap= "+xOnMap+", yOnMap="+yOnMap+" WHERE siteName= \'" + siteName+"\' and mapID="+mapID+" and mapVersion="+mapVersion+";";
					QueryCommunicator QCom = new QueryCommunicator(query, "EditMapWithPic");
					return QCom;
				}
				
				/**
				 * change status  upToDate of client_purchase of specific city
				 * @param cityName
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator updateUpToDate(String cityName) {//����� �� �� ��� ����� ��� ������� ��� �� ���� ��� � 0

					String query = "UPDATE client_purchase SET upToDate = '1' WHERE cityName=\'"+cityName+"\';";
					QueryCommunicator QCom = new QueryCommunicator(query,"EditMapWithPic");
					return QCom;
				}
				
	//*************************************************ManagerHome***********************************************
				
				/**
				 * Returns all maps that sent for approval
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getmapWhereisSentApprovalOne() {//����� �� �� ����� ������ ������

					String query = "SELECT * from map where isSentApproval='1';";
					QueryCommunicator QCom = new QueryCommunicator(query, "ManagerHome");
					return QCom;
				}
				
				
				/**
				 * returns all newprice
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getnewPrice1() {

					String query = "SELECT * FROM newprice;";//����� �� ����� ����� �� ������� ������
					QueryCommunicator QCom = new QueryCommunicator(query, "ManagerHome");//������ �� �� ������ ����
					return QCom;
				}
				
				
				/**
				 * returns all client
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getAllClient() {

					String query ="SELECT * FROM client;";
					QueryCommunicator QCom = new QueryCommunicator(query, "ManagerHome");
					return QCom;
			}
				
				
	//************************************************MapApproval*************************************************			
				
				/**
				 * change SentApproval status
				 * @param mapID
				 * @param version
				 * @return QueryCommunicator 
				 */
				public static QueryCommunicator UpdateSendTo0(int mapID,int version) {//���� ����� ����� �1 � 0

					String query = "UPDATE map SET isSentApproval = '0' WHERE mapID=" + mapID+ " AND version="+version+";";
					QueryCommunicator QCom = new QueryCommunicator(query, "MapApproval");
					return QCom;
				}
				
				/**
				 * update specific map
				 * @param mapID
				 * @param version
				 * @param DeleteDate
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator SetDeleteDate(int mapID,int version,String DeleteDate) {//������ ����� ����� ����

					String query = "UPDATE map SET DeleteDate= \'"+DeleteDate+"\' WHERE mapID= "+ mapID+" and mapID="+mapID+" and version="+version+";";
					QueryCommunicator QCom = new QueryCommunicator(query, "MapApproval");
					return QCom;
				}
				
				/**
				 * return all site_in_map  of specific map 
				 * @param mapID
				 * @param mapVersion
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getSiteInMap(int mapID,int mapVersion) {//������ �� �� ������ �� ���� ����

					String query = "SELECT * from site_in_map where mapID="+mapID+" and mapVersion="+mapVersion+";";
					QueryCommunicator QCom = new QueryCommunicator(query, "MapApproval");
					return QCom;
				}
				
				
				/**
				 * add new map
				 * @param mapID
				 * @param version
				 * @param cityName
				 * @param description
				 * @param UploadDate
				 * @param DeleteDate
				 * @param isEditing
				 * @param isSentApproval
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator InsertDetailsMap(int mapID,int version,String cityName,String description,String UploadDate,String DeleteDate,int isEditing,int isSentApproval) {//����� ��� ���� �� �� ������ ���

					String query = "INSERT INTO map(mapID,version,cityName,description,UploadDate,DeleteDate,isEditing,isSentApproval)VALUES ("+mapID+","+version+",\'"+cityName+"\',\'"+description+"\',\'"+UploadDate+"\',\'"+DeleteDate+"\',"+isEditing+","+isSentApproval+");";
					QueryCommunicator QCom = new QueryCommunicator(query, "MapApproval");
					return QCom;
				}
				
				/**
				 * add picture to specific map
				 * @param mapID
				 * @param version
				 * @param cityName
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator InsertFileMap(int mapID,int version,String cityName) {//����� ���� ����
					String query = "UPDATE map SET mapFile= ?"+" WHERE mapID="+mapID+" and version="+version+";";
					QueryCommunicator QCom = new QueryCommunicator(query, "MapApproval");
					QCom.setFilename(cityName+mapID+".png");
					return QCom;
				}
		
		//****************AddTypeToSite***************
				
				/**
				 * add site type
				 * @param siteTypeName
				 * @return QueryCommunicator
				 */
		public static QueryCommunicator addSiteType(String siteTypeName)
		{
			String query="INSERT INTO site_type VALUES (\'"+siteTypeName+"\');";
			QueryCommunicator QCom = new QueryCommunicator(query,"AddTypeToSite");
			return QCom;
		}
		//****************HOME***************
		
		/**
		 * UPDATE registered_users when he logoff
		 * @param userName
		 * @param pass
		 * @return QueryCommunicator
		 */
				public static QueryCommunicator logOutQuery(String userName, String pass) {

					String query = "UPDATE registered_users SET activeStatus = '0' WHERE userName='" + userName + "' AND password='"
							+ pass + "';";
					QueryCommunicator QCom = new QueryCommunicator(query, "Home");
					return QCom;
				}
				
				/**
				 * return all client_purchase of specific client
				 * @param userName
				 * @return QueryCommunicator
				 */
				
				public static QueryCommunicator getClientPurchaseByName(String userName) {//������ ���� ������ �������� ��� �� ���� 

					String query = "SELECT * FROM client_purchase WHERE userName=\'" + userName + "\';";
					QueryCommunicator QCom = new QueryCommunicator(query, "Home");
					return QCom;
				}
				
				
				/** 
				 * Returns all cities objects
				 * @param userName
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getCityQuery6() {

					String query = "SELECT * FROM city;";
					QueryCommunicator QCom = new QueryCommunicator(query,"Home");
					return QCom;
				}
				
				
				/**
				 * update userSubscribed status in client_purchase
				 * @param purchaseNum
				 * @return QueryCommunicator
				 */
				
				public static QueryCommunicator updateUserSubscribed(int purchaseNum) {//����� � 1 �� ��� ���� �� ����� �� ����� ����

					String query = "UPDATE client_purchase SET userSubscribed = '1' WHERE purchaseNum="+ purchaseNum +";";
					QueryCommunicator QCom = new QueryCommunicator(query,"Home");
					return QCom;
				}
				
				/**
				 * return all  maps that was deleted
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getMapsDelIs0() {//������ �� �� ����� ������ ������ ����=0 

					String query = "SELECT * FROM map WHERE DeleteDate='0';";
					QueryCommunicator QCom = new QueryCommunicator(query, "Home");
					return QCom;
				}
				
				/**
				 * update upToDate status of specific client_purchase
				 * @param purchaseNum
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator SetUpdateZero(int purchaseNum) {//����� �� ������ ��� � 0 ������ ����

					String query = "UPDATE client_purchase SET upToDate = '0' WHERE purchaseNum="+ purchaseNum +";";
					QueryCommunicator QCom = new QueryCommunicator(query, "Home");
					return QCom;
				}
		//******************************************EmployeeHome***********************
				/**
				 * update  registered_users when he logout
				 * @param userName
				 * @param pass
				 * @return
				 */
				public static QueryCommunicator logOutQuery2(String userName, String pass) {

					String query = "UPDATE registered_users SET activeStatus = '0' WHERE userName='" + userName + "' AND password='"
							+ pass + "';";
					QueryCommunicator QCom = new QueryCommunicator(query, "EmployeeHome");
					return QCom;
				}
				
		//**************************ViewClientCard*************************
				
				/**
				 * return a specific client
				 * @param userName
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getClient(String userName) {//������ ���� ��������

					String query = "SELECT * FROM client WHERE userName=\'" + userName + "\';";
					QueryCommunicator QCom = new QueryCommunicator(query, "ViewClientCard");
					return QCom;
				}
				
				/**
				 * select all purchase of specific client
				 * @param userName
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getClientbyName(String userName) {//������ ���� ������ �������� ��� �� ������

					String query = "SELECT * FROM client_purchase WHERE userName=\'" + userName + "\';";
					QueryCommunicator QCom = new QueryCommunicator(query, "ViewClientCard");
					return QCom;
				}
				
				
				/**
				 * return all client_purchase
				 * @param userName
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getClientPurchase(String userName) {//������ ���� ������ �� ������ 

					String query = "SELECT * FROM client_purchase;";
					QueryCommunicator QCom = new QueryCommunicator(query, "ViewClientCard");
					return QCom;
				}
				
				/**
				 * UPDATE specific registered_users
				 * @param userName
				 * @param firstName
				 * @param lastName
				 * @param phoneNumber
				 * @param email
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator UpdateReg(String userName,String firstName,String lastName,String phoneNumber,String email)
				{

					String query = "UPDATE registered_users SET firstName= \'" + firstName+ "\',lastName= \'" + lastName + "\', phoneNumber=\'" + phoneNumber + "\',email= \'" + email + "\' WHERE userName= \'" + userName+"\';";
					QueryCommunicator QCom = new QueryCommunicator(query, "ViewClientCard");
					return QCom;
				}
				
				
				/**
				 * UPDATE specific client
				 * @param userName
				 * @param creditCardNum
				 * @param expirationDate
				 * @param CVV
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator UpdateClient(String userName,int creditCardNum,String expirationDate,int CVV)
				{

					String query = "UPDATE client SET creditCardNum= " +creditCardNum+ ",expirationDate= \'" +expirationDate + "\', CVV=" + CVV + " WHERE  userName=\'"+userName+"\';";
					QueryCommunicator QCom = new QueryCommunicator(query, "ViewClientCard");
					return QCom;
				}
				
				
				/**
				 * return specific registered_users
				 * @param userName
				 * @return QueryCommunicator
				 */
				
				public static QueryCommunicator getAllregistered_users(String userName) {

					String query = "SELECT * FROM registered_users WHERE userName=\'" + userName +"\';";
					QueryCommunicator QCom = new QueryCommunicator(query, "ViewClientCard");
					return QCom;
				}

				
				//**************************ViewCityInMapCatalog*************************
				
				/**
				 * return maps of specific city that deleted
				 * @param cityName
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getMapByCityName(String cityName) //����� ���� ���� ��� �� ��� ������ ������ ����=0
				{
					String query="SELECT * FROM map WHERE cityName=\'" + cityName + "\' and DeleteDate='0';";
					QueryCommunicator QCom = new QueryCommunicator(query,"ViewCityInMapCatalog");
					return QCom;
				}
				
				/**
				 * Returns all tours of a certain city
				 * @param cityName
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getAllToursOfCityQuery2(String cityName) {

					String query = "SELECT * FROM tour WHERE cityName='" + cityName + "';";
					QueryCommunicator QCom = new QueryCommunicator(query, "ViewCityInMapCatalog");
					return QCom;
				}
				//*********PurchaseSubscription********
				/**
				 * add client_purchase
				 * @param userName
				 * @param date
				 * @param purchaseType
				 * @param discount
				 * @param cityName
				 * @param subRenewal
				 * @param userSubscribed
				 * @param subPeriod
				 * @param upToDate
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator insertClientPurchase(String userName,String date,int purchaseType,int discount,String cityName,int subRenewal,int userSubscribed,int subPeriod,int upToDate) {

					String query = "INSERT INTO client_purchase (userName,date,purchaseType,discount,cityName,subRenewal,userSubscribed,subPeriod,upToDate) VALUES (\'"+userName+"\',\'"+date+"\',"+purchaseType+","+discount+",\'"+cityName+"\',"+subRenewal+","+userSubscribed+","+subPeriod+","+upToDate+");";
					QueryCommunicator QCom = new QueryCommunicator(query, "PurchaseSubscription");
					return QCom;
				}
				
				
				/**
				 * Returns all tours of a certain city
				 * @param cityName
				 * @return QueryCommunicator
				 */
		
				public static QueryCommunicator getAllToursOfCityQuery3(String cityName) {

					String query = "SELECT * FROM tour WHERE cityName='" + cityName + "';";
					QueryCommunicator QCom = new QueryCommunicator(query, "PurchaseSubscription");
					return QCom;
				}
				
				/**
				 * Returns specific site's info
				 * @param cityName
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getSitelistQuery(String cityName) {//����� ����� ����� �� ��� �������

					String query = "SELECT * FROM site WHERE cityNamefk=\'"+cityName+"\';";
					QueryCommunicator QCom = new QueryCommunicator(query, "PurchaseSubscription");
					return QCom;
				}
				
				/**
				 * return all site_in_tour of specific tour
				 * @param tourID
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getSitesInSpecificTour2(int tourID)//������ ����� �� ���� ������
				{
					String query="SELECT * FROM site_in_tour WHERE tourID="+tourID+";";
					QueryCommunicator QCom = new QueryCommunicator(query,"PurchaseSubscription");
					return QCom;
					
				}
				
				/**
				 * return all maps of specific city
				 * @param cityName
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getMapByCityName3(String cityName) //����� ���� ���� ��� �� ���
				{
					String query="SELECT * FROM map WHERE cityName=\'" + cityName + "\';";
					QueryCommunicator QCom = new QueryCommunicator(query,"PurchaseSubscription");
					return QCom;
				}
				
				
				/**
				 * returns all sites_in_map of a certain map
				 * @param mapID
				 * @param version
				 * @return QueryCommunicator
				 */
			
				public static QueryCommunicator getAllSitesOfMapQuery1(int mapID,int version) {

					String query = "SELECT * FROM site_in_map WHERE mapID=" + mapID + " and mapVersion=" +version+ ";";
					QueryCommunicator QCom = new QueryCommunicator(query, "PurchaseSubscription");
					return QCom;
				}
				
				/**
				 * return all map of specific city that not deleted 
				 * @param cityName
				 * @return QueryCommunicator
				 */
				
				public static QueryCommunicator getMapByCityName5(String cityName) //����� ���� ���� ��� �� ��� ������ ������ ����=0
				{
					String query="SELECT * FROM map WHERE cityName=\'" + cityName + "\' and DeleteDate='0';";
					QueryCommunicator QCom = new QueryCommunicator(query,"PurchaseSubscription");
					return QCom;
				}
				
				/**
				 * add new report
				 * @param cityName
				 * @param date
				 * @param viewsNumber
				 * @param downloadsNumber
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator insertReport(String cityName,String date,int viewsNumber,int downloadsNumber) {

					String query = "INSERT INTO report VALUES (\'"+cityName+"\',\'"+date+"\',"+viewsNumber+","+downloadsNumber+");";
					QueryCommunicator QCom = new QueryCommunicator(query, "PurchaseSubscription");
					return QCom;
				}
				
				/**
				 * update downloadsNumber in  specific report
				 * @param cityName
				 * @param date
				 * @param downloadsNumber
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator UpdatetReport(String cityName,String date,int downloadsNumber) {

					String query = "UPDATE report SET downloadsNumber=\'"+downloadsNumber+"\' WHERE cityName=\'"+cityName+"\' and date=\'"+date+"\';";
					QueryCommunicator QCom = new QueryCommunicator(query, "PurchaseSubscription");
					return QCom;
				}
				
				/**
				 * return specific report
				 * @param cityName
				 * @param date
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getReportByCityName2(String cityName,String date) {//����� ���� ����� ��� �� ��� ������

					String query = "SELECT * FROM report WHERE cityName=\'" + cityName + "\' and date=\'"+date+"\';";
					QueryCommunicator QCom = new QueryCommunicator(query, "PurchaseSubscription");
					return QCom;
				}
				//*****************************showReport************************************
				
				/**
				 * return maps by city name
				 * @param cityName
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator getMapByCityName2(String cityName) //����� ���� ���� ��� �� ���
				{
					String query="SELECT * FROM map WHERE cityName=\'" + cityName + "\' AND version>0;";
					QueryCommunicator QCom = new QueryCommunicator(query,"showReport");
					return QCom;
				}
				
		        /**
		         * return all maps that not in edit status
		         * @return QueryCommunicator
		         */
				public static QueryCommunicator getMap() //����� ���� ���� 
				{
					String query="SELECT * FROM map WHERE version>0;";
					QueryCommunicator QCom = new QueryCommunicator(query,"showReport");
					return QCom;
				}
				
				
				/**
				 * return all the client_purchase by date 
				 * @param date
				 * @return QueryCommunicator
				 */
					public static QueryCommunicator getClientbyDate(String date) {//������ ���� ������ �������� ��� ����� �����

						String query = "SELECT * FROM client_purchase WHERE date=\'" + date + "\';";
						QueryCommunicator QCom = new QueryCommunicator(query, "showReport");
						return QCom;
					}
					
					/**
					 * return all  client_purchase
					 * @return QueryCommunicator
					 */
					public static QueryCommunicator getClientPurchase2() {//������ ���� ������ �������� 

						String query = "SELECT * FROM client_purchase;";
						QueryCommunicator QCom = new QueryCommunicator(query, "showReport");
						return QCom;
					}
					

					/**
					 * return all report by date
					 * @param date
					 * @return QueryCommunicator
					 */
					public static QueryCommunicator getReportDate(String date) {//������ ���� ����� ��� �����

						String query = "SELECT * FROM report WHERE date=\'" + date + "\';";
						QueryCommunicator QCom = new QueryCommunicator(query, "showReport");
						return QCom;
					}
					
					/**
					 * return specific report
					 * @param cityName
					 * @param date
					 * @return QueryCommunicator
					 */
				public static QueryCommunicator getReportByCityName(String cityName,String date) {//����� ���� ����� ��� �� ��� ������

						String query = "SELECT * FROM report WHERE cityName=\'" + cityName + "\' and date=\'"+date+"\';";
						QueryCommunicator QCom = new QueryCommunicator(query, "showReport");
						return QCom;
					}
				
				/**
				 * update specific report
				 * @param cityName
				 * @param viewsNumber
				 * @param date
				 * @return QueryCommunicator
				 */
					
					public static QueryCommunicator UpdateViewsNumRepor(String cityName,int viewsNumber,String date) {//����� ���� ����� ���"� �� ��� ������ ������

						String query = "UPDATE report SET viewsNumber=\'"+viewsNumber+"\' WHERE cityName=\'"+cityName+"\' and date=\'"+date+"\';";
						QueryCommunicator QCom = new QueryCommunicator(query,"showReport");
						return QCom;
					}
					
					//*****************************createReport************************************
					
					
					/** 
					 * Returns all cities objects
					 * @return QueryCommunicator
					 */
					public static QueryCommunicator getCityQuery3() {

						String query = "SELECT * FROM city;";
						QueryCommunicator QCom = new QueryCommunicator(query, "createReport");
						return QCom;
					}
					
				//	**************************************ChangePricesDepartmentDirector*****************************
					/**
					 * Returns all cities objects
					 * @return QueryCommunicator
					 */
					public static QueryCommunicator getCityQuery4() {

						String query = "SELECT * FROM city;";
						QueryCommunicator QCom = new QueryCommunicator(query, "ChangePricesDepartmentDirector");//������ �� �� ������ ����
						return QCom;
					}
					
					/**
					 * Inserts all new prices to newprice table.
					 * @param cityName
					 * @param newPrice
					 * @return QueryCommunicator
					 */
					public static QueryCommunicator insertIntoNewprice(String cityName,double newPrice)//������ �� ���� ����� �� ������� ������ 
					{
					String query="INSERT INTO newprice VALUES (\'"+cityName+"\',"+newPrice+");";
					QueryCommunicator QCom = new QueryCommunicator(query,"ChangePricesDepartmentDirector");
					return QCom;
					}
					/**
					 * delete all rows of newprice table.
					 * @return QueryCommunicator
					 */
					public static QueryCommunicator DeleteFromNewprice2()//����� ����� ����� ����� ������ 
					{
					String query="DELETE FROM newprice;";
					QueryCommunicator QCom = new QueryCommunicator(query,"ChangePricesDepartmentDirector");
					return QCom;
					}
					
//					**************************************ChangePricesCompanyManager*****************************
					/**
					 * updates prices on city table.
					 * @param cityName
					 * @param price
					 * @return QueryCommunicator
					 */
					public static QueryCommunicator UpdatePrices(String cityName,double price) {//���� ������ ����� ����
						String query = "UPDATE city SET price="+price+" WHERE cityName=\'"+cityName+"\';";
						QueryCommunicator QCom = new QueryCommunicator(query,"ChangePricesCompanyManager");
						return QCom;
					}
					/**
					 * delete all rows of newprice table.
					 * @return QueryCommunicator
					 */
					public static QueryCommunicator DeleteFromNewprice()//����� ����� ����� ����� ������ 
					{
					String query="DELETE FROM newprice;";
					QueryCommunicator QCom = new QueryCommunicator(query,"ChangePricesCompanyManager");
					return QCom;
					}
					/**
					 * updates prices on newprice table.
					 * @param cityName
					 * @param price
					 * @return QueryCommunicator
					 */
					public static QueryCommunicator UpdateNewprice(String cityName,double newPrice)//����� ���� ����� ������ 
					{
					String query="UPDATE newprice SET price="+newPrice+" WHERE cityName=\'"+cityName+"\';";
					QueryCommunicator QCom = new QueryCommunicator(query,"ChangePricesCompanyManager");
					return QCom;
					}
					
					/**
					 * Returns all cities objects
					 * @return QueryCommunicator
					 */
					
					public static QueryCommunicator getCityQuery5() {

						String query = "SELECT * FROM city;";
						QueryCommunicator QCom = new QueryCommunicator(query, "ChangePricesCompanyManager");//������ �� �� ������ ����
						return QCom;
					}
					/**
					 * Returns all rows from newprice table
					 * @return QueryCommunicator
					 */
					public static QueryCommunicator getnewPrice() {

						String query = "SELECT * FROM newprice;";//����� �� ����� ����� �� ������� ������
						QueryCommunicator QCom = new QueryCommunicator(query, "ChangePricesCompanyManager");
						return QCom;
					}
					
		//*****************************SubscriptionRenewal************************************
					
					/**
					 * Inserts a new row to client_purchase table
					 * @param userName
					 * @param date
					 * @param purchaseType
					 * @param discount
					 * @param cityName
					 * @param subRenewal
					 * @param userSubscribed
					 * @param subPeriod
					 * @param upToDate
					 * @return QueryCommunicator
					 */
					public static QueryCommunicator insertClientPurchase2(String userName,String date,int purchaseType,int discount,String cityName,int subRenewal,int userSubscribed,int subPeriod,int upToDate) {

						String query = "INSERT INTO client_purchase (userName,date,purchaseType,discount,cityName,subRenewal,userSubscribed,subPeriod,upToDate) VALUES (\'"+userName+"\',\'"+date+"\',"+purchaseType+","+discount+",\'"+cityName+"\',"+subRenewal+","+userSubscribed+","+subPeriod+","+upToDate+");";
						QueryCommunicator QCom = new QueryCommunicator(query, "PurchaseSubscription");
						return QCom;
					}
					
					
		//*****************************ViewPurchasedCities************************************
					
					/**
					 * select all maps from map table that belongs to the same city.
					 * @param cityName
					 * @return QueryCommunicator
					 */
					public static QueryCommunicator getMapByCityName6(String cityName) //����� ���� ���� ��� �� ��� ������ ������ ����=0
					{
						String query="SELECT * FROM map WHERE cityName=\'" + cityName + "\' and DeleteDate='0';";
						QueryCommunicator QCom = new QueryCommunicator(query,"ViewPurchasedCities");
						return QCom;
					}
					
					
					
					/**
					 * return specific report
					 * @param cityName
					 * @param date
					 * @return QueryCommunicator
					 */
				public static QueryCommunicator getReportByCityName1(String cityName,String date) {//����� ���� ����� ��� �� ��� ������

						String query = "SELECT * FROM report WHERE cityName=\'" + cityName + "\' and date=\'"+date+"\';";
						QueryCommunicator QCom = new QueryCommunicator(query, "ViewPurchasedCities");
						return QCom;
					}
				
				
				/**
				 * add new report
				 * @param cityName
				 * @param date
				 * @param viewsNumber
				 * @param downloadsNumber
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator insertReport1(String cityName,String date,int viewsNumber,int downloadsNumber) {

					String query = "INSERT INTO report VALUES (\'"+cityName+"\',\'"+date+"\',"+viewsNumber+","+downloadsNumber+");";
					QueryCommunicator QCom = new QueryCommunicator(query, "ViewPurchasedCities");
					return QCom;
				}
				
				/**
				 * update viewsNumber in  specific report
				 * @param cityName
				 * @param date
				 * @param downloadsNumber
				 * @return QueryCommunicator
				 */
				public static QueryCommunicator UpdatetReport2(String cityName,String date,int viewsNumber) {

					String query = "UPDATE report SET viewsNumber=\'"+viewsNumber+"\' WHERE cityName=\'"+cityName+"\' and date=\'"+date+"\';";
					QueryCommunicator QCom = new QueryCommunicator(query, "ViewPurchasedCities");
					return QCom;
				}
				//************************************MapImage***********************************
					/**
					 * returns all sites_in_map of a certain map
					 * @param mapID
					 * @param version
					 * @return
					 */
					
					public static QueryCommunicator getAllSitesOfMapQuery2(int mapID,int version) {

						String query ="SELECT * FROM site_in_map WHERE mapID=" + mapID + " and mapVersion=" +version+ ";";
						QueryCommunicator QCom = new QueryCommunicator(query, "MapImage");
						return QCom;
				}
					
					
			//*****************************************ViewClientDetails****************************		
					
						
					/**
					 * selects a client from client table by userName
					 * @param userName
					 * @return QueryCommunicator
					 */
					public static QueryCommunicator getClient1(String userName) {

						String query = "SELECT * FROM client WHERE userName=\'" + userName + "\';";
						QueryCommunicator QCom = new QueryCommunicator(query, "ViewClientDetails");
						return QCom;
					}
					
					/**
					 * Selects all client's purchases from client_purchase table.
					 * @param userName
					 * @return QueryCommunicator
					 */
					public static QueryCommunicator getClientbyName1(String userName) {//������ ���� ������ �������� ��� �� ������

						String query = "SELECT * FROM client_purchase WHERE userName=\'" + userName + "\';";
						QueryCommunicator QCom = new QueryCommunicator(query, "ViewClientDetails");
						return QCom;
					}
					
					/**
					 * Selects all purchases from client_purchase table.
					 * @param userName
					 * @return QueryCommunicator
					 */	
					public static QueryCommunicator getClientPurchase1(String userName) {//������ ���� ������ �� ������ 

						String query = "SELECT * FROM client_purchase;";
						QueryCommunicator QCom = new QueryCommunicator(query, "ViewClientDetails");
						return QCom;
					}
					
					
					//*****************************************ChooseCityToEdit****************************
					
					/**
					 *  Returns all cities objects
					 * @return
					 */
				
					public static QueryCommunicator getCityQuery7() {

						String query = "SELECT * FROM city;";
						QueryCommunicator QCom = new QueryCommunicator(query, "ChooseCityToEdit");
						return QCom;
					}
					
					
					
		
	
		
}  




