package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import client.UserClient;
import entity.City;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class AddCityController extends OpenWindowClass implements Initializable {

	/**
	 * The class AddCityController
	 */
	UserClient userClient;
	public static ArrayList<City> cityList;

	/**
	 * sets instance of this controller in userClient to get data from server
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		userClient = ConnectToServerClass.userClient;
		userClient.setAddCity(this);
	}

	// *****SEMAPHORE
	/**
	 * Semaphore variables
	 */
	public static int flag = -1;
	final Lock lock = new ReentrantLock();
	final Condition dbAvalibale = lock.newCondition();
	// *****

	@FXML
	TextField cityNameTxt;

	@FXML
	Label cityAlreadyExistLabel;

	@FXML
	Label NotLetterLabel;

	/**
	 * Checks if the city already exists and if the input is legal. in that case it
	 * adds the city to the DB
	 * 
	 * @param event
	 * @throws InterruptedException
	 * @throws IOException
	 */
	public void addCity(ActionEvent event) throws InterruptedException, IOException {
		NotLetterLabel.setVisible(false);
		cityAlreadyExistLabel.setVisible(false);

		String cityName = cityNameTxt.getText();
		if (cityName.equals("")) {
			NotLetterLabel.setVisible(true);
			return;
		}
		for (int i = 0; i < cityName.length(); i++) {
			if (!(Character.isLetter(cityName.charAt(i))) && (!(Character.isSpaceChar(cityName.charAt(i))))) {
				NotLetterLabel.setVisible(true);
				return;
			}
		}

		QueryCommunicator Qcom = QueryCreator.getCityList(cityNameTxt.getText());
		userClient.handleMessageFromClientUI(Qcom);
		lock.lock();
		while (flag == -1)
			dbAvalibale.await();
		lock.unlock();

		if (cityList.size() == 0) // city doesnt exist
		{
			Qcom = QueryCreator.AddCityQuery(cityNameTxt.getText(), 0);
			userClient.handleMessageFromClientUI(Qcom);
			// Success message pops
			popUpWindow("Success Add City!");
		} else { // city exist
			cityAlreadyExistLabel.setVisible(true);
			return;
		}
		EditMapController.olistCity.add(cityName);
		closeWindow(event);
	}

	/**
	 * Gets the information about the city whether it already exists from the DB
	 * 
	 * @param exist
	 */
	public void setCityExist(ArrayList<City> city) {
		cityList = city;
		flag = 0;
		lock.lock();
		dbAvalibale.signalAll();
		lock.unlock();
	}
}
