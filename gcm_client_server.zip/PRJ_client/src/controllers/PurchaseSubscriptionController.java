package controllers;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.imageio.ImageIO;

import client.UserClient;
import entity.City;
import entity.Map;
import entity.RegisteredUser;
import entity.Site;
import entity.SiteInMap;
import entity.Tour;
import entity.report;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;


public class PurchaseSubscriptionController extends OpenWindowClass implements Initializable {
	/**
	 * The class PurchaseSubscriptionController
	 * 
	 *
	 */
	Map map;
	RegisteredUser user = LoginController.user;
	public City currentCity = ViewCityInMapCatalogController.currentCity;
	public Map selectedMap = ViewCityInMapCatalogController.selectedMap;

	// fill city sites and city tour
	public static ArrayList<SiteInMap> siteList;
	public static ArrayList<Map> mapList;

	/**
	 * Semaphore variables
	 */
	// semaphore
	public static int flag1;
	final Lock lock1 = new ReentrantLock();
	final Condition dbAvalibale1 = lock1.newCondition();

	public static int updateReportFlag;
	public static int mountDuration = 0;
	public ArrayList<Integer> mounts;

	ConnectToServerClass conToServer;
	UserClient userClient;
	QueryCommunicator Qcom;

	/**
	 * Sets the userClient from ConnectToServerClass to communicate with the server
	 * through it, and sends "this" to get feedback from the server
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		flag1 = 0;
		cityName.setText(currentCity.getName());
		userClient = ConnectToServerClass.userClient;
		userClient.setPurchaseSubscription(this);

		updateReportFlag = 0;

		Qcom = QueryCreator.getMapByCityName5(currentCity.getName());
		userClient.handleMessageFromClientUI(Qcom);

	}

	@FXML
	ComboBox<Integer> subsriptionLengthCB;

	@FXML
	TextField price;

	@FXML
	Label cityName;

	ObservableList<Integer> mountList;

	@FXML
	CheckBox clickOneTime;

	@FXML
	CheckBox clickSubscription;

	@FXML
	Label error;

	/**
	 * gets ArrayList of types and sets them into the combobox
	 * 
	 * @param types
	 */
	public void setSubsriptionLengt() {
		mounts = new ArrayList<>();
		for (int i = 1; i < 7; i++)
			mounts.add(i);
		mountList = FXCollections.observableArrayList();
		for (Integer i : mounts) {
			mountList.add(i);
		}
		subsriptionLengthCB.setItems(mountList);
	}

	/**
	 * Submits a purchase of a one time/periodical subscription. sets the date of
	 * purchase for today and sends a DB query in accordance to the purchase type.
	 * 
	 * @param event
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void purchase(ActionEvent event) throws IOException, InterruptedException {
		LocalDate today = LocalDate.now();
		String date = today.format(DateTimeFormatter.ofPattern("dd/MM/yy"));
		if (clickOneTime.isSelected() && clickSubscription.isSelected()) {
			error.setVisible(true);
			return;
		}
		if (clickOneTime.isSelected()) {
			mountDuration = 0;

			Qcom = QueryCreator.insertClientPurchase(user.getUserName(), date, 1, 0, currentCity.getName(), 0, 1, 0, 0);
			userClient.handleMessageFromClientUI(Qcom);
			// popUpWindow("The map has successfully download to your desktop");
			fillPDFFile();
			Qcom = QueryCreator.getReportByCityName2(currentCity.getName(), date);
			userClient.handleMessageFromClientUI(Qcom);
		}
		if (clickSubscription.isSelected()) {
			// ������� �� ���� ���� �� ������ ������ ��� ����
			Qcom = QueryCreator.insertClientPurchase(user.getUserName(), date, 2, -10, currentCity.getName(), 0, 0,
					mountDuration, 0);
			userClient.handleMessageFromClientUI(Qcom);
			popUpWindow("You can view city maps for subscription duration");
		}

	}

	/**
	 * updates the amount for payment in accordance to the selected number of months
	 * for a periodical subscription
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void comboBoxPress(ActionEvent event) throws IOException {

		mountDuration = subsriptionLengthCB.getValue();
		price.setText(Integer.toString((int) currentCity.getRate() + mountDuration * 30));
	}

	/**
	 * "one time purchase" button press
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void oneTimePress(ActionEvent event) throws IOException {

		price.setText(Integer.toString((int) currentCity.getRate()));
		clickSubscription.setSelected(false);
		subsriptionLengthCB.setItems(null);
	}

	/**
	 * "one time purchase" button press
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void pressSub(ActionEvent event) throws IOException {
		setSubsriptionLengt();

		clickOneTime.setSelected(false);

	}

	/**
	 * When "back subscribe" button is clicked, switches to login page
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void back(ActionEvent event) throws IOException {
		openWindow(event, "Home", "application");
	}

	/**
	 * passes all the maps of the city sends query to the server to take site of the
	 * maps from the database Call the function dest(),create(city, map,s) and
	 * downMaps(mapList,s) from class PurchaseDowland. Fill PDF file of map and
	 * download map image
	 * 
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void fillPDFFile() throws IOException, InterruptedException {
		String city = "" + currentCity.getName();
		String map = "";

		if (mapList != null) {
			for (int i = 0; i < mapList.size(); i++) {
				flag1 = 0;
				map += "\n\nmap id: " + mapList.get(i).getIDMap() + "\nmap virsion : " + mapList.get(i).getVersion();
				map += "\ndescription: " + mapList.get(i).getTextualDescription();
				lock1.lock();
				Qcom = QueryCreator.getAllSitesOfMapQuery1(mapList.get(i).getIDMap(), mapList.get(i).getVersion());
				userClient.handleMessageFromClientUI(Qcom);
				while (flag1 == 0) {
					dbAvalibale1.await();
				}
				lock1.unlock();

				for (int j = 0; j < siteList.size(); j++) {

					map += "\n   site name :" + siteList.get(j).getSiteName();

				}
			}
		}
		String s = PurchaseDowland.dest();
		PurchaseDowland.create(city, map, s);
		PurchaseDowland.downMaps(mapList, s);
	}

	/**
	 * Gets ArrayList of all the sites of map from the DB
	 * 
	 * @param siteArr
	 */
	public void setFillSite(ArrayList<SiteInMap> siteArr) {
		lock1.lock();
		updateReportFlag++;
		siteList = siteArr;
		flag1 = 1;
		dbAvalibale1.signalAll();
		lock1.unlock();
	}

	/**
	 * Gets ArrayList of all the maps of city from the DB
	 * @param mapArr
	 */
	public void setMapList(ArrayList<Map> mapArr) {
		mapList = mapArr;
	}

	/**
	 * Gets ArrayList of reports from the DB
	 * if the size of ArrayList is zero send query to insert new report to database else update city report.
	 * 
	 * @param reports
	 */
	public void setReport(ArrayList<report> reports) {
		LocalDate today = LocalDate.now();
		String date = today.format(DateTimeFormatter.ofPattern("dd/MM/yy"));
		if (reports.size() == 0) {
			Qcom = QueryCreator.insertReport(currentCity.getName(), date, 0, 1);
			userClient.handleMessageFromClientUI(Qcom);
			return;
		} else {
			Qcom = QueryCreator.UpdatetReport(currentCity.getName(), date, reports.get(0).getDownloadsNumber() + 1);
			userClient.handleMessageFromClientUI(Qcom);
			return;
		}
	}
}
