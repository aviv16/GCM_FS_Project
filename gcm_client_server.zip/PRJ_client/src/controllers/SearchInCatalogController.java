package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.UserClient;
import entity.City;
import entity.Map;
import entity.Site;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import com.jfoenix.controls.JFXComboBox;


public class SearchInCatalogController extends OpenWindowClass implements Initializable {

	/**
	 * the class SearchInCatalogController
	 *
	 */
	public static City chosenCity;

	public ArrayList<City> allCities;
	public static ArrayList<Site> allSites;
	public static ArrayList<Map> mapsSearchArray;
	boolean initialSiteFlag = false;
	boolean initialCityFlag = false;

	@FXML
	JFXComboBox<String> citiesCB;

	@FXML
	JFXComboBox<String> sitesCB;

	@FXML
	JFXComboBox<String> afterSearchCitiesCB;

	@FXML
	TextArea descriptionTxt;

	@FXML
	Label nothingSelectedLabel;

	@FXML
	Label seeResultsLabel;

	ObservableList<String> cities;
	ObservableList<String> sites;
	ObservableList<String> afterSearchCities;
	UserClient userClient;

	/**
	 * Sets the userClient from ConnectToServerClass to communicate with the server
	 * through it, and sends "this" to get feedback from the server Sends queries to
	 * the server asking for the sites and the cities.
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		userClient = ConnectToServerClass.userClient;
		userClient.setSearchInCatalog(this);

		afterSearchCities = FXCollections.observableArrayList();

		QueryCommunicator Qcom = QueryCreator.getCityQuery();
		userClient.handleMessageFromClientUI(Qcom);

		Qcom = QueryCreator.getAllSitesQuery();
		userClient.handleMessageFromClientUI(Qcom);
	}

	/**
	 * When "Back" button is clicked, switches to relevant home page or login page
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void backToLoginClick(ActionEvent event) throws IOException {
		if (LoginController.user == LoginController.undefinedUser)
			openWindow(event, "LogIn", "application");
		else {
			switch (LoginController.user.getPermission()) {
			case 1: // user
				openWindow(event, "Home", "application");
				break;
			case 2: // employee
				openWindow(event, "EmployeeHome", "application");
				break;
			case 3: // manager
			case 4:
				openWindow(event, "ManagerHome", "application");
				break;
			}
		}
	}

	/**
	 * starts a search in the DB by the provided city name and opens the
	 * "ViewCityInMapCatalog" window with the relevant results.
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void searchByCityName(ActionEvent event) throws IOException {
		nothingSelectedLabel.setVisible(false);
		String cityName = citiesCB.getValue();
		if (cityName == null) {
			nothingSelectedLabel.setVisible(true);
			return;
		}
		for (City city : allCities) {
			if (city.getName().equals(cityName)) {
				chosenCity = city;
				break;
			}
		}
		openWindow(event, "ViewCityInMapCatalog", "application");
	}

	/**
	 * starts a search in the DB by the provided site name and shows on a ComboBox
	 * all relevant cities that the site appears in.
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void searchBySite(ActionEvent event) throws IOException {
		nothingSelectedLabel.setVisible(false);
		afterSearchCities.clear();

		String siteName = sitesCB.getValue();
		if (siteName == null) {
			nothingSelectedLabel.setVisible(true);
			return;
		}
		for (Site site : allSites) {
			if (site.getSiteName().equals(siteName)) {
				afterSearchCities.add(site.getCityName());
			}
		}
		afterSearchCitiesCB.setItems(afterSearchCities);
		seeResultsLabel.setVisible(true);
	}

	/**
	 * starts a search in the DB by a provided description and shows on a ComboBox
	 * all relevant cities that the given description is fully or partly contained
	 * in their description.
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void searchByDescription(ActionEvent event) throws IOException {
		afterSearchCities.clear();
		nothingSelectedLabel.setVisible(false);
		if (descriptionTxt.getText().equals("")) {
			nothingSelectedLabel.setVisible(true);
			afterSearchCitiesCB.setItems(afterSearchCities);
			return;
		}
		afterSearchCities.clear();
		QueryCommunicator Qcom = QueryCreator.searchCityByDescriptionQuery(descriptionTxt.getText());
		userClient.handleMessageFromClientUI(Qcom);

		Qcom = QueryCreator.searchSiteByDescriptionQuery(descriptionTxt.getText());
		userClient.handleMessageFromClientUI(Qcom);
		seeResultsLabel.setVisible(true);
	}

	/**
	 * opens a new window ("ViewCityInMapCatalog") with details relevant to a
	 * selected city after search.
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void goToCity(ActionEvent event) throws IOException {
		String cityName = afterSearchCitiesCB.getValue();
		if (cityName == null) {
			popUpWindow("You must choose city!");
			return;
		}
		for (City city : allCities) {
			if (city.getName().equals(cityName)) {
				chosenCity = city;
				break;
			}
		}
		openWindow(event, "ViewCityInMapCatalog", "application");
	}

	/**
	 * Gets ArrayList of cities and sets in to the comboBox of the cities
	 * 
	 * @param cityArray
	 */
	public void setCityArray(ArrayList<City> cityArray) {
		if (!initialCityFlag) {
			allCities = cityArray;
			cities = FXCollections.observableArrayList();
			for (City city : cityArray) {
				cities.add(city.getName());
			}
			System.out.println(cities.get(0));
			citiesCB.setItems(cities);
			initialCityFlag = true;
			return;
		} else {
			for (City city : cityArray) {
				afterSearchCities.add(city.getName());
			}
			afterSearchCitiesCB.setItems(afterSearchCities);
		}
	}

	/**
	 * Gets ArrayList of sites and sets in to the comboBox of the sites
	 * 
	 * @param siteArray
	 */
	public void setSiteArray(ArrayList<Site> siteArray) {
		if (!initialSiteFlag) {
			allSites = siteArray;
			sites = FXCollections.observableArrayList();
			for (Site site : siteArray) {
				sites.add(site.getSiteName());
			}
			sitesCB.setItems(sites);
			initialSiteFlag = true;
			return;
		} else {
			for (Site site : siteArray) {
				if (!(afterSearchCities.contains(site.getCityName()))) {
					afterSearchCities.add(site.getCityName());
				}
			}
			afterSearchCitiesCB.setItems(afterSearchCities);
		}
	}

	/**
	 * sets a static Arraylist with all the relevant maps to show on the new window
	 * that opens following a search in the catalog.
	 * 
	 * @param mapsArray
	 */
	public void setMapsArray(ArrayList<Map> mapsArray) {
		mapsSearchArray = mapsArray;
		for (Map map : mapsArray) {
			if (!(afterSearchCities.contains(map.getCityName()))) {
				afterSearchCities.add(map.getCityName());
			}
		}
		afterSearchCitiesCB.setItems(afterSearchCities);
	}
}
