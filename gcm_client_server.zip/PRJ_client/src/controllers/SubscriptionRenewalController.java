package controllers;

import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;

import client.UserClient;
import entity.City;
import entity.ClientPurchase;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Label;


public class SubscriptionRenewalController extends OpenWindowClass implements Initializable {

	/**
	 * The class -SubscriptionRenewalController
	 *
	 */
	UserClient userClient;
	ObservableList<Integer> lengthObservableList;
	City renewCity;

	/**
	 * Initializes a userClient instance's connectionToServer to trace response of
	 * server to specific instance's requests. also initializes a
	 * RenewalPageController instance to trace back chosen city.
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		userClient = ConnectToServerClass.userClient;
		userClient.setSubscriptionRenewalController(this);

		renewCity = RenewalPageController.chosenCity;
		// TEST:
		// renewCity=new City("haifa", 100);

		cityName.setText(renewCity.getName());

		lengthObservableList = FXCollections.observableArrayList();
		for (int i = 1; i <= 6; i++)
			lengthObservableList.add(i);

		lengthCB.setItems(lengthObservableList);

	}

	@FXML
	private Label cityName;

	@FXML
	private Label error;

	@FXML
	private JFXTextField originalPriceTxt;

	@FXML
	private JFXComboBox<Integer> lengthCB;

	@FXML
	private JFXTextField finalPriceTxt;

	@FXML
	void cancel(ActionEvent event) {
		closeWindow(event);
	}

	/**
	 * submits a renewal of periodical subscription according to selected period
	 * chosen by user.
	 * 
	 * @param event
	 */
	@FXML
	void purchaseRenewal(ActionEvent event) {
		if (lengthCB.getSelectionModel().getSelectedItem() == null) {
			error.setVisible(true);
			return;
		}
		int subLength = lengthCB.getSelectionModel().getSelectedItem();
		String date = LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yy"));
		QueryCommunicator Qcom = QueryCreator.insertClientPurchase2(LoginController.user.getUserName(), date, 2, 0,
				renewCity.getName(), 1, 0, subLength, 0);
		userClient.handleMessageFromClientUI(Qcom);

		// change status to "already seen renewal"
		for (ClientPurchase purchase : HomeController.clientPurchasesForRenewal) {
			if (purchase.getCityName().equals(renewCity.getName())) {
				Qcom = QueryCreator.updateUserSubscribed(purchase.getPurchaseNum());
				userClient.handleMessageFromClientUI(Qcom);
			}
		}

		RenewalPageController.citiesObservable.remove(renewCity);
		RenewalPageController.renewCon.setTable();
		popUpWindow("You renewed your subscription successfully!");
		closeWindow(event);
	}

	/**
	 * calculates the price of renewal according to the selected period of time.
	 * 
	 * @param event
	 */
	@FXML
	void selectLength(ActionEvent event) {
		int initPrice = (int) renewCity.getRate();
		initPrice += lengthCB.getValue() * 30;
		originalPriceTxt.setText("" + initPrice);
		originalPriceTxt.setAlignment(Pos.BASELINE_CENTER);
		finalPriceTxt.setText("" + (initPrice - initPrice / 10));
		finalPriceTxt.setAlignment(Pos.BASELINE_CENTER);
	}

}
