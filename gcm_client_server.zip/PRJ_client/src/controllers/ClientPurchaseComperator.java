package controllers;

import java.util.Comparator;

import entity.ClientPurchase;

public class ClientPurchaseComperator implements Comparator<ClientPurchase> {

	/**
	 * The class ClientPurchaseComperator compare purchases by their client purchase name
	 *
	 */
	/**
	 * compare the name of purchase1 and purchase2
	 * @param purchase1
	 * @param purchase2
	 */
	@Override
	public int compare(ClientPurchase purchase1, ClientPurchase purchase2) {
		return purchase1.getCityName().compareTo(purchase2.getCityName());
	}

}
