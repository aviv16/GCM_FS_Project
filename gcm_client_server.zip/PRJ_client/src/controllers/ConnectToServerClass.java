package controllers;

import java.io.IOException;

import client.UserClient;

public class ConnectToServerClass{
	/**
	 * The class ConnectToServerClass saves the connection to the server for all controllers to use
	 *
	 */
	public static int DEFAULT_PORT = 5555;
	public static UserClient userClient;
	
	/**
	 * connect to server 
	 * @param serverIP
	 * @throws IOException
	 */
	public void connectToServer(String serverIP) throws IOException
	{
			
				userClient = new UserClient(serverIP, DEFAULT_PORT, this); /*creates new client (that extends AbstractClient)
																						sends him the IP that was inserted to serverIPtxt textField
																						the default port and "this" so that the client could send back
																						feedback or data to the controller*/ 
	}
	
}
