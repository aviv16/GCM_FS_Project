package controllers;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.property.TextAlignment;
import com.sun.javafx.font.FontFactory;


import entity.Map;
import javafx.scene.image.Image;
import javafx.scene.text.Font;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;


public class PurchaseDowland {
	/**
	 * The class PurchaseDowland
	 *
	 */
	public static int fileName = 1;
	public static String dest()
	{
		FileChooser2 g=new FileChooser2();
	    String DEST=g.e();
	    DEST=DEST+"/";
	    System.out.println(DEST);
	    return DEST;
	}
	/**
	 * This method generates a pdf file which contains all the maps of a certain city and it's details.
	 * @param city
	 * @param map
	 * @param DEST
	 * @throws IOException
	 */
	public static void create(String city, String map,String DEST) throws IOException {
		File theFile = new File(DEST + "city-" +city+fileName+ ".pdf");
		FileOutputStream fos = new FileOutputStream(theFile );
		PdfWriter writer = new PdfWriter(fos);
		fileName++;
		// Initialize PDF document
		PdfDocument pdf = new PdfDocument(writer);
		Document document = new Document(pdf);
		// document.add(image);
		Paragraph p1= new Paragraph("City Map");
		p1.setFontSize(24);
		p1.setTextAlignment(TextAlignment.CENTER); 
		Paragraph p2= new Paragraph("Purchase:\ncity name: " + city + "\n************************************\n");
		p2.setFontSize(18);
		p2.setTextAlignment(TextAlignment.CENTER); 
		Paragraph p3= new Paragraph(map);
		p3.setFontSize(16);
		p3.setTextAlignment(TextAlignment.CENTER); 
		document.add(p1);
		document.add(p2);
		document.add(p3);
		document.close();
	}

	/**
	 * prepares the file for download and writes it to the relevant destination.
	 * @param mapList
	 * @param DEST
	 */
	public static void downMaps(ArrayList<Map> mapList,String DEST) {

		try {
			for (int i = 0; i < mapList.size(); i++) {
				File theFile = new File(DEST + mapList.get(i).getCityName() + mapList.get(i).getIDMap() + ".png");
				FileOutputStream output;

				output = new FileOutputStream(theFile);

				InputStream input = new ByteArrayInputStream(mapList.get(i).getMyFile());// mapList.get(i).getInput();
				byte[] buffer = new byte[1024];
				while (input.read(buffer) > 0)
					output.write(buffer);
				System.out.println("SAVE " + theFile.getAbsolutePath());
				input.close();
				output.close();
			}
		} catch (Exception e) {

		}
	}
}
