
package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import client.UserClient;
import entity.RegisteredUser;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class LoginController extends OpenWindowClass implements Initializable{
	/**
	 * The class LoginController
	 *
	 */
	@FXML
	TextField userNametxt;
	
	@FXML
	TextField passwordtxt;
	 
	@FXML
	Label resultUserExistLabel;
	
	@FXML
	Label emptyFieldLabel;
	
	@FXML
	Label wrongPasswordLabel;
	
	@FXML
	Label alreadyConnectedLabel;
	
	/**
	 * Saves the logged in user so the other controllers will have access to it
	 */
	public static RegisteredUser undefinedUser;
	public static RegisteredUser user;
	//*******************************
	ConnectToServerClass conToServer;
	UserClient userClient;
	
	final Lock lock = new ReentrantLock();
	final Condition dbAvalibale = lock.newCondition(); 
	
	boolean serverAnswer=false;
	
	/**
	 * Sets the userClient from ConnectToServerClass to communicate with the server through it, and sends "this" to get feedback from the server
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {	
		userClient=ConnectToServerClass.userClient;
		userClient.setLogin(this);
		undefinedUser=new RegisteredUser();
		user=undefinedUser;
	}
	/**
	 * When "Login" button is clicked, check if there is missing field and if not, send query to check existence of the user with the password.
	 * waits until answer from server and then goes to the home page relevant to the permission of the user.
	 * @param event
	 * @throws IOException
	 */
	public void login(ActionEvent event) throws IOException, InterruptedException
	{
		emptyFieldLabel.setVisible(false);
		resultUserExistLabel.setVisible(false);
		if(userNametxt.getText().isEmpty()||passwordtxt.getText().isEmpty())
		{
			emptyFieldLabel.setVisible(true);
			return;
		}
		
		lock.lock();
		QueryCommunicator Qcom=QueryCreator.IsLoginInfoExist(userNametxt.getText(),passwordtxt.getText());
		userClient.handleMessageFromClientUI(Qcom);
		
		while (user==undefinedUser)
			dbAvalibale.await(); 
		lock.unlock();
		if(user==null)
		{
			resultUserExistLabel.setVisible(true);
			user=undefinedUser;
			return;
			
		}
		else {
			if(user.getActiveStatus()==1)
			{
				alreadyConnectedLabel.setVisible(true);
				return;
			}
		try {
			Qcom=QueryCreator.loginQuery(user.getUserName(),user.getPassword());
			userClient.handleMessageFromClientUI(Qcom);
		switch(user.getPermission())
		{
		case 1:
	    	openWindow(event,"Home","application");
	    	break;
		case 2:
	    	openWindow(event,"EmployeeHome","application");
	    	break;
		case 3:
			openWindow(event,"ManagerHome","application");
	    	break;
		case 4:
			openWindow(event,"ManagerHome","application");
	    	break;
		default:
			resultUserExistLabel.setVisible(true);
	    	break;
		}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		
	}
	
	/**
	 * When "Register" button is clicked, switches to registration page
	 * @param event
	 * @throws IOException
	 */
	    public void registration(ActionEvent event) throws IOException {
	    	openWindow(event,"Registration","application");
	    }

	    /**
	     * When "Watch City Catalog" button is clicked, switches to cityCatalog page
	     * @param event
	     * @throws IOException
	     */
	    public void viewCatalog(ActionEvent event) throws IOException {
	    	openWindow(event,"SearchInCatalog","application");
	    }
	    
	    /**
		 * gets the desired user from the server. If don't exist, it's null.
		 * notify the login method to continue running
		 * @param regUser
		 */
		public void userReceived(RegisteredUser regUser)
		{
			user=regUser;
			lock.lock();
			dbAvalibale.signalAll();
			lock.unlock();
		}
}
