package controllers;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.CharacterCodingException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.imageio.ImageIO;

import com.jfoenix.controls.JFXButton;

import client.UserClient;
import entity.City;
import entity.Map;
import entity.PinWithName;
import entity.Site;
import entity.SiteInMap;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;


public class EditMapController extends OpenWindowClass implements Initializable {
	/**
	 * The class EditMapController
	 *
	 */
	UserClient userClient;
	public static Map map;
	public SiteInMap siteInMap;
	static double xClick,yClick;
	public static ObservableList<String> olistCity;
	public static City curCity;
	public static ArrayList<City> cityList;
	ObservableList<Site> olistSite;
	public static ArrayList<Site> citySitesArr;
	public static ArrayList<SiteInMap> mapSitesArr; //sites that where in the map before the edit
	public static ArrayList<SiteInMap> toChangemapSitesArr; //sites that are on the map during the edit
	public Group pinGroup;
	ArrayList<Site> sitesToShow;
	ArrayList<ImageView> pinImgArr;
	//ImageView newPinImg;//****************
	PinWithName newPinImg;
	Image image;
	ImageView selectedPin;
	public static int missingSitesListFlag;
	TextField descTxt;
	public String siteName;
		/**
		 * Semaphore variables
		 */
		public static int flag=-1; 
		final Lock lock = new ReentrantLock();
		final Condition dbAvalibale = lock.newCondition(); 

    @FXML
    private Button editBtn;
    
	@FXML
    private ComboBox<String> cityCmb;

    @FXML
    private Button saveBtn;

    @FXML
    private TextArea desctxtBox;

    @FXML
    private Button addCityBtn;

    @FXML
    private TableView<Site> sitestbl;

    @FXML
    private TableColumn<Site, String> sitestblCol;

    @FXML
    private Button editCityBtn;

    @FXML
    private Button getMapBtn;

    @FXML
    private TextField mapIDtxt;

    @FXML
    private Pane mapPane;

    @FXML
    private ImageView imgView;

    @FXML
    private TextField currentCitytxt;

    @FXML
    private Button cancelBtn;

    @FXML
    private Label notFoundlbl;

    @FXML
    private Button attachBtn;

    @FXML
    private Label mapUnavailable;
    
    @FXML
    private JFXButton rejectBtn;

    @FXML
    private JFXButton uploadVersionBtn;
    
    @FXML
    private Hyperlink startEditHLink;
    
    /**
     *  go to employee home page.
     * @param event
     * @throws IOException
     */
    @FXML
    void SaveAllChanges(ActionEvent event) throws IOException {
    	if(map==null)
			return;
    	if(currentCitytxt.getText().equals(""))
    	{
    		popUpWindow("You can't save a map with no city!");
    		return;
    	}
    	save();
    	//if(LoginController.user.getPermission()==2) //the manager don't need this page- CHECKKKK from employee
    		
    	switch (LoginController.user.getPermission()) 
		{
    	case 4:	//manager
		case 3: // manager
			if (MapsApprovalController.chosenMap == null) 
			{
				openWindow(event, "ManagerHome", "application");
			}
			else 
			{
				openWindow(event, "MapApproval", "application");
			}
			break;
		case 2:
			openWindow(event, "EmployeeHome", "application"); // or back to another window?
			openWindowWithoutClosingCurrent("SendToManagerApproval", "application");
			break;
		}
    }

    /**
     * the employee press "save" button. Update the database and go to employee home page.
     */
    public void save()
    {
    	QueryCommunicator Qcom;
    	//boolean wasOnMap=false;
    	SiteInMap siteMapSaver=null;
    	if(map==null)
			return;
    	for(SiteInMap sim: toChangemapSitesArr)
    	{
    		for(SiteInMap initSim:mapSitesArr)
    		{
    			if(sim.getSiteName().equals(initSim.getSiteName()))
    			{
    				siteMapSaver=initSim;
    				 //the site's coordinates may have been changed
    				if((sim.getxOnMap()!=initSim.getxOnMap())||(sim.getyOnMap()!=initSim.getyOnMap()))
    				{
    					Qcom=QueryCreator.UpdatetSiteInMap(map.getIDMap(), map.getVersion(), sim.getSiteName(), sim.getxOnMap(), sim.getyOnMap());
    					userClient.handleMessageFromClientUI(Qcom);
    				}
    			}
    		} 
    		if(siteMapSaver==null) //the site wasn't on map before. needs to be added
			{
    			Qcom=QueryCreator.InsertSiteInMap(map.getIDMap(), map.getVersion(), sim.getSiteName(), sim.getxOnMap(), sim.getyOnMap());
				userClient.handleMessageFromClientUI(Qcom);
				
			}
    		else { //the site was on the map in first place
    			mapSitesArr.remove(siteMapSaver); //removes from the arr to know what sites needs to be removed
    			siteMapSaver=null;
    		}
    	}
    	for(SiteInMap initSim:mapSitesArr) //deletes all the sites that were in the map but removed
		{
    		Qcom=QueryCreator.DeleteSiteInMap(map.getIDMap(), map.getVersion(), initSim.getSiteName());
			userClient.handleMessageFromClientUI(Qcom);
		}
    	Qcom=QueryCreator.UpdateEditTo0(map.getIDMap(), map.getVersion());
    	userClient.handleMessageFromClientUI(Qcom);
    }
    /**
     * the employee press on the map and add to the map new site.
     * @param mEvent
     */
    @FXML
	public void addSiteToMap(MouseEvent mEvent) {
		if(mEvent.getButton()==MouseButton.PRIMARY) {
    	if(sitesToShow.size()!=0) {
		xClick=mEvent.getX()-10;
		yClick=mEvent.getY()-10;
		sitestbl.setDisable(false);
    	}
		}
	}
//    @FXML
//    public void enableEditing(ActionEvent event)
//    {
//    	imgView.setDisable(false);
//    	mapPane.setDisable(false);
//    	if(mapSitesArr.size()>0) {
//    		createPinforSite();
//    	mapPane.getChildren().setAll(pinGroup);
//    	}
//    }
    /**
     * enablem to editing the map
     * @param event
     */
    @FXML
    public void enableEditing(ActionEvent event)
    {
    	imgView.setDisable(false);
    	mapPane.setDisable(false);
    	imgView.setEffect(null);
    	startEditHLink.setVisible(false);
    	if(mapSitesArr.size()>0) {
    		mapPane.getChildren().setAll(pinGroup);
    	}
    }
    /**
     * attach the new map to the city.
     * save new map into the database.
     * update the version of the map.
     * @param event
     * @throws IOException
     */
    @FXML
	public void attachCity(ActionEvent event) throws IOException {
    	if(cityCmb.getSelectionModel().getSelectedItem()==null)
    	{
    		popUpWindow("You must select a city!");
    		return;
    	}
		popUpWindow("Map <"+map.getIDMap()+"> is now attached to "+cityCmb.getSelectionModel().getSelectedItem());
		mapSitesArr.clear();
		citySitesArr.clear(); 
		map.setCityName(cityCmb.getSelectionModel().getSelectedItem());
		QueryCommunicator Qcom=QueryCreator.LinkmapToCity(map.getIDMap(),map.getCityName());
		userClient.handleMessageFromClientUI(Qcom);
		Qcom=QueryCreator.UpdateEditTo0(map.getIDMap(), map.getVersion());
    	userClient.handleMessageFromClientUI(Qcom);
		openWindow(event, "EditMapWithPic", "application");
	}

    /**
     * when employee click "cancel" go to the home page.
     * @param event
     * @throws IOException
     */
	@FXML
	void cancelAndClose(ActionEvent event) throws IOException {
		//closeWindow(event);
		// where should I return to?

		// XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXEDIT
		// reset statics maybe
		if(map!=null)
		{
			QueryCommunicator Qcom=QueryCreator.UpdateEditTo0(map.getIDMap(), map.getVersion());
			userClient.handleMessageFromClientUI(Qcom);
		}
    	//check
    	//closeWindow(event);
		switch (LoginController.user.getPermission()) 
		{
		case 4:  // manager
		case 3: // manager
			if (MapsApprovalController.chosenMap == null) 
			{
				openWindow(event, "ManagerHome", "application");
			}
			else 
			{
				openWindow(event, "MapApproval", "application");
			}
			break;
		case 2:
			openWindow(event, "EmployeeHome", "application"); // or back to another window?
			break;
		}
		// XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXEDIT
	}

//    @FXML
//	public void chooseSiteFromTable(MouseEvent mEvent) throws IOException
//	{
//		sitestbl.setDisable(true);
//		Site selectedSite=sitestbl.getSelectionModel().getSelectedItem();
//		if(selectedSite!=null)
//		{
//		siteInMap=new SiteInMap(map.getIDMap(),map.getVersion(),selectedSite.getSiteName(),xClick,yClick);
//		toChangemapSitesArr.add(siteInMap);
//		sitesToShow.remove(selectedSite);
//		olistSite.remove(selectedSite);
//		createPinforSite();
//		mapPane.getChildren().setAll(pinGroup);
//		System.out.println(selectedSite.getSiteName());
//		sitestbl.getItems().setAll(olistSite);
//		}
//	}

	/**
	 * the employee choose site that he want to change.
	 * 
	 * @param mEvent
	 * @throws IOException
	 */
	   @FXML
		public void chooseSiteFromTable(MouseEvent mEvent) throws IOException
		{
			sitestbl.setDisable(true);
			Site selectedSite=sitestbl.getSelectionModel().getSelectedItem();
			if(selectedSite!=null)
			{
			siteInMap=new SiteInMap(map.getIDMap(),map.getVersion(),selectedSite.getSiteName(),xClick,yClick);
			toChangemapSitesArr.add(siteInMap);
			sitesToShow.remove(selectedSite);
			olistSite.remove(selectedSite);
			createPinforSite(selectedSite.getSiteName());
			newPinImg.setPinName(sitestbl.getSelectionModel().getSelectedItem().getSiteName());
			mapPane.getChildren().setAll(pinGroup);
			System.out.println(selectedSite.getSiteName());
			sitestbl.getItems().setAll(olistSite);
			}
		}
	   
	   /**
	    * the employee click "add city" button. go to "AddCity" screen.
	    * @param event
	    * @throws IOException
	    */
    @FXML
	void addCityClick(ActionEvent event) throws IOException {
    		openWindowWithoutClosingCurrent("AddCity","application");
	    }
	
    /**
     * The employee click "edit city" button, go to the screen "EditCity".
     * @param event
     * @throws IOException
     */
	@FXML
	void editCityClick(ActionEvent event) throws IOException
	{
		String cityName=currentCitytxt.getText();
		if(cityName.equals(""))
			return;
		for(City c:cityList)
		{
			if(c.getName().equals(cityName))
				curCity=c;
		}
		QueryCommunicator Qcom=QueryCreator.UpdateEditTo0(map.getIDMap(), map.getVersion());
    	userClient.handleMessageFromClientUI(Qcom);
		openWindow(event,"EditCity","application");
	}

	/**
	 * The employee enter map ID that he want to change.
	 * Function take the map details from the database
	 * @param event
	 */
    @FXML
    void getMapByID(ActionEvent event) {
    	QueryCommunicator Qcom;
    	//sends query to get map details from server
    	//returns to fillMapFields
    	// XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXEDIT
    	//get the map without upload date (=edit version of the map)
    	Qcom=QueryCreator.getMepWithoutUploadDate(Integer.parseInt(mapIDtxt.getText()));
    	userClient.handleMessageFromClientUI(Qcom);	
    	startEditHLink.toFront();
    	startEditHLink.setVisible(true);
    	// XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXEDIT
    }
//*************************************************************

    /**
     * Initialize the screen "EditMap".
     * 
     */
    @Override
	public void initialize(URL location, ResourceBundle resources) {
    	userClient=ConnectToServerClass.userClient;
		userClient.setEditMap(this);
		editCityBtn.setDisable(false);
		missingSitesListFlag=0;
		map=null;
		citySitesArr=new ArrayList<Site>();
		olistCity = FXCollections.observableArrayList();
		olistSite=FXCollections.observableArrayList();
		sitesToShow=new ArrayList<Site>();
		sitestblCol.setCellValueFactory(new PropertyValueFactory<Site,String>("siteName"));
		pinImgArr=new ArrayList<ImageView>();
		toChangemapSitesArr=new ArrayList<SiteInMap>();
		mapSitesArr=new ArrayList<SiteInMap>();
		image=new Image(getClass().getResourceAsStream("newpin.png"));
		pinGroup=new Group();
		mapPane.toFront();
		pinGroup.toFront();
		if(MapsApprovalController.chosenMap!=null)
			mapIDtxt.setText(""+MapsApprovalController.chosenMap.getIDMap());
		if(LoginController.user.getPermission()>=3) //manager
		{
			if (MapsApprovalController.chosenMap != null) 
			{
				rejectBtn.setVisible(true);
			}
			uploadVersionBtn.setVisible(true);
		}
    }

    /**
     * Fill the map fields
     * check if map is not update now.
     * @param list5
     * @throws IOException
     */
    public void fillMapFields(ArrayList<Map> list5) throws IOException
    {
    	
    	if(list5.size()==0) {
			notFoundlbl.setVisible(true);
			return;
    	}
    	else {
        	// XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXEDIT
    		missingSitesListFlag++;
    		getMapBtn.setDisable(true);
    		mapIDtxt.setDisable(true);
			mapUnavailable.setVisible(false);
			Map mapToEdit = list5.get(0);

			if (mapToEdit.getIsEditing() == 1)
			{
				Platform.runLater(new Runnable() {
					@Override
					public void run() {
						mapUnavailable.setText("Another worker currently editing!");
					}
				});
				startEditHLink.setVisible(false);
				mapUnavailable.setVisible(true);
				return;
			}
			if (LoginController.user.getPermission() == 2) 
			{
				if (mapToEdit.getIsSentApproval() == 1) 
				{
					Platform.runLater(new Runnable() {
						@Override
						public void run() {
							mapUnavailable.setText("Map is waiting to be approved!");
						}
					});
					startEditHLink.setVisible(false);
					mapUnavailable.setVisible(true);
					return;
				}
			}
    		QueryCommunicator Qcom1=QueryCreator.UpdateEditTo1(mapToEdit.getIDMap(),mapToEdit.getVersion()); //updating isEditing field
    		userClient.handleMessageFromClientUI(Qcom1);	
    		//test
    		//Qcom1=QueryCreator.UpdateEditToZero(mapToEdit.getIDMap(),mapToEdit.getVersion()); //updating isEditing field
    		//userClient.handleMessageFromClientUI(Qcom1);
        	// XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXEDIT
    		
    		System.out.println(list5.get(0).getIDMap());
    		desctxtBox.setText(list5.get(0).getTextualDescription());
    		byte [] mapByte=list5.get(0).getMyFile();
    		notFoundlbl.setVisible(false);
    		System.out.println("size: "+mapByte.length);
    		ByteArrayInputStream bis=new ByteArrayInputStream(mapByte);
    		BufferedImage BImage=ImageIO.read(bis);
    		Image image=SwingFXUtils.toFXImage(BImage, null);
    		imgView.setImage(image);
    		map=list5.get(0);
    		System.out.println(map.getCityName());
    		//receive cities to fill ComboBox
    		//return to fillCityList
    		QueryCommunicator Qcom=QueryCreator.getCityQuery2();
    		userClient.handleMessageFromClientUI(Qcom);	
    		System.out.println(Qcom.getQuery());
    	}
    }
    /**
     * Fill the city list from the database
     * For each city take the site from the database
     * @param list5
     */
    public void fillCityList(ArrayList<City> list5) {
    	cityList=list5;
    	//System.out.println("cities");
		desctxtBox.setDisable(false);
		if(map.getCityName()==null) 
		{
			addCityBtn.setDisable(false);
			editCityBtn.setDisable(false);
			attachBtn.setDisable(false);
			cityCmb.setDisable(false);
		}
	 
	 for(City city: list5)
		{
			olistCity.add(city.getName());
		}
		cityCmb.setItems(olistCity);
		if(map.getCityName()!=null) {
			currentCitytxt.setText(map.getCityName());
			desctxtBox.setText(map.getTextualDescription());
		}
		//receive all sites of city
		//returns to initializeCitySites
		QueryCommunicator Qcom=QueryCreator.getSitelistQuery2(map.getCityName());
		userClient.handleMessageFromClientUI(Qcom);
    }

    /**
     * Initialize the city sites. 
     * get all sites in city from the database.
     * @param list5
     */
	public void initializeCitySites(ArrayList<Site> list5) {
		System.out.println("citysites");
		missingSitesListFlag++;
		citySitesArr=list5;
		//receive all sites of this map
		//return to initializeMapSites
		QueryCommunicator Qcom=QueryCreator.getAllSitesOfMapQuery(map.getIDMap(),map.getVersion());
		userClient.handleMessageFromClientUI(Qcom);
		
		
	}

	/**
	 *  Initialize map sites.
	 *  get all sites in map from the database.
	 * @param list5
	 */
	public void initializeMapSites(ArrayList<SiteInMap> list5) {
		System.out.println("mapsites");
		missingSitesListFlag++;
		mapSitesArr=list5;
		for(SiteInMap sim:list5)
		{
			toChangemapSitesArr.add(sim);
		}
		checkCitySitesNotInMap();
		locateInitializedMapSites();
	}

//	public void locateInitializedMapSites() {
//		for(int i=0;i<mapSitesArr.size();i++)
//		{
//			xClick=mapSitesArr.get(i).getxOnMap();
//			yClick=mapSitesArr.get(i).getyOnMap();
//			createPinforSite();
//		}
//		
//	}
	/**
	 *  Locate Initialized map sites. 
	 *  take x location and y location that the employee enter.
	 *  put in the location pin.
	 */
	public void locateInitializedMapSites() {
		for(int i=0;i<mapSitesArr.size();i++)
		{
			xClick=mapSitesArr.get(i).getxOnMap();
			yClick=mapSitesArr.get(i).getyOnMap();
			siteName=mapSitesArr.get(i).getSiteName();
			createPinforSite(siteName);
			newPinImg.setPinName(siteName);
		}
	}
	
	/**
	 * check if city sites that employee enter not in map.
	 */
	private void checkCitySitesNotInMap() {
		int isOfBothFlag=0;
		for(int i=0;i<citySitesArr.size();i++) {
			for(int j=0;j<mapSitesArr.size();j++)
			{
				if(citySitesArr.get(i).getSiteName().equals(mapSitesArr.get(j).getSiteName()))
					{
					System.out.println(citySitesArr.get(i).getSiteName()+" is already on map! ");
					isOfBothFlag=1;
					}
			}
			if(isOfBothFlag==0)
				sitesToShow.add(citySitesArr.get(i));
			isOfBothFlag=0;
		}
		for(Site site: sitesToShow)
		{
			olistSite.add(site);
		}
		sitestbl.getItems().setAll(olistSite);
		for(int i=0;i<sitesToShow.size();i++)
			System.out.println(sitesToShow.get(i).getSiteName());
	}
	
	//****************

	  /**
	   * remove pin from the map.
	   * @param event
	   */
	private void removePinFromMap(MouseEvent event) {
		if(event.getButton()==MouseButton.SECONDARY) {
		selectedPin=(ImageView)event.getSource();
		for(int i=0;i<toChangemapSitesArr.size();i++) {
			//if(newPinImg.getPinName().equals(toChangemapSitesArr.get(i).getSiteName())) {
    		if(selectedPin.getId().equals(toChangemapSitesArr.get(i).getSiteName())) {
				for(int j=0;j<citySitesArr.size();j++)
				{
					if(citySitesArr.get(j).getSiteName().equals(toChangemapSitesArr.get(i).getSiteName())) {
							sitesToShow.add(citySitesArr.get(j));
							olistSite.add(citySitesArr.get(j));
						}
					}
					toChangemapSitesArr.remove(i);
				}
			}	
	  	pinGroup.getChildren().remove(selectedPin);
		sitestbl.getItems().setAll(olistSite);
		}
	}
    
//	public void createPinforSite()
//	{
//		System.out.println(xClick);
//		System.out.println(yClick);
//		newPinImg=new ImageView(image);
//		newPinImg.setPreserveRatio(false);
//		newPinImg.setFitHeight(18);
//		newPinImg.setFitWidth(18);
//		newPinImg.setLayoutX(xClick);
//		newPinImg.setLayoutY(yClick);
//		pinGroup.getChildren().add(newPinImg);
//		//mapPane.getChildren().setAll(pinGroup);
//		pinImgArr.add(newPinImg);
//				
//	}
	/**
	 * create new pin for site that employee enter.
	 * @param sitePinName
	 */
	public void createPinforSite(String sitePinName)
	{
		System.out.println(xClick);
		System.out.println(yClick);
		newPinImg=new PinWithName();
		newPinImg.setPinImg(new ImageView(image));
		newPinImg.pinImg.setPreserveRatio(false);
		newPinImg.pinImg.setFitHeight(18);
		newPinImg.pinImg.setFitWidth(18);
		newPinImg.pinImg.setLayoutX(xClick);
		newPinImg.pinImg.setLayoutY(yClick);
		newPinImg.setPinName(sitePinName);
		newPinImg.getPinImg().setId(sitePinName);
		newPinImg.pinImg.setOnMouseClicked(this::removePinFromMap);
		newPinImg.pinImg.setOnMouseEntered(this::displaySiteInfo);
		newPinImg.pinImg.setOnMouseExited(this::hideSiteInfo);
		pinGroup.getChildren().add(newPinImg.pinImg);
		//add description for mouse hover
		descTxt=new TextField(newPinImg.getPinName());
		descTxt.setLayoutX(newPinImg.pinImg.getLayoutX()+15);
		descTxt.setLayoutY(newPinImg.pinImg.getLayoutY()-10);
		descTxt.setOpacity(0.4);
		descTxt.setVisible(false);
		newPinImg.setTextInfo(descTxt);
		pinGroup.getChildren().add(descTxt);
		//
				
	}
	/**
	 * Display in the screen the site information
	 * @param event
	 */
	public void displaySiteInfo(MouseEvent event)
	{
		ImageView imgView=(ImageView)event.getSource();
		descTxt.setText(imgView.getId());
		descTxt.setLayoutX(imgView.getLayoutX()+15);
		descTxt.setLayoutY(imgView.getLayoutY()-10);
		descTxt.setOpacity(0.4);
		descTxt.setVisible(true);
	}
	/**
	 * Hide in the screen the site information
	 * @param event
	 */
	public void hideSiteInfo(MouseEvent event)
	{
		descTxt.setVisible(false);
	}
	/**
	 *  Stop editing map. 
	 * @param event
	 */
	@FXML
	void rejectEdit(ActionEvent event) 
	{
		if(map==null)
			return;
		ManagerHomeController.approvalMaps.remove(MapsApprovalController.chosenMap);
		QueryCommunicator Qcom=QueryCreator.UpdateSendTo0(map.getIDMap(), map.getVersion());
		userClient.handleMessageFromClientUI(Qcom);
		Qcom=QueryCreator.UpdateEditTo0(map.getIDMap(), map.getVersion());
    	userClient.handleMessageFromClientUI(Qcom);
		try {
			openWindow(event, "MapApproval", "application");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * Upload new version of map to the database
	 * @param event
	 * @throws InterruptedException
	 */
	@FXML
	void uploadNewVersion(ActionEvent event) throws InterruptedException
	{
		if(map==null)
			return;
		if(currentCitytxt.getText().equals(""))
    	{
    		popUpWindow("You can't upload a map with no city!");
    		return;
    	}
		save(); //save all the changes and than begin upload new version
		lock.lock();
		QueryCommunicator Qcom=QueryCreator.getmapWhereDeleteDateZero(map.getIDMap());
		userClient.handleMessageFromClientUI(Qcom);
		while (flag==-1)
			dbAvalibale.await(); 
		lock.unlock();
		flag=-1;
		Qcom=QueryCreator.UpdateSendTo0(map.getIDMap(), map.getVersion());
		userClient.handleMessageFromClientUI(Qcom);
		Qcom=QueryCreator.updateUpToDate(map.getCityName()); //notify clients that a new version of the map has been published
		userClient.handleMessageFromClientUI(Qcom);
		popUpWindow("A new version has been published!");
		if (MapsApprovalController.chosenMap != null) 
		{
			try {
				openWindow(event, "MapApproval", "application");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else {
			try {
				openWindow(event, "ManagerHome", "application");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	/**
	 * Set the most updated map in the database.
	 * Insert the new map to the database.
	 * @param mostUpdated
	 */
	public void setMostUpdatedMap(ArrayList<Map> mostUpdated)
	{
		QueryCommunicator Qcom;
		missingSitesListFlag++;
		String date= LocalDate.now().format(DateTimeFormatter.ofPattern("dd/MM/yy"));
		
		if(mostUpdated.size()==0)
		{
			//will add map ID to query
			Qcom=QueryCreator.InsertDetailsMap(map.getIDMap(),1, map.getCityName(), desctxtBox.getText(), date, "0", 0, 0);
			userClient.handleMessageFromClientUI(Qcom);
			
			Qcom=QueryCreator.InsertFileMap(map.getIDMap(), 1, map.getCityName());
			userClient.handleMessageFromClientUI(Qcom);
			
			for(SiteInMap sim:toChangemapSitesArr)
			{ //duplicate all the sites in map
				Qcom=QueryCreator.InsertSiteInMap(map.getIDMap(), 1, sim.getSiteName(), sim.getxOnMap(), sim.getyOnMap());
				userClient.handleMessageFromClientUI(Qcom);
			}
		}
		else {
			Map lastVersionMap=mostUpdated.get(0);
			
			Qcom=QueryCreator.SetDeleteDate(lastVersionMap.getIDMap(), lastVersionMap.getVersion(), date);
			userClient.handleMessageFromClientUI(Qcom);
			
			//will add map ID to query
			Qcom=QueryCreator.InsertDetailsMap(map.getIDMap(),lastVersionMap.getVersion()+1, map.getCityName(), desctxtBox.getText(), date, "0", 0, 0);
			userClient.handleMessageFromClientUI(Qcom);
			
			Qcom=QueryCreator.InsertFileMap(lastVersionMap.getIDMap(), lastVersionMap.getVersion()+1, lastVersionMap.getCityName());
			userClient.handleMessageFromClientUI(Qcom);
			
			for(SiteInMap sim:toChangemapSitesArr)
			{ //duplicate all the sites in map
				Qcom=QueryCreator.InsertSiteInMap(lastVersionMap.getIDMap(), lastVersionMap.getVersion()+1, sim.getSiteName(), sim.getxOnMap(), sim.getyOnMap());
				userClient.handleMessageFromClientUI(Qcom);
			}
		}
		// free semaphore
		flag = 1;
		lock.lock();
		dbAvalibale.signalAll();
		lock.unlock();
	}

}
