package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class SendToManagerApprovalController extends OpenWindowClass { 

	/**
	 * The class SendToManagerApprovalController. this class extends OpenWindowClass.
	 */

	/**
	 * lets the user save editing changes only.
	 * @param event
	 */
    @FXML
    void justSave(ActionEvent event) {
    	closeWindow(event);
    }

    /**
     * lets the user submit editing sessions and sending a request for the superior's approval. 
     * @param event
     */
    @FXML
    void sendToApproval(ActionEvent event) {
    	QueryCommunicator Qcom=QueryCreator.UpdateSendTo1(EditMapController.map.getIDMap(), EditMapController.map.getVersion());
    	ConnectToServerClass.userClient.handleMessageFromClientUI(Qcom); 
    	closeWindow(event);
    }
}
