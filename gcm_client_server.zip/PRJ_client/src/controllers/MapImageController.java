package controllers;

import java.awt.image.BufferedImage;
import java.awt.image.DataBuffer;
import java.awt.image.DataBufferByte;
import java.awt.image.IndexColorModel;
import java.awt.image.Raster;
import java.awt.image.RenderedImage;
import java.awt.image.SampleModel;
import java.awt.image.WritableRaster;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;

import client.UserClient;
import entity.Map;
import entity.SiteInMap;
import javafx.embed.swing.SwingFXUtils;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;


public class MapImageController extends OpenWindowClass implements Initializable {
	/**
	 * The class MapImageController
	 *
	 */
	Map map;
	UserClient userClient;
	double xLocation;
	double yLocation;
	ImageView newPinImg;
	Image image;
	ArrayList<ImageView> pinImgArr;
	ArrayList<Label> sitesNamesLabels;
	public Group pinGroup;

	/**
	 * Initialize the screen sets instance of this controller in userClient to get
	 * data from server sends query to the server asking for all map in the database
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		/*
		 * map=ViewCityInMapCatalogController.selectedMap; try { ByteArrayInputStream
		 * byt=new ByteArrayInputStream(map.getMyFile()); BufferedImage bImage=
		 * ImageIO.read(byt); if(bImage==null) { return; } Image image
		 * =SwingFXUtils.toFXImage(bImage, null); ImageView imageView=new ImageView();
		 * imageView.setImage(image); imageView.setFitHeight(198);
		 * imageView.setFitWidth(350); pane.getChildren().add(imageView); } catch
		 * (IOException e) { // TODO Auto-generated catch block e.printStackTrace(); }
		 */

		userClient = ConnectToServerClass.userClient;
		userClient.setMapImage(this);

		map = ViewPurchaseCitiesController.selectedMap;
		sitesNamesLabels = new ArrayList<Label>();
		try {
			ByteArrayInputStream byt = new ByteArrayInputStream(map.getMyFile());
			BufferedImage bImage = ImageIO.read(byt);
			if (bImage == null) {
				return;
			}
			Image image = SwingFXUtils.toFXImage(bImage, null);
			ImageView imageView = new ImageView();
			imageView.setImage(image);
			imageView.setFitHeight(401);
			imageView.setFitWidth(607);
			pane.getChildren().add(imageView);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		image = new Image(getClass().getResourceAsStream("newpin.png"));
		pinImgArr = new ArrayList<ImageView>();
		pinGroup = new Group();
		QueryCommunicator Qcom = QueryCreator.getAllSitesOfMapQuery2(map.getIDMap(), map.getVersion());
		userClient.handleMessageFromClientUI(Qcom);
	}

	@FXML
	Pane pane;

	@FXML
	Pane sitesPane;

	@FXML
	Pane labelsPane;

	/**
	 * close the window
	 */
	public void close(ActionEvent event) {
		closeWindow(event);
	}

	/**
	 * get from database all the map
	 * 
	 * @param sitesInMap
	 */
	public void setSitesOfMap(ArrayList<SiteInMap> sitesInMap) {
		for (SiteInMap sim : sitesInMap) {
			xLocation = sim.getxOnMap();
			yLocation = sim.getyOnMap();
			Label lbl = new Label();
			lbl.setLayoutX(xLocation);
			lbl.setLayoutY(yLocation + 15);
			lbl.setText(sim.getSiteName());
			lbl.setVisible(true);
			lbl.setStyle("-fx-font-weight: bold");
			sitesNamesLabels.add(lbl);
			createPinforSite();
		}
	}

	/**
	 * create new pin for site
	 */
	public void createPinforSite() {
		newPinImg = new ImageView(image);
		newPinImg.setPreserveRatio(false);
		newPinImg.setFitHeight(18);
		newPinImg.setFitWidth(18);
		newPinImg.setLayoutX(xLocation);
		newPinImg.setLayoutY(yLocation);
		pinGroup.getChildren().add(newPinImg);
		pinImgArr.add(newPinImg);

	}

	/**
	 * show the site in map
	 * 
	 * @param event
	 */
	@FXML
	void showSites(ActionEvent event) {
		sitesPane.getChildren().setAll(pinGroup);
		labelsPane.getChildren().setAll(sitesNamesLabels);
	}
}
