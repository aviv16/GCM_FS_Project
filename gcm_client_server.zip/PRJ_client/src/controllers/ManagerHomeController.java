package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import com.jfoenix.controls.JFXComboBox;

import client.UserClient;
import entity.Client;
import entity.Map;
import entity.RegisteredUser;
import entity.newCity;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;


public class ManagerHomeController extends OpenWindowClass implements Initializable {
	/**
	 * The class ManagerHomeController
	 *
	 */
	public static RegisteredUser client;
	  @FXML
	  private JFXComboBox<String> clientCB;
	  @FXML
		private Button update;
		public static ArrayList<Client> clientArr=null;
		ObservableList<String> clientList;
		public static int pricesApprove;
//		public static int flag = -1;
//		public static final Lock lock = new ReentrantLock();
//		public static final Condition dbAvalibale = lock.newCondition();
//	  
	UserClient userClient;
	public static ArrayList<Map> approvalMaps;
	public static ArrayList<newCity> approvalCity;
	RegisteredUser user=LoginController.user;
	
	/**
	 *  Initialize the screen 
	 *   sets instance of this controller in userClient to get data from server
	 *   sends query to the server asking for all the client in the database
	 *   sends query to the server asking for all maps waiting to be approved
	 *   sends query to the server asking forget all newCity prices waiting to be approved
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		pricesApprove = 0;
		client=new RegisteredUser();
		userClient=ConnectToServerClass.userClient;
		userClient.setManagerHome(this);
		approvalMaps=null;
		if (user.getPermission() == 3) 
			update.setVisible(true);
		
		//���� �� �� �������
		QueryCommunicator Qcom=QueryCreator.getAllClient();
		userClient.handleMessageFromClientUI(Qcom);

		
		//send query to get all maps waiting to be approved
		Qcom=QueryCreator.getmapWhereisSentApprovalOne();
		userClient.handleMessageFromClientUI(Qcom);
		
		//send query to get all newCity prices waiting to be approved
		 Qcom=QueryCreator.getnewPrice1();
		userClient.handleMessageFromClientUI(Qcom);

		//TEST
		//setMapsToApprove(new ArrayList<Map>());
		
	}
    @FXML
    private Label youHaveMessageLabel;

    @FXML
    private Label newPricesToApprove;
    
    /**
     * manager press "logout" sends query to the server asking change active status of manager.
     * @param event
     * @throws IOException
     */
    @FXML
    void logout(ActionEvent event) throws IOException 
    {
    	QueryCommunicator Qcom=QueryCreator.logOutQuery(LoginController.user.getUserName(),LoginController.user.getPassword());
		userClient.handleMessageFromClientUI(Qcom);
    	openWindow(event,"LogIn","application");
    }

    /**
     * manager press "Map Approvals" button switch to "MapApproval"
     * @param event
     */
    @FXML
    void mapApprovals(ActionEvent event) 
    {
    	try {
			openWindow(event, "MapApproval", "application");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    /**
     *  manager press "View City Catalog" button switch to "SearchInCatalog"
     * @param event
     * @throws IOException
     */
    @FXML
    void viewCityInCatalog(ActionEvent event) throws IOException 
    {
			openWindow(event, "SearchInCatalog", "application");
    }

    /**
     * manager press "View City Catalog" button switch to "SearchInCatalog"
     * @param event
     */
    @FXML
    void createReport(ActionEvent event) 
    {
    	try {
			openWindow(event, "CreateReport", "application");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    /**
     * the manager press update rate if regular manager switch to  "ChangePricesDepartmentDirector" screen,
     *  if company manager switch to  "ChangePricesCompanyManager"
     * @param event
     * @throws IOException
     */
    @FXML
    void updateRate(ActionEvent event) throws IOException 
    {
    	if(user.getPermission()==3)
    		openWindow(event, "ChangePricesDepartmentDirector", "application");
    	else if (user.getPermission() == 4 && pricesApprove == 1)
		openWindow(event, "ChangePricesCompanyManager", "application");
    }
    
    
    /**
     * manager press "edit map" button if company manager switch to   "EditMapWithPic"
     * @param event
     * @throws IOException
     */
    @FXML
    void editMap(ActionEvent event) throws IOException 
    {
			openWindow(event, "EditMapWithPic", "application");
    }
    
    /**
     *  manager press "edit city" button if company manager switch to  "ChooseCityToEdit"
     * @param event
     * @throws IOException
     */
    @FXML
    void editCity(ActionEvent event) throws IOException
    {
		openWindow(event, "ChooseCityToEdit", "application");
    }
    
    /**
     * manager press "view client" button if company manager switch to  "ViewClientCard"
     * @param event
     * @throws IOException
     */
    @FXML
    void viewClient(ActionEvent event) throws IOException 
    {
    	if(clientCB.getValue()!=null)
    	{
    		client.setUserName(clientCB.getValue());
			openWindow(event, "ViewClientCard", "application");
    	}
    }
    /**
     * get from the database all the map that manager need approve
     * @param maps
     */
    public void setMapsToApprove(ArrayList<Map> maps)
    {
    	approvalMaps=maps;
    	 Platform.runLater(new Runnable() {
             @Override public void run() {
            	youHaveMessageLabel.setText("You have "+maps.size()+" new requests for map approvals");
             }
         });
    	youHaveMessageLabel.setStyle("-fx-font-weight: bold");
    }
    
    /**
     * get from the database all the city
     * @param city
     */
    public void setNewCityToApprove(ArrayList<newCity> city)
    {
    	approvalCity = city;
		if (user.getPermission() == 4) {
			if (approvalCity.size() > 0) {
				update.setVisible(true);
				pricesApprove = 1;
				newPricesToApprove.setVisible(true);
			}

		}
    }
	/**
	 *Gets ArrayList of types and sets them into the combobox
	 * @param types
	 */
	public void setAllClient(ArrayList<Client> types)
	{
		clientArr=types;
		clientList=FXCollections.observableArrayList();
		for(int i=0;i<types.size();i++)
		{
			clientList.add((clientArr.get(i)).getuserName());
		}
		clientCB.setItems(clientList);
	} 
    
}
