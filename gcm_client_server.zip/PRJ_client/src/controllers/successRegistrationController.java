package controllers;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.scene.Node;
import javafx.stage.Stage;

public class successRegistrationController extends OpenWindowClass {

	/**
	 * The class successRegistrationController
	 *
	 */
	/**
	 * after registration of a new user to the system, returns to the login screen.
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void backToLogin(ActionEvent event) throws IOException {
		Node source = (Node) event.getSource();
		Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
	}
}
