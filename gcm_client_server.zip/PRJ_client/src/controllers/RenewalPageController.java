package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import entity.City;
import entity.Site;
import javafx.fxml.Initializable;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;


public class RenewalPageController extends OpenWindowClass implements Initializable {

	/**
	 * The class RenewalPageController.
	 */
	public static ObservableList<City> citiesObservable;
	public static City chosenCity;
	public static RenewalPageController renewCon;

	/**
	 * Overrides Initializable's Initialize method. initializes a city's table.
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		citiesObservable = FXCollections.observableArrayList();
		renewCon = this;

		cityNameColumn.setCellValueFactory(new PropertyValueFactory<City, String>("name"));
		cityNameColumn.setStyle("-fx-alignment: CENTER;");

		for (City city : HomeController.allRenewalCities) {
			citiesObservable.add(city);
		}
		cityTable.getItems().setAll(citiesObservable);
	}

	@FXML
	private TableView<City> cityTable;

	@FXML
	private TableColumn<City, String> cityNameColumn;

	@FXML
	Label noChoiseLabel;

	/**
	 * gets a selected city from the table and opens the subscription renewal window
	 * 
	 * @param event
	 */
	@FXML
	void goToPurchase(ActionEvent event) {
		noChoiseLabel.setVisible(false);
		if (cityTable.getSelectionModel().getSelectedItem() == null) {
			noChoiseLabel.setVisible(true);
			return;
		}
		chosenCity = cityTable.getSelectionModel().getSelectedItem();
		try {
			openWindowWithoutClosingCurrent("SubscriptionRenewal", "application");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * returns to the home page when the user hits the "Back" button.
	 * 
	 * @param event
	 */
	@FXML
	void back(ActionEvent event) {
		citiesObservable.clear();
		try {
			openWindow(event, "Home", "application");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * fill the table of all cities.
	 */
	public void setTable() {
		cityTable.getItems().setAll(citiesObservable);
	}
}
