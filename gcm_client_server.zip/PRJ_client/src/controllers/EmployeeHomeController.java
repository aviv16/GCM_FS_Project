package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import client.UserClient;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

public class EmployeeHomeController extends OpenWindowClass implements Initializable {
	/**
	 * The class EmployeeHomeController
	 *
	 */
	UserClient userClient;

	/**
	 * sets instance of this controller in userClient to get data from server
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		userClient = ConnectToServerClass.userClient;
		userClient.setEmployeeHome(this);
	}

//	public void chagePrice(ActionEvent event) throws IOException {
//		openWindow(event, "ChangePricesDepartmentDirector", "application");
//	}

	/**
	 * "View Catalog" button press go to "SearchInCatalog" screen
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void viewCatalog(ActionEvent event) throws IOException {
		openWindow(event, "SearchInCatalog", "application");
	}

	/**
	 * "logout" button press go to "LogIn" screen update the active status of the
	 * employee
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void logout(ActionEvent event) throws IOException {
		QueryCommunicator Qcom = QueryCreator.logOutQuery2(LoginController.user.getUserName(),
				LoginController.user.getPassword());
		userClient.handleMessageFromClientUI(Qcom);
		openWindow(event, "LogIn", "application");
	}

	/**
	 * "Edit Map" button press go to "EditMapWithPic" screen
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void editMap(ActionEvent event) throws IOException {
		openWindow(event, "EditMapWithPic", "application");
	}

	/**
	 * "view report" button press go to "CreateReport" screen
	 * 
	 * @param event
	 * @throws IOException
	 */
	public void report(ActionEvent event) throws IOException {
		openWindow(event, "CreateReport", "application");
	}

	/**
	 * "Edit City" button press go to "ChooseCityToEdit" screen
	 * 
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void editCity(ActionEvent event) throws IOException {
		openWindow(event, "ChooseCityToEdit", "application");
	}
}
