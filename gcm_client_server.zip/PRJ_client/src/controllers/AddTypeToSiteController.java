package controllers;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import client.UserClient;
import entity.SiteType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import com.jfoenix.controls.JFXTextField;


public class AddTypeToSiteController extends OpenWindowClass implements Initializable {

	/**
	 * The class AddTypeToSiteController
	 */
	UserClient userClient;
	
	/**
	 * Sets the userClient from ConnectToServerClass to communicate with the server through it, and sends "this" to get feedback from the server
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		userClient=ConnectToServerClass.userClient;
		userClient.setAddTypeToSite(this);
	}
	
	@FXML
	JFXTextField typeName;
	
	@FXML
	Label typeAlreadyExistLabel;
	
	/**
	 * Closes the window
	 * @param event
	 */
	public void cancel(ActionEvent event)
	{
		closeWindow(event);
	}
	
	/**
	 * Checks if the type already exists
	 * If exists- notify the user
	 * Else adds the type to database and closes the window
	 * @param event
	 */
	public void addType(ActionEvent event)
	{
		ArrayList<SiteType> list=null;
		if(EditSiteController.siteTypes!=null)
		{
			list=EditSiteController.siteTypes;
		}
		else if(AddSiteController.siteTypes!=null)
		{
			list=AddSiteController.siteTypes;
		}
		for(SiteType type: list)
		{
			if(type.getName().equals(typeName.getText()))
			{
				typeAlreadyExistLabel.setVisible(true);
				return;
			}
		}
		SiteType type=new SiteType(typeName.getText());
		if(EditSiteController.siteTypes!=null)
		{
			EditSiteController.siteTypes.add(type);
			EditSiteController.controller.updateSitesType();
		}
		if(AddSiteController.siteTypes!=null)
		{
			AddSiteController.siteTypes.add(type);
			AddSiteController.controller.updateSitesType();
		}
		
		QueryCommunicator Qcom = QueryCreator.addSiteType(typeName.getText());
		userClient.handleMessageFromClientUI(Qcom);
		popUpWindow(typeName.getText()+" added as a type!");
		closeWindow(event);
	}

}
