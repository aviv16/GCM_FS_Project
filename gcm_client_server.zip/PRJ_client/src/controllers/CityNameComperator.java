package controllers;


import java.util.Comparator;

import entity.City;
import entity.ClientPurchase;

public class CityNameComperator implements Comparator<City> {

	/**
	 * The class CityNameComperator compare to cities by their name
	 *
	 */
	/**
	 * compare the name of city1 and city2
	 * @param city1
	 * @param city2
	 */
	@Override
	public int compare(City city1, City city2) {
		return city1.getName().compareTo(city2.getName());
	}

}
