package controllers;

import java.io.Serializable;


public class QueryCommunicator implements Serializable {
	/**
	 * class that have a query and the type of the query. Objects from this class
	 * will be send from client to server
	 *
	 */
	// Class variables
	private static final long serialVersionUID = 1L;
	private String Filename;
	private String query;
	private type t;
	private String screenName;

	public enum type {
		SELECT_query, UPDATE_query, INSERT_query, DELETE_query
	};

	/**
	 * classifies a query's type in accordance to the first word of the query. this
	 * class also saves the screen's name in order to trace the query's source
	 * 
	 * @param query
	 * @param screenName
	 */
	public QueryCommunicator(String query, String screenName) // gets query and classifies it using the first word
	{
		this.screenName = screenName;
		this.query = query;
		if (query.startsWith("SELECT"))
			t = type.SELECT_query;
		else {
			if (query.startsWith("UPDATE"))
				t = type.UPDATE_query;

			if (query.startsWith("INSERT"))
				t = type.INSERT_query;

			if (query.startsWith("DELETE"))
				t = type.DELETE_query;
		}

	}

	/**
	 * get the Type of the query
	 * 
	 * @return
	 */
	public type getType() {
		return t;
	}

	/**
	 * get the query
	 * 
	 * @return
	 */
	public String getQuery() {
		return query;
	}

	/**
	 * query result back to the screen name
	 * 
	 * @return
	 */
	public String getScreenName() {
		return screenName;
	}

	/**
	 * get file name
	 * 
	 * @return
	 */
	public String getFilename() {
		return Filename;
	}

	/**
	 * set file name
	 * 
	 * @param filename
	 */
	public void setFilename(String filename) {
		Filename = filename;
	}
}
