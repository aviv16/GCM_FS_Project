package controllers;

import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileSystemView;

public class FileChooser2 {

	/**
	 * The class FileChooser Allows the user to download the maps he has purchased
	 * to the folder he chooses.
	 *
	 */
	public String s;

	/**
	 * choose folder for download
	 * 
	 * @return string of destination
	 */
	public String e() {

		JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
		jfc.setDialogTitle("Choose a directory to save your file: ");
		jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

		int returnValue = jfc.showSaveDialog(null);
		if (returnValue == JFileChooser.APPROVE_OPTION) {
			if (jfc.getSelectedFile().isDirectory()) {
				System.out.println("You selected the directory: " + jfc.getSelectedFile());
				s = jfc.getSelectedFile().getAbsolutePath();

			}
		}
		return s;
	}

}
