package controllers;

import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;


public class OpenWindowClass {

	/**
	 * The class OpenWindowClass- switches between windows
	 */
	/**
	 * method that get the event and information about the window that needs to be
	 * opened hides the current window and opens the wanted window
	 * 
	 * @param event
	 * @param FXMLname
	 * @param cssName
	 * @throws IOException
	 */
	// method that get the event and information about the window that needs to be
	// opened
	// hides the current window and opens the wanted window
	public void openWindow(ActionEvent event, String FXMLname, String cssName) throws IOException {
		((Node) event.getSource()).getScene().getWindow().hide(); // hiding primary window
		Stage primaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader();
		Pane root = loader.load(getClass().getResource("/application/" + FXMLname + ".fxml").openStream()); // loading
																											// FXML file
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/application/" + cssName + ".css").toExternalForm()); // get
																													// relevant
																													// css
																													// file
		primaryStage.setScene(scene);
		primaryStage.show(); // open window
	}

	/**
	 * open new window without closing the current without
	 * 
	 * @param FXMLname
	 * @param cssName
	 * @throws IOException
	 */
	public void openWindowWithoutClosingCurrent(String FXMLname, String cssName) throws IOException {
		Stage primaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader();
		Pane root = loader.load(getClass().getResource("/application/" + FXMLname + ".fxml").openStream()); // loading
																											// FXML file
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/application/" + cssName + ".css").toExternalForm()); // get
																													// relevant
																													// css
																													// file
		primaryStage.setScene(scene);
		primaryStage.show(); // open window
	}

	/**
	 * close the without
	 * 
	 * @param event
	 */
	public void closeWindow(ActionEvent event) {
		Node source = (Node) event.getSource();
		Stage stage = (Stage) source.getScene().getWindow();
		stage.close();
	}
	/*
	 * public void changeScene(String fxml) throws IOException{ String screen=
	 * "/application/"+fxml+".fxml"; Parent pane = FXMLLoader.load(
	 * getClass().getResource(screen));
	 * 
	 * Main.primary.getScene().setRoot(pane); }
	 */

	/**
	 * open open success window put the massage that we want in the window.
	 * 
	 * @param FXMLname
	 * @param cssName
	 * @throws IOException
	 */
	public void openSuccessWindow(String FXMLname, String cssName) throws IOException {
		// ((Node)event.getSource()).getScene().getWindow().hide(); //hiding primary
		// window
		Stage primaryStage = new Stage();
		FXMLLoader loader = new FXMLLoader();
		Pane root = loader.load(getClass().getResource("/application/" + FXMLname + ".fxml").openStream()); // loading
																											// FXML file
		Scene scene = new Scene(root);
		scene.getStylesheets().add(getClass().getResource("/application/" + cssName + ".css").toExternalForm()); // get
																													// relevant
																													// css
																													// file
		primaryStage.setScene(scene);
		primaryStage.show(); // open window
	}

	/**
	 * pop up window
	 * 
	 * @param message
	 */
	public void popUpWindow(String message) {
		Alert alert = new Alert(AlertType.NONE, message, ButtonType.OK);
		alert.setTitle("");
		alert.setHeaderText(null);
		alert.setContentText(message);
		alert.showAndWait();

		if (alert.getResult() == ButtonType.OK) {
			alert.close();
		}

	}
}
