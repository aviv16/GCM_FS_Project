package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import com.jfoenix.controls.JFXComboBox;

import client.UserClient;
import entity.City;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;


public class ChooseCityToEditController extends OpenWindowClass implements Initializable {

	/**
	 * The class ChooseCityToEditController -Allows the employee to edit city.
	 *
	 */
	UserClient userClient;
	public static City cityToEdit;
	ArrayList<City> allCities;
	ObservableList<String> cityNamesList;
	
	/**
	 * sets instance of this controller in userClient to get data from server
	 * send query to get all cities and when receiving the list, fill comboBox.
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		userClient=ConnectToServerClass.userClient;
		userClient.setChooseCityToEdit(this);
		cityToEdit=null;
		cityNamesList=FXCollections.observableArrayList();
		QueryCommunicator Qcom=QueryCreator.getCityQuery7();
		userClient.handleMessageFromClientUI(Qcom);
	}


    @FXML
    private JFXComboBox<String> citiesCB;

    /**
     * The employee click on button "cancel" back to the employee home page.
     * @param event
     * @throws IOException
     */
    @FXML
    void cancel(ActionEvent event) throws IOException {
    	switch(LoginController.user.getPermission())
    	{
    	case 2:
    		openWindow(event, "EmployeeHome", "application");
    		break;
    	case 3:
    	case 4:
    		openWindow(event, "ManagerHome", "application");
    		break;
    	}
    }

    /**
     * The employee click on button "Go To Edit City" switch to the screen "EditCity".
     * @param event
     * @throws IOException
     */
    @FXML
    void goToEditCity(ActionEvent event) throws IOException {
    	if(citiesCB.getValue()==null)
    		return;
    	
    	for(City city:allCities)
    	{
    		if(city.getName().equals(citiesCB.getValue()))
    			cityToEdit=city;
    	}
    	openWindow(event, "EditCity", "application");
    }
    
    /**
     * get all cities from database and fill the comboBox.
     * @param cities
     */
    public void setCities(ArrayList<City> cities)
    {
    	allCities=cities;
    	for(City city:allCities)
    	{
    		cityNamesList.add(city.getName());
    	}
    	citiesCB.setItems(cityNamesList);;
    }
}
