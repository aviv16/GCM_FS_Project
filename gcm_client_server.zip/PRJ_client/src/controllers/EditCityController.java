package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import client.UserClient;
import entity.City;
import entity.Site;
import entity.SiteInTour;
import entity.Tour;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;


public class EditCityController extends OpenWindowClass implements Initializable {

	/**
	 * The class EditCityController
	 */
	public static City currentCity;
	public static Site currentSite;
	public static Tour currentTour;
	public static ArrayList<Site> sitesArr;
	public static ArrayList<Tour> toursArr;
	public static ObservableList<Site> sitesList;
	public ObservableList<Tour> toursList;
	UserClient userClient;
	
	/**
	 * Sets the userClient from ConnectToServerClass to communicate with the server through it, and sends "this" to get feedback from the server
	 * Initialize the Table columns and sends queries to get data to the tables
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		userClient=ConnectToServerClass.userClient;
		userClient.setEditCity(this);
		sitesList=FXCollections.observableArrayList();
		toursList=FXCollections.observableArrayList();
		sitesArr=new ArrayList<Site>();
		toursArr=new ArrayList<Tour>();
		tourIDColumn.setCellValueFactory(new PropertyValueFactory<Tour, Integer>("IDTour"));
		tourIDColumn.setStyle( "-fx-alignment: CENTER;");
		tourDescriptionColumn.setCellValueFactory(new PropertyValueFactory<Tour, String>("description"));
		tourDescriptionColumn.setStyle( "-fx-alignment: CENTER;");
		siteNameColumn.setCellValueFactory(new PropertyValueFactory<Site, String>("siteName"));
		siteNameColumn.setStyle( "-fx-alignment: CENTER;");
		if(ChooseCityToEditController.cityToEdit==null)
			currentCity=EditMapController.curCity;
		else {
			currentCity=ChooseCityToEditController.cityToEdit;
		}
		//currentCity=new City("Haifa", 2000);
		QueryCommunicator Qcom = QueryCreator.getAllSitesOfCityQuery(currentCity.getName());
		userClient.handleMessageFromClientUI(Qcom);
		QueryCommunicator Qcom2 = QueryCreator.getAllToursOfCityQuery(currentCity.getName());
		userClient.handleMessageFromClientUI(Qcom2);
		
		/*//TEST 
		ArrayList<Site> s=new ArrayList<Site>();
		s.add(new Site("Name", "city", "classific", "explain", "true"));
		s.add(new Site("Name2", "city", "classific2", "explain2", "true"));
		s.add(new Site("Name3", "city", "classific2", "explain2", "true"));
		s.add(new Site("Name4", "city", "classific2", "explain2", "true"));
		s.add(new Site("Name5", "city", "classific2", "explain2", "true"));
		fillSitesTable(s);
		
		ArrayList<Tour> t= new ArrayList<Tour>();
		t.add(new Tour(1, "description", "city"));
		t.add(new Tour(2, "zdfg", "city"));
		t.add(new Tour(3, "descrzxfgiption", "city"));
		t.add(new Tour(4, "descrzxcsiption", "city"));
		fillToursTable(t);*/
	}
	
	@FXML
	Label cityName;
	
	@FXML
	TableView <Tour> tours;
	
	@FXML
	TableColumn<Tour, Integer> tourIDColumn;
	
	@FXML
	TableColumn<Tour, String> tourDescriptionColumn;
	
	@FXML
	TableView <Site> sites;
	
	@FXML
	TableColumn<Site, String> siteNameColumn;
	
	@FXML
	Label noSelection;
	
	/**
	 * Saves the selected site and goes to editSite window
	 * @param event
	 */
	@FXML
	void editSite(ActionEvent event) 
	{
		if(sites.getSelectionModel().getSelectedItem()==null)
		{
			noSelection.setVisible(true);
			return;
		}
		currentSite = sites.getSelectionModel().getSelectedItem();
		try {
			openWindow(event, "EditSite", "application");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Saves the selected tour and goes to editTour window
	 * @param event
	 */
	@FXML
	void editTour(ActionEvent event)
	{
		if(tours.getSelectionModel().getSelectedItem()==null)
		{
			noSelection.setVisible(true);
			return;
		}
		currentTour=tours.getSelectionModel().getSelectedItem();
		try {
			openWindow(event, "EditTourInCity", "application");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	/**
	 * goes to AddTour window
	 * @param event
	 */
	@FXML
	void addTour(ActionEvent event)
	{
		try {
			openWindow(event, "AddTour", "application");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * goes to AddSite window
	 * @param event
	 */
	@FXML
	void addSite(ActionEvent event)
	{
		try {
			openWindow(event, "AddSite", "application");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * "delete site" button press -delete site and update the database.
	 * @param event
	 */
	@FXML
	void deleteSite(ActionEvent event)
	{
		if(sites.getSelectionModel().getSelectedItem()==null)
		{
			noSelection.setVisible(true);
			return;
		}
		Site site=sites.getSelectionModel().getSelectedItem();
		QueryCommunicator Qcom=QueryCreator.deleteSite(site.getSiteName(), site.getCityName()); //delete site from sql
		userClient.handleMessageFromClientUI(Qcom);
		
		sitesList.remove(sites.getSelectionModel().getSelectedItem()); //remove site from sites table
		sites.getItems().setAll(sitesList);
		
		popUpWindow(site.getSiteName()+" has been deleted!");
	}
	
	/**
	 * "delete tour" button press -delete all the site in the tour, delete the tour and update the database.
	 * @param event
	 */
	@FXML
	void deleteTour(ActionEvent event)
	{
		if(tours.getSelectionModel().getSelectedItem()==null)
		{
			noSelection.setVisible(true);
			return;
		}
		currentTour=tours.getSelectionModel().getSelectedItem();
		
		int tourID=(tours.getSelectionModel().getSelectedItem()).getIDTour();
		QueryCommunicator Qcom;
		Qcom=QueryCreator.deleteSiteFromTour(tourID); //delete all sites of tour from sql
		userClient.handleMessageFromClientUI(Qcom);
		
		Qcom=QueryCreator.deleteTour(tourID); //delete tour from sql
		userClient.handleMessageFromClientUI(Qcom);
		
		toursList.remove(tours.getSelectionModel().getSelectedItem()); //remove from table
		tours.getItems().setAll(toursList);
		
		popUpWindow("Tour no."+tourID+" has been deleted!");
	}
	/**
	 * gets all the sites in the city and present them in the table
	 * @param arr
	 */
	public void fillSitesTable(ArrayList<Site> arr)
	{
		sitesArr=arr;
		for(Site site: arr)
		{
			sitesList.add(site);
		}
		sites.getItems().setAll(sitesList);
	}
	/**
	 * gets all the tours in the city and present them in the table
	 * @param arr
	 */
	public void fillToursTable(ArrayList<Tour> arr)
	{
		toursArr=arr;
		for(Tour tour: arr)
		{
			toursList.add(tour);
		}
		tours.getItems().setAll(toursList);
	}
	
	/**
	 * "back" button press- go to "EmployeeHome" screen if is it employee. if the user is manager go to "ManagerHome" screen.
	 * @param event
	 * @throws IOException
	 */
	@FXML
	void back(ActionEvent event) throws IOException
	{
		if(ChooseCityToEditController.cityToEdit==null)
			openWindow(event, "EditMapWithPic", "application");
		else {
			ChooseCityToEditController.cityToEdit=null;
			switch(LoginController.user.getPermission())
	    	{
	    	case 2:
	    		openWindow(event, "EmployeeHome", "application");
	    		break;
	    	case 3:
	    	case 4:
	    		openWindow(event, "ManagerHome", "application");
	    		break;
	    	}
		}
	
	}
}
