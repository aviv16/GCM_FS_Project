package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.UserClient;
import entity.Site;
import entity.SiteType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;

public class AddSiteController extends OpenWindowClass implements Initializable {
	/**
	 * The class AddDurationAndSerialController
	 */
	public static ArrayList<SiteType> siteTypes=null;
	UserClient userClient;
	public static AddSiteController controller;
	
	/**
	 * Sets the userClient from ConnectToServerClass to communicate with the server through it, and sends "this" to get feedback from the server
	 * sends query to the server asking for all the types of the sites
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
		userClient=ConnectToServerClass.userClient;
		userClient.setAddSite(this);
		controller=this;
		cityNameLabel.setText(EditCityController.currentCity.getName());
		QueryCommunicator Qcom=QueryCreator.getSiteType2();
		userClient.handleMessageFromClientUI(Qcom);
	}

	@FXML
	Label cityNameLabel;
	
	@FXML
	Label errorLabel;
	
	@FXML
	JFXTextField siteNameTxt;
	
	@FXML
	TextArea siteDescriptionTxt;
	
	@FXML
	 JFXComboBox <String> siteTypeCB;
	
	@FXML
	JFXCheckBox accessability;
	
	ObservableList<String> sitesTypesList;
	
	/**
	 * sends query to the server to enter the new site into the database
	 * @param event
	 * @throws IOException
	 */
	public void saveSite(ActionEvent event) throws IOException
	{
		String accessible=new String();
		if(accessability.isSelected())
			accessible="true";
		else accessible="false";
		errorLabel.setVisible(false);
		for(Site site: EditCityController.sitesArr)
		{
			if(site.getSiteName().equals(siteNameTxt.getText()))
			{
				errorLabel.setText("Site name already exist!");
				errorLabel.setVisible(true);
				return;
			}
		}
		QueryCommunicator Qcom=QueryCreator.addSite(siteNameTxt.getText(),EditCityController.currentCity.getName(),
				siteTypeCB.getValue(),siteDescriptionTxt.getText(), accessible);
		userClient.handleMessageFromClientUI(Qcom);
		popUpWindow(siteNameTxt.getText()+" has been added!");
		openWindow(event, "EditCity", "application");
	}
	/**
	 * goes back to editCity window
	 * @param event
	 * @throws IOException
	 */
	public void cancel(ActionEvent event) throws IOException
	{
		openWindow(event, "EditCity", "application");
	}
	/**
	 * Opens new window to add new type
	 * @param event
	 * @throws IOException
	 */
	public void addSiteType(ActionEvent event) throws IOException
	{
		openWindowWithoutClosingCurrent("AddTypeToSite", "application");
	}
	/**
	 *Gets ArrayList of types and sets them into the combobox
	 * @param types
	 */
	public void setSitesType(ArrayList<SiteType> types)
	{
		siteTypes=types;
		sitesTypesList=FXCollections.observableArrayList();
		for(SiteType type: types)
		{
			sitesTypesList.add(type.getName());
		}
		siteTypeCB.setItems(sitesTypesList);
	} 
	
	/**
	 * Updating in the combobox the new types of sites that were added
	 */
	public void updateSitesType()
	{
		for(SiteType type: siteTypes)
		{
			if(!sitesTypesList.contains(type.getName()))
				sitesTypesList.add(type.getName());
		}
		siteTypeCB.setItems(sitesTypesList);
	}
}
