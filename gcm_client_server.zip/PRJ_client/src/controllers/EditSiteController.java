package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.UserClient;
import entity.Site;
import entity.SiteType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXComboBox;


public class EditSiteController extends OpenWindowClass implements Initializable {

	/**
	 * The class EditSiteController
	 *
	 */
	Site site;
	UserClient userClient;
	public static ArrayList<SiteType> siteTypes=null;
	public static EditSiteController controller;
	/**
	 * Sets the userClient from ConnectToServerClass to communicate with the server through it, and sends "this" to get feedback from the server
	 * ask from the server for the types of the sites and sets all the information of the site
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		userClient = ConnectToServerClass.userClient;
		userClient.setEditSite(this);
		controller=this;
		site=EditCityController.currentSite;
		siteNameLabel.setText(site.getSiteName());
		cityNameLabel.setText(EditCityController.currentCity.getName());
		siteDescriptionTxt.setText(site.getExplanation());
		if(site.getAccessibility().equals("true"))
			accessability.setSelected(true);
		QueryCommunicator Qcom=QueryCreator.getSiteType();
		userClient.handleMessageFromClientUI(Qcom);
		
		/*//TEST
		ArrayList<SiteType> s= new ArrayList<SiteType>();
		s.add(new SiteType("class1"));
		s.add(new SiteType("class2"));
		s.add(new SiteType("classific"));
		setSitesType(s);*/
	}

	@FXML
	Label siteNameLabel;
	
	@FXML
	Label cityNameLabel;
	
	@FXML
	TextArea siteDescriptionTxt;
	
	@FXML
	JFXCheckBox accessability;
	
	@FXML
	JFXComboBox<String> siteTypeCB;
	
	public static ObservableList<String> sitesTypesList;
	
	/**
	 * saves all the information on the site and send query to change it on the database
	 * goes back to editCity afterwards
	 * @param event
	 * @throws IOException
	 */
	public void saveSite(ActionEvent event) throws IOException
	{
		String accessible=new String();
		if(accessability.isSelected())
			accessible="true";
		else accessible="false";
		QueryCommunicator Qcom=QueryCreator.updateSiteInfoQuery(site.getSiteName(),EditCityController.currentCity.getName(),
				siteTypeCB.getValue(),siteDescriptionTxt.getText(), accessible);
		userClient.handleMessageFromClientUI(Qcom);
		popUpWindow(site.getSiteName()+" details has changed!");
		openWindow(event, "EditCity", "application");
		//reset the site saved in the window maybe?
	}
	
	/**
	 * cancels the edit and goes back to editCity window
	 * @param event
	 * @throws IOException
	 */
	public void cancel(ActionEvent event) throws IOException
	{
		openWindow(event, "EditCity", "application");
	}
	
	/**
	 * open new window to add new type of site
	 * @param event
	 * @throws IOException
	 */
	public void addSiteType(ActionEvent event) throws IOException
	{
		openWindowWithoutClosingCurrent("AddTypeToSite", "application");
		System.out.println("check");
	}
	
	/**
	 * gets ArrayList with all the types and sets them in the combobox
	 * also set the default choice to the the current type of the site
	 * @param types
	 */
	public void setSitesType(ArrayList<SiteType> types)
	{
		siteTypes=types;
		sitesTypesList=FXCollections.observableArrayList();
		for(SiteType type: types)
		{
			sitesTypesList.add(type.getName());
		}
		siteTypeCB.setItems(sitesTypesList);
		siteTypeCB.getSelectionModel().select(site.getClassifcation());
	} 
	
	/**
	 * fill the comboBox siteType
	 */
	public void updateSitesType()
	{
		for(SiteType type: siteTypes)
		{
			if(!sitesTypesList.contains(type.getName()))
				sitesTypesList.add(type.getName());
		}
		siteTypeCB.setItems(sitesTypesList);
	}
}
	
