package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import com.jfoenix.controls.JFXTextField;


public class AddDurationAndSerialController extends OpenWindowClass {
	/**
	 * The class AddDurationAndSerialController
	 */
	@FXML
	JFXTextField durationTxt;
	
	@FXML
	JFXTextField positionTxt;
	
	@FXML 
	Label wrongInputLabel;
	
	/**
	 * Adds the duration and serial number of the site on the tour on the DB only if the input is legal
	 * @param event
	 */
	public void addSiteToTour(ActionEvent event)
	{
		wrongInputLabel.setVisible(false);
		if(durationTxt.getText().equals("")||positionTxt.getText().equals(""))
		{
			wrongInputLabel.setText("Empty Field!");
			wrongInputLabel.setVisible(true);
			return;
		}
		for(int i=0;i<durationTxt.getText().length();i++)
		{
			if(!Character.isDigit(durationTxt.getText().charAt(i)))
			{
				wrongInputLabel.setText("Must Be Integer");
				return;
			}
		}
		for(int i=0;i<positionTxt.getText().length();i++)
		{
			if(!Character.isDigit(positionTxt.getText().charAt(i)))
			{
				wrongInputLabel.setText("Must Be Integer");
				return;
			}
		}
		
		if((EditTourController.editTourCon)!=null)
			EditTourController.editTourCon.addDurAndPos(Integer.parseInt(durationTxt.getText()), Integer.parseInt(positionTxt.getText()));
			else if(AddTourController.addTourCon!=null)
				AddTourController.addTourCon.addDurAndPos(Integer.parseInt(durationTxt.getText()), Integer.parseInt(positionTxt.getText()));
		closeWindow(event);
	}
	
	/**
	 * Closes the AddDurationAndSerial window 
	 * @param event
	 */
	public void cancel(ActionEvent event)
	{
		closeWindow(event);
	}
}
