package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.ResourceBundle;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import client.UserClient;
import entity.City;
import entity.newCity;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn.CellEditEvent;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;

public class ChangePricesCompanyManagerController extends OpenWindowClass implements Initializable {

	/**
	 * The class ChangePricesCompanyManagerController
	 */
	@FXML
	TableView<fillCityTable> table;

	@FXML
	private TableColumn<fillCityTable, String> cityName;

	@FXML
	private TableColumn<fillCityTable, Double> price;

	@FXML
	private TableColumn<fillCityTable, String> newPrice;

	public ObservableList<fillCityTable> ClientPurchaseList;

	public static ArrayList<City> cityArr;
	public static ArrayList<newCity> newCityArr;

	ConnectToServerClass conToServer;
	UserClient userClient;
	QueryCommunicator Qcom;
//
//	public static int flag = 0;
//	final Lock lock = new ReentrantLock();
//	final Condition dbAvalibale = lock.newCondition();
//	
//	public static int flag1 = 0;
//	final Lock lock1 = new ReentrantLock();
//	final Condition dbAvalibale1 = lock.newCondition();

	/**
	 * sets instance of this controller in userClient to get data from server
	 * sends query to get data on changed prices
	 * Initializing the tables
	 */
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		userClient = ConnectToServerClass.userClient;
		userClient.setChangePricesCompanyManager(this);

		// ������ ������� ���� �� �� ������� �� ����
		Qcom = QueryCreator.getCityQuery5();
		userClient.handleMessageFromClientUI(Qcom);
//		lock.lock();
//		while (flag == 0)
//			try {
//				dbAvalibale.await();
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		lock.unlock();

		Qcom = QueryCreator.getnewPrice();
		userClient.handleMessageFromClientUI(Qcom);
//		lock1.lock();
//		while (flag1 == 0)
//			try {
//				dbAvalibale1.await();
//			} catch (InterruptedException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		lock1.unlock();

		try {
			Thread.sleep(50);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// System.out.println("before");
		cityName.setCellValueFactory(new PropertyValueFactory<fillCityTable, String>("cityName"));
		cityName.setStyle("-fx-alignment: CENTER;");
		// System.out.println("after");
		price.setCellValueFactory(new PropertyValueFactory<fillCityTable, Double>("price"));
		price.setStyle("-fx-alignment: CENTER;");
		newPrice.setCellValueFactory(new PropertyValueFactory<fillCityTable, String>("newPrice"));
		newPrice.setStyle("-fx-alignment: CENTER;");

		if (cityArr != null) {

			Collections.sort(cityArr, new CityNameComperator());
			if (newCityArr.size() > 0) {
				Collections.sort(newCityArr, new NewCityNameComperator());
			}

			ArrayList<fillCityTable> temp = new ArrayList<>();
			for (int i = 0; i < cityArr.size(); i++) {
				fillCityTable p = new fillCityTable(cityArr.get(i));
				for (int j = 0; j < newCityArr.size(); j++)
					if (newCityArr.get(j).getName().equals(cityArr.get(i).getName())) {
						p.setNewPrice(Double.toString(newCityArr.get(i).getRate()));
					}
				temp.add(p);
			}
			table.getItems().setAll(temp);
		}

		// ����� ����� �� ����� ���� �����
		table.setEditable(true);
		newPrice.setCellFactory(TextFieldTableCell.forTableColumn());

	}
	
	/**
	 * Saves the changed prices and updates them in the database
	 * @param event
	 * @throws IOException
	 */
	public void changePrices(ActionEvent event) throws IOException {
		// ���� �� ������ ������ �DB
		for (fillCityTable row : table.getItems()) {
			if (row.getNewPrice() != "") {
				System.out.println(row.getCityName() + " " + row.getNewPrice());
				Qcom = QueryCreator.UpdatePrices(row.getCityName(), Double.parseDouble(row.getNewPrice()));
				userClient.handleMessageFromClientUI(Qcom);
			}
		}
		Qcom = QueryCreator.DeleteFromNewprice();
		userClient.handleMessageFromClientUI(Qcom);
		popUpWindow("Change Prices Complete!");
		openWindow(event, "ManagerHome", "application");

	}

	/**
	 *  save the new value that the worker changed
	 * @param event
	 */
	public void onEditChange(CellEditEvent<fillCityTable, String> event) {
		fillCityTable f = table.getSelectionModel().getSelectedItem();
		f.setNewPrice(event.getNewValue());
	}
	
	/**
	 * cancel and go back to home page
	 * @param event
	 * @throws IOException
	 */
	public void cancel(ActionEvent event) throws IOException {
		openWindow(event, "ManagerHome", "application");
	}

	/**
	 * gets cities to fill table
	 * @param cityArry
	 */
	public void setCity(ArrayList<City> cityArry) {
		cityArr = cityArry;
//		flag = 1;
//		lock.lock();
//		dbAvalibale.signalAll();
//		lock.unlock();
	}



	/**
	 * gets the cities with the changed prices
	 * @param cityArry
	 */
	public void setNewCity(ArrayList<newCity> cityArry) {
		newCityArr = cityArry;
//		flag1 = 1;
//		lock1.lock();
//		dbAvalibale1.signalAll();
//		lock1.unlock();
	}
	
	/**
	 * class to present all the relevant data in table
	 *
	 *
	 */
	public class fillCityTable {
		private String cityName;
		private Double price;
		private String newPrice;

		fillCityTable(City city) {
			cityName = city.getName();
			price = city.getRate();
			newPrice = "";
		}

		public String getCityName() {
			return cityName;
		}

		public void setCityName(String cityName) {
			this.cityName = cityName;
		}

		public Double getPrice() {
			return price;
		}

		public void setPrice(Double price) {
			this.price = price;
		}

		public String getNewPrice() {
			return newPrice;
		}

		public void setNewPrice(String newPrice) {
			this.newPrice = newPrice;
		}

	}
}
