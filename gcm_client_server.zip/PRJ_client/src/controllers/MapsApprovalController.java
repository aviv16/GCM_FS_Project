package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import entity.Map;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;


public class MapsApprovalController extends OpenWindowClass implements Initializable{

	/**
	 *  MapsApprovalController the manager approve the map
	 *
	 */
	ObservableList<Map> approvalMaps;
	public static Map chosenMap;
	
	/**
	 * Initialize the screen take from ManagerHomeController the map to approve
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		if(ManagerHomeController.approvalMaps==null)
		{
			noMaps.setVisible(true);
			return;
		}
		chosenMap=null;
		approvalMaps=FXCollections.observableArrayList();
		mapIDColumn.setCellValueFactory(new PropertyValueFactory<Map, Integer>("IDMap"));
		mapIDColumn.setStyle( "-fx-alignment: CENTER;");
		cityNameColumn.setCellValueFactory(new PropertyValueFactory<Map, String>("cityName"));
		cityNameColumn.setStyle( "-fx-alignment: CENTER;");
		descriptionColumn.setCellValueFactory(new PropertyValueFactory<Map, String>("textualDescription"));
		descriptionColumn.setStyle( "-fx-alignment: CENTER;");
		if((ManagerHomeController.approvalMaps==null)||(ManagerHomeController.approvalMaps.size()==0)) // to check
		{
			noMaps.setVisible(true);
		}
		else {
			for (Map map : ManagerHomeController.approvalMaps)
			{
				approvalMaps.add(map);
			}
			mapsTable.getItems().setAll(approvalMaps);
		}
	}
	
    @FXML
    private TableView<Map> mapsTable;

    @FXML
    private TableColumn<Map, Integer> mapIDColumn;

    @FXML
    private TableColumn<Map, String> cityNameColumn;

    @FXML
    private TableColumn<Map, String> descriptionColumn;

    @FXML
    private Label noMaps;

    /**
	 *press "back" switch to "ManagerHome" screen.
	 * @param event
	 */
    @FXML
    void back(ActionEvent event) 
    {
    	chosenMap=null;
    	try {
			openWindow(event, "ManagerHome", "application");
		} catch (IOException e) { 
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    /**
	 * press "Edit Map" switch to "EditMapWithPic" screen.
	 * @param event
	 */
    @FXML
    void toEditMap(ActionEvent event) {
    	//maybe check if something selected first
    	chosenMap=mapsTable.getSelectionModel().getSelectedItem();
    	try {
			openWindow(event, "EditMapWithPic", "application");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

	

}
