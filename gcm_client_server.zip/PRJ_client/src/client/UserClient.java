package client;

import java.io.IOException;
import java.util.ArrayList;

import controllers.AddCityController;
import controllers.AddSiteController;
import controllers.AddTourController;
import controllers.AddTypeToSiteController;
import controllers.ChangePricesCompanyManagerController;
import controllers.ChangePricesDepartmentDirectorController;
import controllers.ChooseCityToEditController;
import controllers.ConnectToServerClass;
import controllers.CreateReportController;
import controllers.EditCityController;
import controllers.EditMapController;
import controllers.EditSiteController;
import controllers.EditTourController;
import controllers.EmployeeHomeController;
import controllers.HomeController;
import controllers.LoginController;
import controllers.ManagerHomeController;
import controllers.MapImageController;
import controllers.PurchaseSubscriptionController;
import controllers.RegistrationController;
import controllers.SearchInCatalogController;
import controllers.SendDataClass;
import controllers.ShowReportController;
import controllers.SubscriptionRenewalController;
import controllers.ViewCityInMapCatalogController;
import controllers.ViewClientCardController;
import controllers.ViewPurchaseCitiesController;
import entity.City;
import entity.Client;
import entity.ClientPurchase;
import entity.Map;
import entity.RegisteredUser;
import entity.Site;
import entity.SiteInMap;
import entity.SiteInTour;
import entity.SiteType;
import entity.Tour;
import entity.newCity;
import entity.report;
import ocsf.client.*;

//the class the connects between the controller and the server
public class UserClient extends AbstractClient {
	// Class variables

	ConnectToServerClass conToServer;
	// ***************************** maybe instead of static methods in controllers,
	// save the instances of the controllers in here
	/**
	 * Saves the controllers that use the connection to server through it so that it
	 * will be able to send them messages back.
	 */
	LoginController loginCon;
	RegistrationController regCon;
	SearchInCatalogController searchInCatalogCon;
	AddCityController addCityCon;
	EditSiteController editSiteCon;
	EditCityController editCityCon;
	AddTypeToSiteController addTypeToSiteCon;
	AddSiteController addSiteCon;
	EditTourController editTourCon;
	AddTourController addTourCon;
	HomeController HomeCon;
	ViewClientCardController clientCardCon;
	ViewCityInMapCatalogController viewCityInMapCatalogCon;
	PurchaseSubscriptionController PurchaseSubscriptionCon;
	EditMapController editMapCon;
	CreateReportController createReportCon;
	ShowReportController showReportCon;
	SubscriptionRenewalController subscriptionRenewalCon;
	ManagerHomeController managerHomeCon;
	ChangePricesDepartmentDirectorController ChangePricesDepartmentCon;
	ChangePricesCompanyManagerController changePricesManagerCon;
	EmployeeHomeController EmployeeHomeCon;
	ViewPurchaseCitiesController viewPurchaseCitiesCon;
	MapImageController mapImageCon;
	ChooseCityToEditController chooseCityToEditCon;
	
	public void setLogin(LoginController controller) {
		loginCon = controller;
	}

	public void setRegistration(RegistrationController controller) {
		regCon = controller;
	}

	public void setSearchInCatalog(SearchInCatalogController controller) {
		searchInCatalogCon = controller;
	}

	public void setAddCity(AddCityController addCityController) {
		addCityCon = addCityController;
	}

	public void setEditSite(EditSiteController editSiteController) {
		editSiteCon = editSiteController;
	}

	public void setEditCity(EditCityController editCityController) {
		editCityCon = editCityController;
	}

	public void setAddTypeToSite(AddTypeToSiteController addTypeToSiteController) {
		addTypeToSiteCon = addTypeToSiteController;
	}

	public void setAddSite(AddSiteController addSiteController) {
		addSiteCon = addSiteController;
	}

	public void setEditTour(EditTourController editTourController) {
		editTourCon = editTourController;
	}

	public void setAddTour(AddTourController addTourController) {
		addTourCon = addTourController;
	}

	public void setHome(HomeController controller) {
		HomeCon = controller;
	}

	public void setViewClientCard(ViewClientCardController controller) {
		clientCardCon = controller;
	}

	public void setViewCityInMapCatalog(ViewCityInMapCatalogController viewCityInMapCatalog) {
		viewCityInMapCatalogCon = viewCityInMapCatalog;
	}

	public void setPurchaseSubscription(PurchaseSubscriptionController controller) {
		PurchaseSubscriptionCon = controller;
	}

	public void setEditMap(EditMapController controller) {
		editMapCon = controller;
	}

	public void setCreateReport(CreateReportController createReportController) {
		createReportCon = createReportController;
	}

	public void setShowReport(ShowReportController showReportController) {
		showReportCon = showReportController;
	}

	public void setSubscriptionRenewalController(SubscriptionRenewalController subscriptionRenewalController) {
		subscriptionRenewalCon = subscriptionRenewalController;
	}

	public void setManagerHome(ManagerHomeController managerHomeController) {
		managerHomeCon = managerHomeController;
	}

	public void setChangePricesDepartmentDirector(ChangePricesDepartmentDirectorController changePrice) {
		ChangePricesDepartmentCon = changePrice;
	}

	public void setChangePricesCompanyManager(ChangePricesCompanyManagerController controller) {
		changePricesManagerCon = controller;
	}

	public void setEmployeeHome(EmployeeHomeController controller) {
		EmployeeHomeCon = controller;
	}
	public void setViewPurchaseCities(ViewPurchaseCitiesController viewPurchaseCitiesController) {
		viewPurchaseCitiesCon=viewPurchaseCitiesController;
	}
	public void setMapImage(MapImageController mapImageController) {
		 mapImageCon=mapImageController;
	}
	public void setChooseCityToEdit(ChooseCityToEditController chooseCityToEditController) {
		chooseCityToEditCon=chooseCityToEditController;		
	}
	// *****************************
	// Class methods
	/**
	 * creates a concrete client to communicate with the server. Open the connection
	 * to the server.
	 * 
	 * @param host
	 * @param port
	 * @param clientCon
	 * @throws IOException
	 */

	public UserClient(String host, int port, ConnectToServerClass conToServer) throws IOException {
		super(host, port);
		this.conToServer = conToServer;
		openConnection(); // opens the connection to the server (AbstractClient method)
	}

	public UserClient(String host, int port) throws IOException {
		super(host, port);
		openConnection(); // opens the connection to the server (AbstractClient method)
	}

	/**
	 * gets message from server and transfer it to the relevant controller and method
	 * @param msg
	 */
	@Override
	protected void handleMessageFromServer(Object msg) {
		//clientCon.setCities((ArrayList <String>)msg); 	//send the cities that the server got from the DB to the controller
		
		SendDataClass sendData=(SendDataClass)msg;
		switch(sendData.getScreenName())
		{
		case "Login":
			if(sendData.getData() instanceof RegisteredUser)
				loginCon.userReceived((RegisteredUser)(sendData.getData()));
			else if (sendData.getData() instanceof Boolean)
				loginCon.userReceived(null);
			break;
		case "Registration":
			if(sendData.getData() instanceof Boolean)
				regCon.userExist((Boolean)sendData.getData());
			break;
		case "SearchInCatalog":
			if (sendData.getData()==null) break;
			if(sendData.getData() instanceof ArrayList)
			{
				ArrayList list=(ArrayList)(sendData.getData());
				if(list.size()==0)
					break;
				if(list.get(0) instanceof City)
				{
					searchInCatalogCon.setCityArray(list);
				}
				else if(list.get(0) instanceof Site)
				{
					searchInCatalogCon.setSiteArray(list);
				}
				else if(list.get(0) instanceof Map)
				{
					searchInCatalogCon.setMapsArray(list);
				}
			}
			break;
		case "AddCity":
			if (sendData.getData() instanceof ArrayList) {
				ArrayList list4 = (ArrayList) (sendData.getData());
				if (list4.size() == 0|| list4.size()>0) {
					addCityCon.setCityExist((ArrayList<City>) list4);
				}
			}
			break;
		case "EditCity":
			if(sendData.getData() instanceof ArrayList)
			{
				ArrayList list=(ArrayList)(sendData.getData());
				if(list.size()==0)
					break;
				if(list.get(0) instanceof Tour)
				{
					editCityCon.fillToursTable(list);
				}
				if(list.get(0) instanceof Site)
				{
					editCityCon.fillSitesTable(list);
				}
			}
			break;
		case "EditSite":
			ArrayList list=(ArrayList)(sendData.getData());
			editSiteCon.setSitesType(list);;
			break;
		case "AddSite":
			ArrayList list3=(ArrayList)(sendData.getData());
			addSiteCon.setSitesType(list3);
			break;
		case "AddTourToCity":
			ArrayList list1=(ArrayList)(sendData.getData());
			addTourCon.setTour((Tour)list1.get(0));
			break;
		case "EditTourInCity":
			ArrayList list2=(ArrayList)(sendData.getData());
			editTourCon.fillTables((ArrayList<SiteInTour>)list2);
			break;
		case "ViewClientCard":
			System.out.println("userclient");
			if(sendData.getData() instanceof RegisteredUser)
			{
				clientCardCon.setUser((RegisteredUser)(sendData.getData()));
			}
			if(sendData.getData() instanceof ArrayList)
			{
				ArrayList list4=(ArrayList)(sendData.getData());
				if(list4.size()==0)
				{
					clientCardCon.setclientPurchaset(list4);
					break;
				}
				if(list4.get(0) instanceof Client)
				{
					clientCardCon.setClient(list4);
				}
				if(list4.get(0) instanceof ClientPurchase)
				{
					clientCardCon.setclientPurchaset(list4);
				}
			}
			break;
		case "ViewCityInMapCatalog":
			if(sendData.getData() instanceof ArrayList)
			{
				ArrayList list4=(ArrayList)(sendData.getData());
				if(list4.size()==0)
					break;
				if(list4.get(0) instanceof Map)
				{
					viewCityInMapCatalogCon.fillMapTable((ArrayList<Map>)list4);
				}
				else if(list4.get(0) instanceof Tour)
				{
					viewCityInMapCatalogCon.setNumberOfTours((ArrayList<Tour>)list4);
				}
			}
			break;
		case "EditMapWithPic":
			if (sendData.getData() instanceof ArrayList) {
				ArrayList list5 = (ArrayList) (sendData.getData());
				if(editMapCon.missingSitesListFlag==3)
				{
					editMapCon.setMostUpdatedMap((ArrayList<Map>)list5);
					break;
				}
				if(list5.size()==0) {
					if(editMapCon.missingSitesListFlag==0)//means map id don't exist
					{
						try {
							editMapCon.fillMapFields((ArrayList<Map>) list5);
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();}
					}
					else if(editMapCon.missingSitesListFlag==1)//means no site for city
					{
						editMapCon.initializeCitySites((ArrayList<Site>) list5);
					}
					else if(editMapCon.missingSitesListFlag==2)//means no sites in map
					{
						editMapCon.initializeMapSites((ArrayList<SiteInMap>) list5);
					}
					break;
				}
				if (list5.get(0) instanceof Map) { 
					try {
						editMapCon.fillMapFields((ArrayList<Map>) list5);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();}
				}
				if (list5.get(0) instanceof City) {
					editMapCon.fillCityList((ArrayList<City>) list5);
				}
				if (list5.get(0) instanceof Site) {
					System.out.println("I see sites");
					editMapCon.initializeCitySites((ArrayList<Site>) list5);	
				}
				if(list5.get(0) instanceof SiteInMap)
				{	
					editMapCon.initializeMapSites((ArrayList<SiteInMap>) list5);
				}
			}
			break;
		case "createReport":
			if (sendData.getData() instanceof ArrayList) {
				ArrayList list4=(ArrayList)(sendData.getData());
				if(list4.size()==0)
					break;
				if (list4.get(0) instanceof City) {
					createReportCon.setCities((ArrayList<City>) list4);
				}
			}
			break;
		case "showReport":
			if (sendData.getData() instanceof ArrayList) {
				ArrayList list4=(ArrayList)(sendData.getData()); 
				if(list4.size()==0)
					break;
				if (list4.get(0) instanceof Map) {
					showReportCon.getCityMap((ArrayList<Map>) list4);
					break;
				}
				if (list4.get(0) instanceof ClientPurchase) {
					showReportCon.setAllPurchases((ArrayList<ClientPurchase>) list4);
					break;
				}
				if (list4.get(0) instanceof report) {
					showReportCon.setReports((ArrayList<report>) list4);
				}
			}
			break;
		case "PurchaseSubscription":
			if(sendData.getData() instanceof ArrayList)
			{
				ArrayList list6=(ArrayList)(sendData.getData());
				if((PurchaseSubscriptionCon.updateReportFlag>0)&&(PurchaseSubscriptionCon.updateReportFlag==PurchaseSubscriptionCon.mapList.size()))
				{
					PurchaseSubscriptionCon.setReport((ArrayList<report>)list6);
				}
				if(list6.size()==0)
				{
					PurchaseSubscriptionCon.setFillSite((ArrayList<SiteInMap>)list6);
					break;
				}
				if(list6.get(0) instanceof SiteInMap)
				{
					PurchaseSubscriptionCon.setFillSite((ArrayList<SiteInMap>)list6);
				}
//				if(list6.get(0) instanceof Tour)
//				{
//					PurchaseSubscriptionCon.setFillTour((ArrayList<Tour>)list6);
//				}
				else if(list6.get(0) instanceof Map)
				{
					PurchaseSubscriptionCon.setMapList((ArrayList<Map>)list6);
				}
			}
			break;
		case "Home":
			if(sendData.getData() instanceof ArrayList)
			{
				ArrayList list4=(ArrayList)(sendData.getData());
				if(list4.size()==0)
				{
					HomeCon.handleRenewals((ArrayList<ClientPurchase>)list4);
					break;
				}
				if(list4.get(0) instanceof City)
				{
					HomeCon.setCities((ArrayList<City>)list4);
				}
				if(list4.get(0) instanceof ClientPurchase)
				{
					HomeCon.handleRenewals((ArrayList<ClientPurchase>)list4);
				}
			}
			break;
		case "ManagerHome":
			if (sendData.getData() instanceof ArrayList) {
				ArrayList list4 = (ArrayList) (sendData.getData());
				if (list4.size() == 0) {
					break;
				}
				if (list4.get(0) instanceof Map) {
					managerHomeCon.setMapsToApprove((ArrayList<Map>) list4);
				}
				if (list4.get(0) instanceof newCity) {
					managerHomeCon.setNewCityToApprove((ArrayList<newCity>) list4);
				}
				if (list4.get(0) instanceof Client) {
					managerHomeCon.setAllClient((ArrayList<Client>) list4);
				}
			}
			break;
		case "ChangePricesDepartmentDirector":
			if (sendData.getData() instanceof ArrayList) {
				ArrayList list4 = (ArrayList) (sendData.getData());
				if (list4.size() == 0) {
					ChangePricesDepartmentCon.setCity((ArrayList<City>) list4);
					break;
				}
				if (list4.get(0) instanceof City) {
					ChangePricesDepartmentCon.setCity((ArrayList<City>) list4);
				}
			}
			break;
		case "ChangePricesCompanyManager":
			if (sendData.getData() instanceof ArrayList) {
				ArrayList list4 = (ArrayList) (sendData.getData());
				if (list4.size() == 0) {
					//changePricesManagerCon.setCity((ArrayList<City>) list4);
					changePricesManagerCon.setNewCity((ArrayList<newCity>) list4);
					break;
				}
				if (list4.get(0) instanceof City) {
					changePricesManagerCon.setCity((ArrayList<City>) list4);
				}
				if (list4.get(0) instanceof newCity) {
					changePricesManagerCon.setNewCity((ArrayList<newCity>) list4);
				}
			}
			break;
		case "ViewPurchasedCities":
			if (sendData.getData() instanceof ArrayList) {
				ArrayList list4 = (ArrayList) (sendData.getData());
				if(viewPurchaseCitiesCon.isGotAllMaps)
				{
					viewPurchaseCitiesCon.setReport((ArrayList<report>)list4);
					break;
				}
				if (list4.size() == 0) {
					viewPurchaseCitiesCon.setMapsOfCity((ArrayList<Map>)list4);
					break;
				}
				if (list4.get(0) instanceof Map) {
					viewPurchaseCitiesCon.setMapsOfCity((ArrayList<Map>)list4);
				}
			}
			break;
		case "MapImage":
			if (sendData.getData() instanceof ArrayList) {
				ArrayList list4 = (ArrayList) (sendData.getData());
				if (list4.size() == 0) {
					mapImageCon.setSitesOfMap((ArrayList<SiteInMap>)list4);
					break;
				}
				if (list4.get(0) instanceof SiteInMap) {
					mapImageCon.setSitesOfMap((ArrayList<SiteInMap>)list4);
				}
			}
			break;
		case "ChooseCityToEdit":
			if (sendData.getData() instanceof ArrayList) {
				ArrayList list4 = (ArrayList) (sendData.getData());
				chooseCityToEditCon.setCities((ArrayList<City>)list4);
			}
			break;
		}
	}

	/**
	 * gets message from controller and sends it to server
	 * 
	 * @param message
	 */
	public void handleMessageFromClientUI(Object message) /// gets message from the controller and sends it to the
															/// server
	{
		try {
			sendToServer(message);
		} catch (IOException e) {
			quit();
		}
	}

	/**
	 * closes connection to the server
	 */
	public void quit() {
		try {
			closeConnection();
		} catch (IOException e) {
		}
		System.exit(0);
	}

	

}
