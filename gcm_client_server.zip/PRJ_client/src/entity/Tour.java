package entity;

import java.io.Serializable;

/**
 * The class Tour  (in client)
 *
 */
public class Tour implements Serializable {

	private static final long serialVersionUID = 1L;
	private int IDTour;
	private String description;
	private String cityName;

	/**
	 * Tour constructor
	 * 
	 * @param IDTour
	 * @param description
	 * @param cityName
	 */
	public Tour(int IDTour, String description, String cityName) {
		this.description = description;
		this.IDTour = IDTour;
		this.cityName = cityName;
	}

	/**
	 * get ID Tour
	 * 
	 * @return IDTour
	 */
	public int getIDTour() {
		return IDTour;
	}

	/**
	 * set ID Tour
	 * 
	 * @param iDTour
	 */
	public void setIDTour(int iDTour) {
		IDTour = iDTour;
	}

	/**
	 * get description
	 * 
	 * @return description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * set description
	 * 
	 * @param description
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * get city name
	 * 
	 * @return cityName
	 */
	public String getCityName() {
		return cityName;
	}

	/**
	 * set city name
	 * 
	 * @param cityName
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

}
