package entity;

import java.io.Serializable;

/**
 * The class SiteInMap (in client)
 *
 */
public class SiteInMap implements Serializable {

	private static final long serialVersionUID = 1L;
	private int mapID;
	private int mapVersion;
	private String siteName;
	private double xOnMap, yOnMap;

	/**
	 * 
	 * @param mapID
	 * @param mapVersion
	 * @param siteName
	 * @param xOnMap
	 * @param yOnMap
	 */
	public SiteInMap(int mapID, int mapVersion, String siteName, double xOnMap, double yOnMap) {
		this.mapID = mapID;
		this.mapVersion = mapVersion;
		this.siteName = siteName;
		this.xOnMap = xOnMap;
		this.yOnMap = yOnMap;
	}

	/**
	 * get map version
	 * 
	 * @return mapVersion
	 */
	public int getMapVersion() {
		return mapVersion;
	}

	/**
	 * set map version
	 * 
	 * @param mapVersion
	 */
	public void setMapVersion(int mapVersion) {
		this.mapVersion = mapVersion;
	}

	/**
	 * get x location in map
	 * 
	 * @return xOnMap;
	 */
	public double getxOnMap() {
		return xOnMap;
	}

	/**
	 * set x location in map
	 * 
	 * @param xOnMap
	 */
	public void setxOnMap(double xOnMap) {
		this.xOnMap = xOnMap;
	}

	/**
	 * get y location in map
	 * 
	 * @return yOnMap
	 */
	public double getyOnMap() {
		return yOnMap;
	}

	/**
	 * set x location in map
	 * 
	 * @param yOnMap
	 */
	public void setyOnMap(double yOnMap) {
		this.yOnMap = yOnMap;
	}

	/**
	 * get site name
	 * 
	 * @return siteName
	 */
	public String getSiteName() {
		return siteName;
	}

	/**
	 * set site name
	 * 
	 * @param siteName
	 */
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	/**
	 * get map ID
	 * 
	 * @return mapID
	 */
	public int getmapID() {
		return mapID;
	}

	/**
	 * set map ID
	 * 
	 * @param mapID
	 */
	public void setmapID(int mapID) {
		this.mapID = mapID;
	}

}
