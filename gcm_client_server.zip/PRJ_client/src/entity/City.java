package entity;

import java.io.Serializable;

/**
 * The Class City-in client
 */
public class City implements Serializable {
	private static final long serialVersionUID = 1L;
	private String name;
	private double rate;

	/**
	 * This is the constructor.
	 * 
	 * @param name The name of the city.
	 * @param rate The rate of the city.
	 */
	public City(String name, double rate) {
		this.name = name;
		this.rate = rate;
	}

	/**
	 * Get the names of the city.
	 * 
	 * @return the names of the city.
	 */
	public String getName() {
		return name;
	}

	/**
	 * Set the names of the city.
	 * 
	 * @param name The name of the city.
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Get the rate of the city.
	 * 
	 * @return the rate of the city.
	 */
	public double getRate() {
		return rate;
	}

	/**
	 * Set the rate of the city.
	 * 
	 * @param rate The rate of the city.
	 */
	public void setRate(double rate) {
		this.rate = rate;
	}
}