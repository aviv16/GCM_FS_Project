package entity;

import java.io.Serializable;

/**
 * The class Version (in client)
 *
 */
public class Version implements Serializable {

	private static final long serialVersionUID = 1L;
	private int versionNumber;
	private String status;

	/**
	 * get version number
	 * 
	 * @return getVersionNumber
	 */
	public int getVersionNumber() {
		return versionNumber;
	}

	/**
	 * set version number
	 * 
	 * @param versionNumber
	 */
	public void setVersionNumber(int versionNumber) {
		this.versionNumber = versionNumber;
	}

	/**
	 * get status
	 * 
	 * @return status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * set status
	 * 
	 * @param status
	 */
	public void setStatus(String status) {
		this.status = status;
	}

}
