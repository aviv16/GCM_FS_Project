package entity;

import java.io.Serializable;

/**
 * The class SiteInTour (in client)
 *
 */
public class SiteInTour implements Serializable {

	private static final long serialVersionUID = 1L;
	private int tourID;
	private int serialNumber;
	private int durationOfVisit;
	private String siteName;
	private String cityName;

	/**
	 * SiteInTour constructor
	 * 
	 * @param id
	 * @param serial
	 * @param duration
	 * @param site
	 * @param city
	 */
	public SiteInTour(int id, int serial, int duration, String site, String city) {
		tourID = id;
		serialNumber = serial;
		durationOfVisit = duration;
		siteName = site;
		cityName = city;
	}

	/**
	 * get serial number
	 * 
	 * @return serialNumber
	 */
	public int getSerialNumber() {
		return serialNumber;
	}

	/**
	 * set serial number
	 * 
	 * @param serialNumber
	 */
	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}

	/**
	 * get duration of visit
	 * 
	 * @return durationOfVisit
	 */
	public int getDurationOfVisit() {
		return durationOfVisit;
	}

	/**
	 * set duration of visit
	 * 
	 * @param durationOfVisit
	 */
	public void setDurationOfVisit(int durationOfVisit) {
		this.durationOfVisit = durationOfVisit;
	}

	/**
	 * get city name
	 * 
	 * @return cityName
	 */
	public String getCityName() {
		return cityName;
	}

	/**
	 * set city name
	 * 
	 * @param cityName
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	/**
	 * get site name
	 * 
	 * @return siteName
	 */
	public String getSiteName() {
		return siteName;
	}

	/**
	 * set site name
	 * 
	 * @param siteName
	 */
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	/**
	 * get tour Id
	 * 
	 * @return tourId
	 */
	public int getTourID() {
		return tourID;
	}

	/**
	 * set tour ID
	 * 
	 * @param tourID
	 */
	public void setTourID(int tourID) {
		this.tourID = tourID;
	}

}
