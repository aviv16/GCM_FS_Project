package entity;

import java.io.Serializable;

/**
 * The Class purchase
 */
public class Purchase implements Serializable{

	private static final long serialVersionUID = 1L;
	private int purchaseNumber;
	private int amountOfDownloads;
	
//	/**
//	 * get purchase number()
//	 * @return purchaseNumber;
//	 */
	public int getPurchaseNumber() {
		return purchaseNumber;
	}
//	/**
//	 * set purchase number()
//	 * @param purchaseNumber
//	 */
	public void setPurchaseNumber(int purchaseNumber) {
		this.purchaseNumber = purchaseNumber;
	}
//	/**
//	 * get amount of map downloads
//	 * @return
//	 */
	public int getAmountOfDownloads() {
		return amountOfDownloads;
	}
//	/**
//	 * set amount of map downloads
//	 * @param amountOfDownloads
//	 */
	public void setAmountOfDownloads(int amountOfDownloads) {
		this.amountOfDownloads = amountOfDownloads;
	}
	
}
