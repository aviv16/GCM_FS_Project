package entity;

import java.io.Serializable;
/**
 * The class site type (in client)
 *
 */
public class SiteType implements Serializable {

	private static final long serialVersionUID = 1L;
	
	String siteName;
	/**
	 * SiteType constructor
	 * @param name
	 */
	public SiteType(String name)
	{
		siteName=name;
	}
	/**
	 * getName
	 * @return siteName
	 */
	public String getName()
	{
		return siteName;
	}

}
