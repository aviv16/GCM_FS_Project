package entity;

import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;

public class PinWithName {

	public ImageView pinImg;
	public String pinName;
	public TextField textInfo;
	
	public TextField getTextInfo() {
		return textInfo;
	}
	public void setTextInfo(TextField textInfo) {
		this.textInfo = textInfo;
	}
	public ImageView getPinImg() {
		return pinImg;
	}
	public void setPinImg(ImageView pinImg) {
		this.pinImg = pinImg;
	}
	public String getPinName() {
		return pinName;
	}
	public void setPinName(String pinName) {
		this.pinName = pinName;
	}
}
