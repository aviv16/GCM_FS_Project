package entity;

/**
 * The class StatisticInformation
 *
 */
public class StatisticInformation {
	private String cityName;
	private int numberOfMaps;
	private int oneTimeNumber;
	private int subscriptionNumber;
	private int renewalsNumber;
	private int viewsNumber;
	private int downloadsNumber;

	/**
	 * StatisticInformation constructor
	 * 
	 * @param cityName
	 * @param numberOfMaps
	 */
	public StatisticInformation(String cityName, int numberOfMaps) {
		this.cityName = cityName;
		this.numberOfMaps = numberOfMaps;
	}

	/**
	 * get city name
	 * 
	 * @return cityName
	 */
	public String getCityName() {
		return cityName;
	}

	/**
	 * set city name
	 * 
	 * @param cityName
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	/**
	 * get number of map
	 * 
	 * @return numberOfMaps
	 */
	public int getNumberOfMaps() {
		return numberOfMaps;
	}

	/**
	 * set number of maps
	 * 
	 * @param numberOfMaps
	 */
	public void setNumberOfMaps(int numberOfMaps) {
		this.numberOfMaps = numberOfMaps;
	}

	/**
	 * get one time number
	 * 
	 * @return oneTimeNumber
	 */
	public int getOneTimeNumber() {
		return oneTimeNumber;
	}

	/**
	 * set one time number
	 * 
	 * @param oneTimeNumber
	 */
	public void setOneTimeNumber(int oneTimeNumber) {
		this.oneTimeNumber = oneTimeNumber;
	}

	/**
	 * get subscription number
	 * 
	 * @return subscriptionNumber
	 */
	public int getSubscriptionNumber() {
		return subscriptionNumber;
	}

	/**
	 * set subscription number
	 * 
	 * @param subscriptionNumber
	 */
	public void setSubscriptionNumber(int subscriptionNumber) {
		this.subscriptionNumber = subscriptionNumber;
	}

	/**
	 * get renewals subscription number
	 * 
	 * @return renewalsNumber;
	 */
	public int getRenewalsNumber() {
		return renewalsNumber;
	}

	/**
	 * set renewals subscription number
	 * 
	 * @param renewalsNumber
	 */
	public void setRenewalsNumber(int renewalsNumber) {
		this.renewalsNumber = renewalsNumber;
	}

	/**
	 * get view number
	 * 
	 * @return viewsNumber
	 */
	public int getViewsNumber() {
		return viewsNumber;
	}

	/**
	 * set view number
	 * 
	 * @param viewsNumber
	 */
	public void setViewsNumber(int viewsNumber) {
		this.viewsNumber = viewsNumber;
	}

	/**
	 * get number of downloads
	 * 
	 * @return downloadsNumber
	 */
	public int getDownloadsNumber() {
		return downloadsNumber;
	}

	/**
	 * set number of downloads
	 * 
	 * @param downloadsNumber
	 */
	public void setDownloadsNumber(int downloadsNumber) {
		this.downloadsNumber = downloadsNumber;
	}

}
