package entity;

import java.io.Serializable;

/**
 * The class site (in client)
 *
 */
public class Site implements Serializable {

	private static final long serialVersionUID = 1L;
	private String siteName;
	private String cityName;
	private String classifcation;
	private String explanation;
	private String accessibility;
	private int xLocation;
	private int yLocation;

	/**
	 * Site constructor get site name, city name, classification, explanation and
	 * accessibility.
	 * 
	 * @param siteName
	 * @param cityName
	 * @param classifcation
	 * @param explanation
	 * @param accessibility
	 */
	public Site(String siteName, String cityName, String classifcation, String explanation, String accessibility) {
		// TODO Auto-generated constructor stub
		this.siteName = siteName;
		this.cityName = cityName;
		this.classifcation = classifcation;
		this.explanation = explanation;
		this.accessibility = accessibility;
	}

	/**
	 * get site name
	 * 
	 * @return siteName
	 */
	public String getSiteName() {
		return siteName;
	}

	/**
	 * set city name
	 * 
	 * @return cityName
	 */
	public String getCityName() {
		return cityName;
	}

	/**
	 * set site name
	 * 
	 * @param siteName
	 */
	public void setSiteName(String siteName) {
		this.siteName = siteName;
	}

	/**
	 * get classifcation
	 * 
	 * @return classifcation
	 */
	public String getClassifcation() {
		return classifcation;
	}

	/**
	 * set classifcation
	 * 
	 * @param classifcation
	 */
	public void setClassifcation(String classifcation) {
		this.classifcation = classifcation;
	}

	/**
	 * get explanation of site
	 * 
	 * @return explanation
	 */
	public String getExplanation() {
		return explanation;
	}

	/**
	 * set explanation of site
	 * 
	 * @param explanation
	 */
	public void setExplanation(String explanation) {
		this.explanation = explanation;
	}

	/**
	 * get accessibility of the site
	 * 
	 * @return accessibility
	 */
	public String getAccessibility() {
		return accessibility;
	}

	/**
	 * set accessibility of the site
	 * 
	 * @param accessibility
	 */
	public void setAccessibility(String accessibility) {
		this.accessibility = accessibility;
	}

	/**
	 * get x Location in map
	 * 
	 * @return xLocation
	 */
	public int getxLocation() {
		return xLocation;
	}

	/**
	 * set x Location in map
	 * 
	 * @param xLocation
	 */
	public void setxLocation(int xLocation) {
		this.xLocation = xLocation;
	}

	/**
	 * get y Location
	 * 
	 * @return yLocation
	 */
	public int getyLocation() {
		return yLocation;
	}

	/**
	 * set y Location
	 * 
	 * @param yLocation
	 */
	public void setyLocation(int yLocation) {
		this.yLocation = yLocation;
	}

}
