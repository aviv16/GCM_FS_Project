package entity;

import java.io.Serializable;

/**
 * The Class Report (in client)
 */
public class report implements Serializable {

	private static final long serialVersionUID = 1L;
	private String cityName;
	private String date;
	private int viewsNumber;
	private int downloadsNumber;

	/**
	 * Report constructor
	 * 
	 * @param cityName
	 * @param date
	 * @param viewsNumber
	 * @param downloadsNumber
	 */
	public report(String cityName, String date, int viewsNumber, int downloadsNumber) {
		this.setCityName(cityName);
		this.setDate(date);
		this.setViewsNumber(viewsNumber);
		this.setDownloadsNumber(downloadsNumber);
	}

	public String getCityName() {
		return cityName;
	}

	/**
	 * set city name
	 * 
	 * @param cityName
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	/**
	 * get date
	 * 
	 * @return date
	 */
	public String getDate() {
		return date;
	}

	/**
	 * set date
	 * 
	 * @param date
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * get number of view
	 * 
	 * @return viewsNumber
	 */
	public int getViewsNumber() {
		return viewsNumber;
	}

	/**
	 * set number of view
	 * 
	 * @param viewsNumber
	 */
	public void setViewsNumber(int viewsNumber) {
		this.viewsNumber = viewsNumber;
	}

	/**
	 * get number of download
	 * 
	 * @return downloadsNumber
	 */
	public int getDownloadsNumber() {
		return downloadsNumber;
	}

	/**
	 * set number of download
	 * 
	 * @param downloadsNumber
	 */
	public void setDownloadsNumber(int downloadsNumber) {
		this.downloadsNumber = downloadsNumber;
	}

}
