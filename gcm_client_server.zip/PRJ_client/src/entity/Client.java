package entity;

import java.io.Serializable;

/**
 * The Class Client- represents a client in the system
 */
public class Client extends RegisteredUser implements Serializable {

	private static final long serialVersionUID = 1L;
	private String userName;
	private String creditCardNumber;
	private String expirationDate;
	private String cvv;

	/**
	 * This is the constructor of Client.
	 * 
	 * @param cvv             
	 * @param userName         
	 * @param creditCardNumber 
	 * @param expirationDate  
	 */
	public Client(String cvv, String userName, String creditCardNumber, String expirationDate) {
		this.cvv = cvv;
		this.userName = userName;
		this.creditCardNumber = creditCardNumber;
		this.setExpirationDate(expirationDate);
	}

	/**
	 * This is the empty constructor.
	 */
	public Client() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Get the credit card of the client.
	 * 
	 * @return creditCardNumber
	 */
	public String getCreditCardNumber() {
		return creditCardNumber;
	}

	/**
	 * Set the credit card of the client.
	 * 
	 * @param creditCardNumber
	 */
	public void setCreditCardNumber(String creditCardNumber) {
		this.creditCardNumber = creditCardNumber;
	}

	/**
	 * Get the cvv of credit card.
	 * 
	 * @return cvv
	 */
	public String getCvv() {
		return cvv;
	}

	/**
	 * Set the cvv of credit card.
	 * 
	 * @param cvv 
	 */
	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	/**
	 * Get the user name of the client.
	 * 
	 * @return userName
	 */
	public String getuserName() {
		return userName;
	}

	/**
	 * Set the user name of the client.
	 * 
	 * @param userName
	 */
	public void setuserName(String userName) {
		this.userName = userName;
	}

	/**
	 * Get expiration date of credit card.
	 * 
	 * @return expirationDate
	 */
	public String getExpirationDate() {
		return expirationDate;
	}

	/**
	 * Set expiration date of credit card.
	 * 
	 * @param expirationDate
	 */
	public void setExpirationDate(String expirationDate) {
		this.expirationDate = expirationDate;
	}

}
