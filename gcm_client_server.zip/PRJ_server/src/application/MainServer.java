package application;
	
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;



public class MainServer extends Application {
	final public static int DEFAULT_PORT = 5555;
	@Override
	public void start(Stage primaryStage) {
		try {
			Image img=new Image("/application/globeIcon.gif");
			primaryStage.getIcons().add(img);
			AnchorPane root = (AnchorPane)FXMLLoader.load(getClass().getResource("serverGUI.fxml"));
			Scene scene = new Scene(root,400,400);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		    launch(args);
	}
}
