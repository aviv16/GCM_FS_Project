package controllers;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import controllers.QueryCommunicator.type;
import ocsf.server.*;

public class MyServer extends AbstractServer implements Runnable{
	// Class variables 
	public static SqlConnector connection; //connection to DB
	ServerController srvrCtrl; //connection to server GUI controller
	
	//Class methods
	public MyServer(int port, ServerController serverController) throws SQLException { //gets the port to listen to and the controller to send feedback and queries to
		super(port);
		srvrCtrl = serverController;
		connection = new SqlConnector();
		connection.open(); //opens the connection to DB
	}
	
	
	
	/**
	 * gets message from client and the client and  send to the client the information he requested According to the screenName that he sent
	 * @param msg
	 * @param client
	 */
	public void handleMessageFromClient(Object msg, ConnectionToClient client) 
	{  
		QueryCommunicator Qcom=(QueryCommunicator)msg;
		srvrCtrl.updateClientActionIntxtArea(((QueryCommunicator)msg).getQuery()); //send the query to be written in server GUI
		String screenName=Qcom.getScreenName();
		
		switch(screenName)
		{
		
		case "Login"://requests that received from the Login screen 
		{
			boolean activeStatus=false;
			if(Qcom.getQuery().contains("activeStatus"))
				activeStatus=true;
			try {
					
				if(activeStatus)	
				{
					if(Qcom.getType()==type.SELECT_query)	
				 client.sendToClient(connection.CheckIfConnected(Qcom.getQuery(),screenName));//����� �� ����� ���
					else if(Qcom.getType()==type.UPDATE_query)//����� �� ������ ������
						connection.addToTable(Qcom.getQuery());	
				}
				 else
				client.sendToClient(connection.checkIfExist(Qcom.getQuery(),screenName));// ����� �� ���� ���
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			break;
		}
		
		case "Registration":
		{
			if(Qcom.getType()==type.SELECT_query)//����� �� ���� �����
		  {
			try {
				client.sendToClient(connection.checkIfExist(Qcom.getQuery(),screenName));
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		  }
			else if(Qcom.getType()==type.INSERT_query)//����� ���� ��� ������
				connection.addToTable(Qcom.getQuery());
				
			break;
		}
		
		case "SearchInCatalog":
		{
			if(Qcom.getType()==type.SELECT_query)//�� ����� ����� ���� �� �����
			{
				
						
					try {
						if(Qcom.getQuery().contains("site"))
						  client.sendToClient(connection.getSitesList(Qcom.getQuery(), screenName));//����� ����� �����
						
						
						else if(Qcom.getQuery().contains("map"))
							  client.sendToClient(connection.getMap(Qcom.getQuery(), screenName));//
						
						
						else
							client.sendToClient(connection.getCitiesList(Qcom.getQuery(), screenName));//����� ����� ����
							
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}	
			}
			break;
		}
		
		
		case "EditCity":
		{
			if(Qcom.getType()==type.SELECT_query)//�� ����� ����� ���� �� �����
			{
				boolean site=false;
				if(Qcom.getQuery().contains("site"))
					site=true;	
					try {
						if(site)
						  client.sendToClient(connection.getSitesList(Qcom.getQuery(), screenName));// �� ��� ����� ����� �����
						
						else
							client.sendToClient(connection.getToursList(Qcom.getQuery(), screenName));//����� ����� ������� �� ���
						
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}	
			}
			
			else
				connection.addToTable(Qcom.getQuery());
			break;
		}
		
		case "AddCity":
		{
			if(Qcom.getType()==type.SELECT_query)
				try {
					client.sendToClient(connection.getCitiesList(Qcom.getQuery(), screenName));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
			else 
				connection.addToTable(Qcom.getQuery()); //����� ��� ����
			break;
		}
			
		case "AddTourToCity":
		{
			if(Qcom.getType()==type.INSERT_query || Qcom.getType()==type.UPDATE_query)//�� ����� ������ ���� ����
			connection.addToTable(Qcom.getQuery()); 
				
		    else if(Qcom.getType()==type.SELECT_query)//�� ����� ����� ��� ����� ������� ���� �������
				try {
					client.sendToClient(connection.getToursList(Qcom.getQuery(), screenName));
				} catch (IOException e) {
					
					e.printStackTrace();
				}
		    	break;	
		}
		
		case "EditSite":
		{
			
			if(Qcom.getType()==type.SELECT_query)//���� ���� �� ��� ������
				try {
					if(Qcom.getQuery().contains("site_type"))
						client.sendToClient(connection.getSiteTypeNameList(Qcom.getQuery(), screenName));//����� ����� ���� �� ���� �����
					else
					client.sendToClient(connection.getSitesList(Qcom.getQuery(), screenName));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			else if(Qcom.getType()==type.UPDATE_query)//  �� ����� ����� ���
				connection.addToTable(Qcom.getQuery());
			
			break;
		}
		
		case "AddSite":
		{
			if(Qcom.getType()==type.INSERT_query)
				connection.addToTable(Qcom.getQuery());
			if(Qcom.getType()==type.SELECT_query)
			try {
				
				client.sendToClient(connection.getSiteTypeNameList(Qcom.getQuery(), screenName));//����� ����� ���� �� ���� �����
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
		
		case "AddTypeToSite":
		{
			connection.addToTable(Qcom.getQuery());
			break;
		}
		
		case "EditMapWithPic":
		{
			if(Qcom.getType()==type.INSERT_query || Qcom.getType()==type.DELETE_query||Qcom.getType()==type.UPDATE_query)//����� ��� ����
			{
				connection.addToTable(Qcom.getQuery());
			}
			if(Qcom.getType()==type.SELECT_query)
			{
				try {
					
					if(Qcom.getQuery().contains("site_in_map"))
						client.sendToClient(connection.getSite_In_MapList(Qcom.getQuery(), screenName));
				    else if(Qcom.getQuery().contains("map"))
					client.sendToClient(connection.getMap(Qcom.getQuery(), screenName));//������ ���
					else if(Qcom.getQuery().contains("site"))
						client.sendToClient(connection.getSitesList(Qcom.getQuery(), screenName));
					else if(Qcom.getQuery().contains("city"))
						client.sendToClient(connection.getCitiesList(Qcom.getQuery(), screenName));
				
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			break;
		}
		
		case "EditTourInCity":
		{
			if(Qcom.getType()==type.DELETE_query || Qcom.getType()==type.UPDATE_query||Qcom.getType()==type.INSERT_query)
			connection.addToTable(Qcom.getQuery());////����� ��� �����
			if(Qcom.getType()==type.SELECT_query)
				try {
					client.sendToClient(connection.getSiteInTourList(Qcom.getQuery(), screenName));//������ ����� �� ��� �����. �� ���� ������
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			break;
		}
		
		case "Home":
		{
			if(Qcom.getType()==type.SELECT_query)
				try {
					if(Qcom.getQuery().contains("city"))
						client.sendToClient(connection.getCitiesList(Qcom.getQuery(), screenName));
					else if(Qcom.getQuery().contains("client_purchase"))
						client.sendToClient(connection.getClientPurchase(Qcom.getQuery(), screenName));
					else if(Qcom.getQuery().contains("map"))
						client.sendToClient(connection.getMap(Qcom.getQuery(), screenName));
						
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
			else 
				connection.addToTable(Qcom.getQuery());	
			break;
		}
		
		case "ViewClientCard":
		{
			if(Qcom.getType()==type.SELECT_query)
			{

				try {
					if(Qcom.getQuery().contains("registered_users"))	
						 client.sendToClient(connection.checkIfExist(Qcom.getQuery(),screenName));
					else if(Qcom.getQuery().contains("client_purchase"))
						client.sendToClient(connection.getClientPurchase(Qcom.getQuery(), screenName));
					else
					client.sendToClient(connection.getClientList(Qcom.getQuery(), screenName));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			else
				connection.addToTable(Qcom.getQuery());
			break;
		}
		
		case "ViewCityInMapCatalog":
		{
			try {
				if(Qcom.getQuery().contains("map"))
					client.sendToClient(connection.getMap(Qcom.getQuery(), screenName));
				else
				client.sendToClient(connection.getToursList(Qcom.getQuery(), screenName));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
		
		case "PurchaseSubscription":
		{
			if(Qcom.getType()==type.SELECT_query)
			{

				try {
					if(Qcom.getQuery().contains("report"))
						client.sendToClient(connection.getReportList(Qcom.getQuery(), screenName));
				    else if(Qcom.getQuery().contains("site_in_map"))
						client.sendToClient(connection.getSite_In_MapList(Qcom.getQuery(), screenName));
					else if(Qcom.getQuery().contains("map"))
						client.sendToClient(connection.getMap(Qcom.getQuery(), screenName));
					else if(Qcom.getQuery().contains("site_in_tour"))
						client.sendToClient(connection.getSiteInTourList(Qcom.getQuery(), screenName));	
					else if(Qcom.getQuery().contains("tour"))
						client.sendToClient(connection.getToursList(Qcom.getQuery(), screenName));
					else if(Qcom.getQuery().contains("site"))
					client.sendToClient(connection.getSitesList(Qcom.getQuery(), screenName));
					
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

			else
			connection.addToTable(Qcom.getQuery());
			break;
		}
		
		case "showReport":
		{
			
			if(Qcom.getType()==type.SELECT_query)
			{

				try {
					if(Qcom.getQuery().contains("client_purchase"))
						client.sendToClient(connection.getClientPurchase(Qcom.getQuery(), screenName));
					else if(Qcom.getQuery().contains("report"))
					client.sendToClient(connection.getReportList(Qcom.getQuery(), screenName));
					else if(Qcom.getQuery().contains("map"))
						client.sendToClient(connection.getMap(Qcom.getQuery(), screenName));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			else 
				connection.addToTable(Qcom.getQuery());
			break;
			
		}
		case "createReport":
		{
			try {
				client.sendToClient(connection.getCitiesList(Qcom.getQuery(), screenName));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}


		case "ChangePrices":
		{
			try {
				client.sendToClient(connection.getCitiesList(Qcom.getQuery(), screenName));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
		
		case "ChangePricesDepartmentDirector":
		{
			if(Qcom.getType()==type.SELECT_query)
			{
				try {
						client.sendToClient(connection.getCitiesList(Qcom.getQuery(), screenName));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else 
				connection.addToTable(Qcom.getQuery());
			break;
		}
		
		case "ChangePricesCompanyManager":
		{
			if(Qcom.getType()==type.SELECT_query)
			{
				try {
					if(Qcom.getQuery().contains("newprice"))
						client.sendToClient(connection.getNewCitiesList(Qcom.getQuery(), screenName));
					else 
						client.sendToClient(connection.getCitiesList(Qcom.getQuery(), screenName));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else 
				connection.addToTable(Qcom.getQuery());
			break;
		}
		
		case "SubscriptionRenewal":
		{
			connection.addToTable(Qcom.getQuery());
			break;
		}
		
		case "ManagerHome":
		{
			if(Qcom.getType()==type.SELECT_query)
			{
				try {
                        if(Qcom.getQuery().contains("map"))	
						client.sendToClient(connection.getMap(Qcom.getQuery(), screenName));
                        else if(Qcom.getQuery().contains("client"))	
    						client.sendToClient(connection.getClientList(Qcom.getQuery(), screenName));
                        else
                        	client.sendToClient(connection.getNewCitiesList(Qcom.getQuery(), screenName));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			else 
				connection.addToTable(Qcom.getQuery());
			break;
		}
		
		case "MapApproval":
		{
			if(Qcom.getType()==type.SELECT_query)
			{
				try {
						client.sendToClient(connection.getMap(Qcom.getQuery(), screenName));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if(Qcom.getQuery().contains("mapFile= ?"))
				try {
					connection.addFile(Qcom.getQuery(),Qcom.getFilename());
				} catch (FileNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			else
				connection.addToTable(Qcom.getQuery());
			break;
		}
		
		case "EmployeeHome":
		{
			connection.addToTable(Qcom.getQuery());
			break;
		}
		
		case "ViewPurchasedCities":
		{
			
			if(Qcom.getType()==type.SELECT_query)
			{
				try {
					   if(Qcom.getQuery().contains("map"))	
						client.sendToClient(connection.getMap(Qcom.getQuery(), screenName));
					   else
						 client.sendToClient(connection.getReportList(Qcom.getQuery(), screenName));
						   
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else
				connection.addToTable(Qcom.getQuery());
			break;
			
		}
		
		case "MapImage":
		{
			if(Qcom.getType()==type.SELECT_query)
			{
				try {
                    if(Qcom.getQuery().contains("site_in_map"))	
					client.sendToClient(connection.getSite_In_MapList(Qcom.getQuery(), screenName));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
			
			else
				connection.addToTable(Qcom.getQuery());
			break;
		}
		
		case "ViewClientDetails":
		{
			if(Qcom.getType()==type.SELECT_query)
			{
				try {
					if(Qcom.getQuery().contains("client_purchase"))
						client.sendToClient(connection.getClientPurchase(Qcom.getQuery(), screenName));
					else
					client.sendToClient(connection.getCitiesList(Qcom.getQuery(), screenName));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			}
			break;
		}
		
		case "ChooseCityToEdit":
		{
			if(Qcom.getType()==type.SELECT_query)
			{
				try {
						client.sendToClient(connection.getCitiesList(Qcom.getQuery(), screenName));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
			break;
		}
		
		
		
			
	}
	
	
}
	/**
	 * This method overrides the one in the superclass. Called when the server
	 * starts listening for connections.
	 */
	protected void serverStarted() {
		System.out.println("Server listening for connections on port " + getPort());
	}

	/**
	 * This method overrides the one in the superclass. Called when the server stops
	 * listening for connections.
	 */
	protected void serverStopped() {
		System.out.println("Server has stopped listening for connections.");
	}
}
