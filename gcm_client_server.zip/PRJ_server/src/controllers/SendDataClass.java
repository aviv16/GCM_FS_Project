package controllers;

import java.io.Serializable;




/**
 *A class that helps transfer data from server to client
 *screenName-the name of the screen which the data is transferred to.
 */
public class SendDataClass implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	
	private String screenName;//That is the name of the screen which the data is transferred to.
	private Object data; //the data
	
	public SendDataClass(String screenName,Object data)
	{
		this.data=data;
		this.screenName=screenName;
	}
	
	public String getScreenName()
	{
		return screenName;
	}
	
	public Object getData()
	{
		return data;
	}
}
