package controllers;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import entity.City;
import entity.Client;
import entity.ClientPurchase;
import entity.Map;
import entity.RegisteredUser;
import entity.Site;
import entity.SiteInMap;
import entity.SiteInTour;
import entity.SiteType;
import entity.Tour;
import entity.newCity;
import entity.report;


/**
 * connecting between the server to the DB
 * This class contains functions that receive queries as a parameter and execute them
 */


public class SqlConnector {
	// Class variables 
	Connection conn;
	
	
	
	
	/**
	 * Connecting to SQL
	 * @param query
	 * @param screenName
	
	 */
	public void open() throws SQLException //opens the connection to the DB
	{
		try 
		{
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (Exception ex) {/* handle the error*/}
        
            conn = DriverManager.getConnection("jdbc:mysql://localhost/gcm?serverTimezone=IST","root",ServerController.passwordToDB);
			//conn = DriverManager.getConnection("jdbc:mysql://localhost/gcm?serverTimezone=IST","root","root");

            System.out.println("SQL connection succeed");
   	}
	
/*	public void editVersion(String query) //changing the version of a city using a query           
	
	{
		Statement stmt;
		try {
			stmt = conn.createStatement();		
			stmt.executeUpdate(query);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}*/

	
	
	
	/**
	 * Returns a list of SiteInMap object in the structure SendDataClass
	 * @param query
	 * @param screenName
	 * @return SendDataClass
	 */
	
	public SendDataClass getSite_In_MapList(String query,String screenName) {
		ArrayList<SiteInMap> siteInmapList=new ArrayList<SiteInMap>();
		Statement stmt;
		SendDataClass siteInMap;
		
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while(rs.next()) //saves each city name from DB 
			{
				siteInmapList.add(new SiteInMap(Integer.parseInt(rs.getString("mapID")),(Integer.parseInt(rs.getString("mapVersion"))),(rs.getString("siteName")),((double)(rs.getObject("xOnMap"))),((double)(rs.getObject("yOnMap")))));	
			}
			siteInMap=new SendDataClass(screenName,siteInmapList);
			return siteInMap;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	/**
	 * Returns a list of ClientPurchases object in the structure SendDataClass
	 * @param query
	 * @param screenName
	 * @return SendDataClass
	 */

	public SendDataClass getClientPurchase(String query,String screenName)
	{
		ArrayList<ClientPurchase> ClientPurchaseList=new ArrayList<ClientPurchase>();
		SendDataClass clientPurchase;
		Statement stmt;
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			
			while(rs.next()) //saves each city name from DB 
			{
				ClientPurchaseList.add(new ClientPurchase(rs.getString("date"),(float)rs.getObject("discount"),rs.getString("userName"),(int)rs.getObject("purchaseType"),(int)rs.getObject("purchaseNum"),rs.getString("cityName"),(int)rs.getObject("subPeriod"),(int)rs.getObject("SubRenewal"),(int)rs.getObject("userSubscribed"),(int)rs.getObject("upToDate")));	
			}
			clientPurchase=new SendDataClass(screenName,ClientPurchaseList);
			return clientPurchase;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	/**
	 * Returns a list of Report object in the structure SendDataClass
	 * @param query
	 * @param screenName
	 * @return SendDataClass
	 */
	public SendDataClass getReportList(String query,String screenName)
	{
		ArrayList<report> ReportList=new ArrayList<report>();
		SendDataClass Report;
		Statement stmt;
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			
			while(rs.next()) //saves each city name from DB 
			{
				ReportList.add(new report(rs.getString("cityName"),rs.getString("date"),(int)rs.getObject("viewsNumber"),(int)rs.getObject("downloadsNumber")));	
			}
			Report=new SendDataClass(screenName,ReportList);
			return Report;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	
	/**
	 * Returns a list of Map object in the structure SendDataClass
	 * @param query
	 * @param screenName
	 * @return SendDataClass
	 */
	public SendDataClass getMap(String query,String screenName)
	{
		ArrayList<Map> mapList=new ArrayList<Map>();
		SendDataClass mapIm;
		Statement stmt;
		
		
		try
		{
			
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			int i=0;
			
			while(rs.next()) //saves each city name from DB 
			{
				Blob blob=rs.getBlob("mapFile");
				byte[] bytes=blob.getBytes(1l, (int)blob.length());
				mapList.add(new Map((int)rs.getObject("version"),rs.getString("description"),(int)rs.getObject("mapID"),bytes,rs.getString("UploadDate"),rs.getString("DeleteDate"),rs.getString("cityName"),(int)rs.getObject("isEditing"),(int)rs.getObject("isSentApproval")));
				//mapList.get(i).setInput(rs.getBinaryStream("mapFile"));	
				i++;	
			}
			mapIm=new SendDataClass(screenName,mapList);
			return mapIm;
		}
		catch(Exception e)
		{
			
		}
		return null;
	
	}
	
	
	
	
	/**
	 * Returns a list of SiteType object in the structure SendDataClass
	 * @param query
	 * @param screenName
	 * @return SendDataClass
	 */
	public SendDataClass getSiteTypeNameList(String query,String screenName) {
		ArrayList<SiteType> siteTypeList=new ArrayList<SiteType>();
		Statement stmt;
		SendDataClass siteType;
		
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while(rs.next()) //saves each city name from DB 
			{
				siteTypeList.add(new SiteType(rs.getString("siteTypeName")));	
			}
			siteType=new SendDataClass(screenName,siteTypeList);
			return siteType;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	/**
	 * Returns a list of Tour object in the structure SendDataClass
	 * @param query
	 * @param screenName
	 * @return SendDataClass
	 */
	public SendDataClass getToursList(String query,String screenName) { 
		ArrayList<Tour> toursList=new ArrayList<Tour>();
		Statement stmt;
		SendDataClass tours;
		
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while(rs.next()) //saves each city name from DB 
			{
				toursList.add(new Tour(Integer.parseInt(rs.getString("tourID")),(rs.getString("description")),(rs.getString("cityName"))));	
			}
			tours=new SendDataClass(screenName,toursList);
			return tours;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	
	/**
	 * Returns a list of SiteInTour object in the structure SendDataClass
	 * @param query
	 * @param screenName
	 * @return SendDataClass
	 */
	
	public SendDataClass getSiteInTourList(String query,String screenName) { 
		ArrayList<SiteInTour> SiteInTourList=new ArrayList<SiteInTour>();
		Statement stmt;
		SendDataClass SiteInTour;
		
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while(rs.next()) //saves each city name from DB 
			{
				SiteInTourList.add(new SiteInTour(Integer.parseInt(rs.getString("tourID")),Integer.parseInt(rs.getString("serialNumber")),Integer.parseInt(rs.getString("visitDuration")),(rs.getString("siteName")),(rs.getString("cityName"))));	
			}
			SiteInTour=new SendDataClass(screenName,SiteInTourList);
			return SiteInTour;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	/**
	 * Returns a list of Client object in the structure SendDataClass
	 * @param query
	 * @param screenName
	 * @return SendDataClass
	 */
	public SendDataClass getClientList(String query,String screenName) { 
		ArrayList<Client> ClientList=new ArrayList<Client>();
		Statement stmt;
		SendDataClass Client;
		
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while(rs.next()) //saves each city name from DB 
			{
				ClientList.add(new Client((rs.getString("CVV")),(rs.getString("userName")),(rs.getString("creditCardNum")),(rs.getString("expirationDate"))));	
			}
			Client=new SendDataClass(screenName,ClientList);
			return Client;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	
	/**
	 * Returns a list of Site object in the structure SendDataClass
	 * @param query
	 * @param screenName
	 * @return SendDataClass
	 */
	public SendDataClass getSitesList(String query,String screenName) { 
		ArrayList<Site> sitesList=new ArrayList<Site>();
		Statement stmt;
		SendDataClass sites;
		
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while(rs.next()) //saves each city name from DB 
			{
				sitesList.add(new Site(rs.getString("siteName"),rs.getString("cityNamefk"),(rs.getString("classification")),(rs.getString("description")),(rs.getString("accessability"))));	
			}
			sites=new SendDataClass(screenName,sitesList);
			return sites;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	
	
	/**
	 * Returns a list of City object in the structure SendDataClass
	 * @param query
	 * @param screenName
	 * @return SendDataClass
	 */
	public SendDataClass getCitiesList(String query,String screenName) { 
		ArrayList<City> cityList=new ArrayList<City>();
		Statement stmt;
		SendDataClass cities;
		
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while(rs.next()) //saves each city name from DB 
			{
				cityList.add(new City(rs.getString("cityName"),Double.parseDouble(rs.getString("price"))));	
			}
			cities=new SendDataClass(screenName,cityList);
			return cities;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	
	/**
	 * Returns a list of newCity object in the structure SendDataClass
	 * @param query
	 * @param screenName
	 * @return SendDataClass
	 */
	public SendDataClass getNewCitiesList(String query,String screenName) {
		ArrayList<newCity> cityList=new ArrayList<newCity>();
		Statement stmt;
		SendDataClass cities;
		
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while(rs.next()) //saves each city name from DB 
			{
				cityList.add(new newCity(rs.getString("cityName"),Double.parseDouble(rs.getString("price"))));	
			}
			cities=new SendDataClass(screenName,cityList);
			return cities;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	
/*	public SendDataClass getIDofCreatedTour(String query,String screenName)
	{
		Statement stmt;
		SendDataClass CreatedTour;
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			CreatedTour=new SendDataClass(screenName,rs.getString("tourID"));			
			return CreatedTour;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	*/
	
	
	/*public sendDataClass getSitesList(String query,String screenName) { //����� ����� ����� �� ��� ���� ����� ������
		ArrayList<String> sitesList=new ArrayList<String>();
		Statement stmt;
		sendDataClass sitesNames;
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while(rs.next()) //saves each city name from DB 
			{
				sitesList.add(rs.getString("siteName"));
			}
			sitesNames=new sendDataClass(screenName,sitesList);
			return sitesNames;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	public sendDataClass getCitiesList(String query,String screenName) { //����� ����� ���� ���� ����� ������
		ArrayList<String> cityList=new ArrayList<String>();
		Statement stmt;
		sendDataClass citiesNames;
		try {
			stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while(rs.next()) //saves each city name from DB 
			{
				cityList.add(rs.getString("cityName"));
			}
			citiesNames=new sendDataClass(screenName,cityList);
			return citiesNames;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}*/
	
	
	
	
	/**
	 * For "Registration" screenName should be returned true/false if the client exists or not in SendDataClass object
	 * For "Login" and "ViewClientCard" screenName  should be returned the registered user object SendDataClass object
	 * @param query
	 * @param screenName
	 * @return SendDataClass
	 */
	public SendDataClass checkIfExist(String query,String screenName)
	{
		ResultSet rs;
		Statement stmt;
		SendDataClass ExistUser;
		
		try {
			
			stmt=conn.createStatement();
			rs = stmt.executeQuery(query);
			if(!rs.next())//If the string is empty, the user does not exist and returns false
			{
				ExistUser= new SendDataClass(screenName,false);
				return ExistUser;
			}

			
			else if(screenName.equals("Registration"))//If this is a test if an existing client returns true
			{
				ExistUser= new SendDataClass(screenName,true);
				return ExistUser;
			}
			
			
			else if(screenName.equals("Login") || screenName.equals("ViewClientCard"))//Returns the registered user object
			{
				RegisteredUser regUser= new RegisteredUser();
				//regUser.setID(Integer.parseInt(rs.getString("ID")));
				regUser.setFirstName(rs.getString("firstName"));
				regUser.setLastName(rs.getString("lastName"));
				regUser.setUserName(rs.getString("userName"));
				regUser.setPassword(rs.getString("password"));
				regUser.setPhoneNumber((rs.getString("phoneNumber")));
				regUser.setEmail((rs.getString("email")));
				regUser.setPermission(Integer.parseInt(rs.getString("permission")));
				regUser.setActiveStatus(Integer.parseInt(rs.getString("activeStatus")));
				ExistUser= new SendDataClass(screenName,regUser);
				return ExistUser;
			}
				
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return null;
	}
	
	
	
	
	/**
	 * Adds an image file to a map entry in SQL
	 * @param query
	 * @param screenName
	 */
	public void addFile(String sql,String fileName) throws SQLException
	, FileNotFoundException
		{
			PreparedStatement myStmt= conn.prepareStatement(sql);
			File theFile=new File(fileName);
			FileInputStream input=new FileInputStream(theFile);
			myStmt.setBinaryStream(1,input);
			myStmt.executeUpdate();	
		}

	
	
	
	/**
	 * Implementing the table update queries
	 * @param query
	 * @param screenName
	 */
	public void addToTable(String query)
	{
		Statement stmt;
		try {
			stmt=conn.createStatement();
			stmt.executeUpdate(query);
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	
	
	
	/**
	 * Check if a user is logged on
	 * @param query
	 * @param screenName
	 * @return SendDataClass
	 */
	
	
	public SendDataClass CheckIfConnected(String query,String screenName)
	{
		ResultSet rs;
		Statement stmt;
		SendDataClass connectedUser;
			
			try {
				stmt=conn.createStatement();
				rs = stmt.executeQuery(query);
				if(!rs.next())//false�� �� ����� �����
					connectedUser= new SendDataClass(screenName,false);
					
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
				connectedUser= new SendDataClass(screenName,true);
				return connectedUser;	
	}
}


