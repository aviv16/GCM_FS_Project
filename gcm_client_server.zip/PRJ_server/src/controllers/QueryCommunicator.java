package controllers;

import java.io.Serializable;


/**
 *class that have a query and the type of the query. Objects from this class will be send from client to server
 */
public class QueryCommunicator implements Serializable{
	// Class variables 
	private static final long serialVersionUID = 1L;
	private String Filename;
	private String query;
	private type t;
	private String screenName;
	public enum type {SELECT_query, UPDATE_query,INSERT_query,DELETE_query};
	//INSERT
	// Class methods
	

/**
 * gets query and classifies it using the first word
 * @param query
 * @param screenName
 */
	public QueryCommunicator(String query,String screenName) 
	{
		this.screenName=screenName;
		this.query=query;
		if(query.startsWith("SELECT"))
			t=type.SELECT_query;
		else {
			if(query.startsWith("UPDATE"))
				t=type.UPDATE_query;
		
			if(query.startsWith("INSERT"))
				t=type.INSERT_query;
			
			if(query.startsWith("DELETE"))
			   t=type.DELETE_query;
		}
	
		}
	
	public type getType()
	{
		return t;
	}
	
	public String getQuery()
	{
		return query;
	}
	public String getScreenName()
	{
		return screenName;
	}

	public String getFilename() {
		return Filename;
	}

	public void setFilename(String filename) {
		Filename = filename;
	}
}
