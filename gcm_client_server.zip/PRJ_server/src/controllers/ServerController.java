package controllers;

import java.io.IOException;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class ServerController {

	// Class variables
	MyServer sv;

	final public static int DEFAULT_PORT = 5555;
	public static String passwordToDB;

	@FXML
	private Button connectBtn;

	@FXML
	private TextArea logDisplay;

	@FXML
	private Label consuccesslbl;

	@FXML
	private Label confaillbl;

	@FXML
	private TextField password;

	/**
	 * the server screen connect to the SQL using the entered password if password
	 * not entered, using the default password "Aa123456"
	 */
	public void connectToDB(ActionEvent event) {
		int port = 0; // Port to listen on
		port = DEFAULT_PORT; // Set port to 5555
		passwordToDB = password.getText();
		if (passwordToDB.equals("")) {
			passwordToDB = "Aa123456";
		}
		consuccesslbl.setVisible(false);
		confaillbl.setVisible(false);
		try {
			sv = new MyServer(port, this); // create new MyServer (extends AbstractServer) and sends him this object to
											// get messages from client
			sv.listen(); // Start listening for connections
			consuccesslbl.setVisible(true);
		} catch (SQLException e) {
			confaillbl.setVisible(true);
		} catch (Exception ex) {
			consuccesslbl.setVisible(false);
			System.out.println("ERROR - Could not listen for clients!");
			confaillbl.setVisible(true);
		}
	}

	/**
	 * gets all the actions that the user does and present them on log
	 * 
	 * @param query
	 */
	public void updateClientActionIntxtArea(String query) { // gets query and shows them on the server's textArea
		logDisplay.appendText(query + "\n");

	}
	/**
	 * closes the connection to the server
	 * @param event
	 * @throws IOException 
	 */
	@FXML
    void closeConnection(ActionEvent event) throws IOException {
		sv.close();
		consuccesslbl.setVisible(false);
    }
}
