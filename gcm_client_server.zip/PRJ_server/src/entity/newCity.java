package entity;

import java.io.Serializable;

/**
 * The class NewCity (In server) save new rate of the city
 */
public class newCity implements Serializable {
	private static final long serialVersionUID = 1L;
	private String name;
	private double newPrice;

	/**
	 * This is the constructor of newCity.
	 * 
	 * @param name
	 * @param newPrice
	 */
	public newCity(String name, double newPrice) {
		this.name = name;
		this.newPrice = newPrice;
	}

	/**
	 * get city name
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * set city name
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * get the rate of the city
	 * 
	 * @return newPrice
	 */
	public double getRate() {
		return newPrice;
	}

	/**
	 * set the rate of the city
	 * 
	 * @param newPrice
	 */
	public void setRate(double newPrice) {
		this.newPrice = newPrice;
	}
}