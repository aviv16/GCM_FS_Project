package entity;

import java.io.Serializable;
/**
 * The class StatisticallInformation - the statistic information  (in server)
 *
 */
public class StatisticallInformation implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private int numberPurchasesMapOfCity;
	private int numberSubscriptionRenewal;
	
	/**
	 * get number of purchase
	 * @return numberPurchasesMapOfCity;
	 */
	public int getNumberPurchasesMapOfCity() {
		return numberPurchasesMapOfCity;
	}
	/**
	 * set number of purcahse
	 * @param numberPurchasesMapOfCity
	 */
	public void setNumberPurchasesMapOfCity(int numberPurchasesMapOfCity) {
		this.numberPurchasesMapOfCity = numberPurchasesMapOfCity;
	}
	/**
	 * get number subscription renewal
	 * @return getNumberSubscriptionRenewal
	 */
	public int getNumberSubscriptionRenewal() {
		return numberSubscriptionRenewal;
	}
	/**
	 * set number subscription renewal
	 * @param numberSubscriptionRenewal
	 */
	public void setNumberSubscriptionRenewal(int numberSubscriptionRenewal) {
		this.numberSubscriptionRenewal = numberSubscriptionRenewal;
	}
	
	
}
