package entity;

import java.io.Serializable;

/**
 * The class map (In server) represents map in the system
 *
 */

public class Map implements Serializable {
	private static final long serialVersionUID = 1L;
	private int version;
	private String textualDescription;
	private int IDMap;
	private byte[] myFile;
	private String UploadDate;
	private String DeleteDate;
	private String cityName;
	private int isEditing;
	private int isSentApproval;

	/**
	 * This is the constructor of Map.
	 * 
	 * @param version
	 * @param textualDescription
	 * @param IDMap
	 * @param myFile
	 * @param UploadDate
	 * @param DeleteDate
	 * @param cityName
	 * @param isEditing
	 * @param isSentApproval
	 */
	public Map(int version, String textualDescription, int IDMap, byte[] myFile, String UploadDate, String DeleteDate,
			String cityName, int isEditing, int isSentApproval) {
		this.version = version;
		this.textualDescription = textualDescription;
		this.IDMap = IDMap;
		this.setMyFile(myFile);
		this.UploadDate = UploadDate;
		this.DeleteDate = DeleteDate;
		this.setCityName(cityName);
		this.isEditing = isEditing;
		this.isSentApproval = isSentApproval;
	}

	/**
	 * get version
	 * 
	 * @return version
	 */
	public int getVersion() {
		return version;
	}

	/**
	 * set version
	 * 
	 * @param version
	 */
	public void setVersion(int version) {
		this.version = version;
	}

	/**
	 * get description of the map
	 * 
	 * @return textualDescription
	 */
	public String getTextualDescription() {
		return textualDescription;
	}

	/**
	 * set description of the map
	 * 
	 * @param textualDescription
	 */
	public void setTextualDescription(String textualDescription) {
		this.textualDescription = textualDescription;
	}

	/**
	 * get map ID
	 * 
	 * @return mapID
	 */
	public int getIDMap() {
		return IDMap;
	}

	/**
	 * set map ID
	 * 
	 * @param iDMap
	 */
	public void setIDMap(int iDMap) {
		IDMap = iDMap;
	}

	/**
	 * get the image of map
	 * 
	 * @return myFile
	 */
	public byte[] getMyFile() {
		return myFile;
	}

	/**
	 * set the image of map
	 * 
	 * @param myFile
	 */
	public void setMyFile(byte[] myFile) {
		this.myFile = myFile;
	}

	/**
	 * get upload date
	 * 
	 * @return UploadDate
	 */
	public String getUploadDate() {
		return UploadDate;
	}

	/**
	 * set upload date
	 * 
	 * @param uploadDate
	 */
	public void setUploadDate(String uploadDate) {
		UploadDate = uploadDate;
	}

	/**
	 * get delete date
	 * 
	 * @return DeleteDate
	 */
	public String getDeleteDate() {
		return DeleteDate;
	}

	/**
	 * set delete date
	 * 
	 * @param deleteDate
	 */
	public void setDeleteDate(String deleteDate) {
		DeleteDate = deleteDate;
	}

	/**
	 * get city name
	 * 
	 * @return cityName
	 */
	public String getCityName() {
		return cityName;
	}

	/**
	 * set city name
	 * 
	 * @param cityName
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	/**
	 * get if map editing
	 * 
	 * @return isEditing;
	 */
	public int getIsEditing() {
		return isEditing;
	}

	/**
	 * set if map editing
	 * 
	 * @param isEditing
	 */
	public void setIsEditing(int isEditing) {
		this.isEditing = isEditing;
	}

	/**
	 * get if map sent to approval
	 * 
	 * @return isSentApproval;
	 */
	public int getIsSentApproval() {
		return isSentApproval;
	}

	/**
	 * set if map sent to approval
	 * 
	 * @param isSentApproval
	 */
	public void setIsSentApproval(int isSentApproval) {
		this.isSentApproval = isSentApproval;
	}

}
