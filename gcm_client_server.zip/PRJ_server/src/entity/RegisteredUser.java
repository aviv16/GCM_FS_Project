package entity;

import java.io.Serializable;
/**
 * The Class RegisteredUser (in sever)
 */
public class RegisteredUser implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	enum Permission {CLIENT,WORKER,MANAGER,COMPANYMANAGER}
	private int permission;
	private String userName;
	private int ID;
	private String phoneNumber;
	private String email;
	private String password;
	private int activeStatus;
	private String firstName;
	private String lastName;
	/**
	 * get the permission of the user (client, employee, employee manager, company manager)
	 * @return
	 */
	public int getPermission() {
		return permission;
	}
	/**
	 * set the permission of the user
	 * @param permission
	 */
	public void setPermission(int permission) {
		this.permission = permission;
	}
	/**
	 * get user name
	 * @return userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * set user name
	 * @param userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * get ID
	 * @return ID
	 */
	public int getID() {
		return ID;
	}
	/**
	 * set ID
	 * @param iD
	 */
	public void setID(int iD) {
		ID = iD;
	}
	/**
	 * get phone number
	 * @return phoneNumber
	 */
	public String getPhoneNumber() {
		return phoneNumber;
	}
	/**
	 * set phone number
	 * @param phoneNumber
	 */
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	/**
	 * get email
	 * @return email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * set email
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * get password
	 * @return password
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * set password
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * get active status
	 * @return activeStatus
	 */
	public int getActiveStatus() {
		return activeStatus;
	}
	/**
	 * set active status
	 * @param activeStatus
	 */
	public void setActiveStatus(int activeStatus) {
		this.activeStatus = activeStatus;
	}
	/**
	 * get first name
	 * @return firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * set first name
	 * @param firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * get last name
	 * @return lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * set last name
	 * @param lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
}



