package entity;

import java.io.Serializable;

/**
 * The Class ClientPurchase (In server) represents the purchase of client.
 */
public class ClientPurchase implements Serializable {

	private static final long serialVersionUID = 1L;
	private String date;// ����� ������
	private float discount;// ����
	private String userName;// �� �����
	// public enum type {ONE_TIME,SUBSCRIPTION};
	private int purchaseType_1_2;// ��� �����:1-�� ����� 2-����� ����
	private int purchaseNum;// ���� �����
	private String cityName;// �� ���� �����
	private int subPeriod;// ����� ����� ���� ����� �� ����� ����� ����� ��� 0
	private int subRenewal_0_1;// �� ������ ���� ��� ����� ���� ����� ����? �� �� 1 ���� 0
	private int userSubscribed_0_1;// ��� ����� ��� ���� ����� �� �� 1 ���� 0
	private int upToDate;

	/**
	 * This is the constructor ofClientPurchase.
	 * 
	 * the constructor get: date of purchase, discount if client subscribe,name of
	 * client purchaseType_1_2(1-for one time, 2-for subscribtion), the number of
	 * purchase the name of the city, the subscription duration, subRenewal,
	 * userSubscribed- if client is subscribe) and up to date
	 * 
	 * @param date
	 * @param discount
	 * @param userName
	 * @param purchaseType_1_2
	 * @param purchaseNum
	 * @param cityName
	 * @param subPeriod
	 * @param subRenewal_0_1
	 * @param userSubscribed_0_1
	 * @param upToDate
	 */
	public ClientPurchase(String date, float discount, String userName, int purchaseType_1_2, int purchaseNum,
			String cityName, int subPeriod, int subRenewal_0_1, int userSubscribed_0_1, int upToDate) {
		this.setDate(date);
		this.setDiscount(discount);
		this.setUserName(userName);
		this.setPurchaseType(purchaseType_1_2);
		this.setPurchaseNum(purchaseNum);
		this.setCityName(cityName);
		this.setSubPeriod(subPeriod);
		this.setSubRenewal(subRenewal_0_1);
		this.setUserSubscribed(userSubscribed_0_1);
		this.setUpToDate(upToDate);
	}

	/**
	 * get date
	 * 
	 * @return date
	 */
	public String getDate() {
		return date;
	}

	/**
	 * set date
	 * 
	 * @param date
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * get discount
	 * 
	 * @return discount
	 */
	public float getDiscount() {
		return discount;
	}

	/**
	 * set discount
	 * 
	 * @param discount
	 */
	public void setDiscount(float discount) {
		this.discount = discount;
	}

	/**
	 * get user name
	 * 
	 * @return userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * set user name
	 * 
	 * @param userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * get purchase number
	 * 
	 * @return purchaseNum
	 */
	public int getPurchaseNum() {
		return purchaseNum;
	}

	/**
	 * set purchase number
	 * 
	 * @param purchaseNum
	 */
	public void setPurchaseNum(int purchaseNum) {
		this.purchaseNum = purchaseNum;
	}

	/**
	 * get city name
	 * 
	 * @return cityName
	 */
	public String getCityName() {
		return cityName;
	}

	/**
	 * set city name
	 * 
	 * @param cityName
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	/**
	 * get subscription duration
	 * 
	 * @return subPeriod
	 */
	public int getSubPeriod() {
		return subPeriod;
	}

	/**
	 * set subscription duration
	 * 
	 * @param subPeriod
	 */
	public void setSubPeriod(int subPeriod) {
		this.subPeriod = subPeriod;
	}

	/**
	 * get is subscription renewal
	 * 
	 * @return subRenewal_0_1.
	 */
	public int isSubRenewal() {
		return subRenewal_0_1;
	}

	/**
	 * set is subscription renewal
	 * 
	 * @param subRenewal
	 */
	public void setSubRenewal(int subRenewal) {
		this.subRenewal_0_1 = subRenewal;
	}

	/**
	 * get if user have subscription
	 * 
	 * @return userSubscribed_0_1;
	 */
	public int isUserSubscribed() {
		return userSubscribed_0_1;
	}

	/**
	 * set if user have subscription
	 * 
	 * @param userSubscribed
	 */
	public void setUserSubscribed(int userSubscribed) {
		this.userSubscribed_0_1 = userSubscribed;
	}

	/**
	 * get purchase type subscription or one time
	 * 
	 * @return purchaseType_1_2
	 */
	public int getPurchaseType() {
		return purchaseType_1_2;
	}

	/**
	 * set purchase type subscription or one time
	 * 
	 * @param purchaseType
	 */

	public void setPurchaseType(int purchaseType) {
		this.purchaseType_1_2 = purchaseType;
	}

	/**
	 * get up to date
	 * 
	 * @return upToDate;
	 */

	public int getUpToDate() {
		return upToDate;
	}

	/**
	 * set up to date
	 * 
	 * @param upToDate
	 */
	public void setUpToDate(int upToDate) {
		this.upToDate = upToDate;
	}

}
